@extends('layout')

@section('mainContent')
	<h1>Update/Delete User</h1>
		<form class="form-horizontal" method="post" action="/locates/{{$locate->id}}">
		@csrf
    @method('put')
    <fieldset>
      <legend></legend>
      <div class="form-group">
        <label class="col-md-4 control-label" for="Province">Province</label>
        <div class="col-md-4">
          <input id="Province" name="Province" type="text"
          placeholder="Enter Province" class="form-control
          input-md"value="{{$locate->Province}}">
        </div>
      </div>

 <div class="form-group">
        <label class="col-md-4 control-label" for="City">City</label>
        <div class="col-md-4">
          <input id="City" name="City" type="text"
          placeholder="Enter City" class="form-control
          input-md"value="{{$locate->City}}">
        </div>
      </div>

       <div class="form-group">
        <label class="col-md-4 control-label" for="Purok">Purok</label>
        <div class="col-md-4">
          <input id="Purok" name="Purok" type="text"
          placeholder="Enter Purok" class="form-control
          input-md"value="{{$locate->Purok}}">
        </div>
      </div>

 <div class="form-group">
        <label class="col-md-4 control-label" for="Purok">Purok</label>
        <div class="col-md-4">
          <button id="submit" name="submit" class="btn btn-primary">Update
           </button>
        </div>
      </div>
    </fieldset>
  </form>

<form class="form-horizontal" method="post" action="/locates/{{$locate->id}}">
  @csrf
  @method('delete')
  <div class="form-group">
        <label class="col-md-4 control-label" for="submit"></label>
        <div class="col-md-4">
          <button id="submit" name="submit" class="btn btn-primary">Delete</button>
        </div>
      </div>
</form>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    
<div>
  <a href="/locates">Show User</a>
</div>
@endsection