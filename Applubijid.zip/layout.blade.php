<div class="container">
	@yield('mainContent')
</div>