@extends('layout')

@section('mainContent')
	<hi>Show User</h1>
	<div style="color: {{$locate->color}}">
		<strong>{{$locate->Province}}</strong><br>
	</div>
		<p>{{$locate->City}}</p>
		<p>{{$locate->Purok}}</p>
	
	<a href="{{$locate->id}}/edit">Edit User</a>
@endsection