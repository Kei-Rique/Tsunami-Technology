@extends('layout')

@section('mainContent')
	<hi>Create User</h1>
		<form method="post" action="/locates">
		@csrf
  <label for="Province">Province:</label><br>
  <input type="text" id="Province" name="Province" ><br>
  <label for="City">City:</label><br>
  <input type="text" id="City" name="City" ><br><br>
  <label for="Purok">Purok:</label><br>
  <input type="text" id="Purok" name="Purok" ><br><br>
  <input type="submit" value="Submit">

</form>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
 	<div>
 		<a href="/locates">Show Users</a>
 	</div>
@endsection