<?php

use Illuminate\Support\Facades\Route;



Route::resource('locates', 'LocationController');

Route::get('/welcome', function () {
     return view('welcome');


});

Route::get('/login', function () {
     return view('login');

     
});

Route::get('/create1', function () {
     return view('create1');

     
});

