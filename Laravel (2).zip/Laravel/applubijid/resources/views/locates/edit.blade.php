@extends('layout')

@section('mainContent')
	<h1>Update/Delete User</h1>
		<form class="form-horizontal" method="post" action="/locates/{{$locate->id}}">
		@csrf
    @method('put')
    <fieldset>
      <legend></legend>
      <div class="form-group">
        <label class="col-md-4 control-label" for="Users">Users</label>
        <div class="col-md-4">
          <input id="Users" name="Users" type="text"
          placeholder="Enter Users" class="form-control
          input-md"value="{{$locate->Users}}">
        </div>
      </div>

<div class="form-group">
        <label class="col-md-4 control-label" for="province">Province</label>
        <div class="col-md-4">
          <input id="province" name="province" type="text"
          placeholder="Enter Users" class="form-control
          input-md"value="{{$locate->province}}">
        </div>
      </div>

 <div class="form-group">
        <label class="col-md-4 control-label" for="City">City</label>
        <div class="col-md-4">
          <input id="City" name="City" type="text"
          placeholder="Enter City" class="form-control
          input-md"value="{{$locate->City}}">
        </div>
      </div>

       <div class="form-group">
        <label class="col-md-4 control-label" for="Purok">Purok</label>
        <div class="col-md-4">
          <input id="Purok" name="Purok" type="text"
          placeholder="Enter Purok" class="form-control
          input-md"value="{{$locate->Purok}}">
        </div>
      </div>

<div class="form-group">
        <label class="col-md-4 control-label" for="street">Street</label>
        <div class="col-md-4">
          <input id="street" name="street" type="text"
          placeholder="Enter Users" class="form-control
          input-md"value="{{$locate->street}}">
        </div>
      </div>

      <div class="form-group">
        <label class="col-md-4 control-label" for="zone">Zone</label>
        <div class="col-md-4">
          <input id="zone" name="zone" type="text"
          placeholder="Enter Users" class="form-control
          input-md"value="{{$locate->zone}}">
        </div>
      </div>

      <div class="form-group">
        <label class="col-md-4 control-label" for="house_number">House Number</label>
        <div class="col-md-4">
          <input id="house_number" name="house_number" type="text"
          placeholder="Enter Users" class="form-control
          input-md"value="{{$locate->house_number}}">
        </div>
      </div>

      <div class="form-group">
        <label class="col-md-4 control-label" for="baranggay">Baranggay</label>
        <div class="col-md-4">
          <input id="baranggay" name="baranggay" type="text"
          placeholder="Enter Users" class="form-control
          input-md"value="{{$locate->baranggay}}">
        </div>
      </div>

      <div class="form-group">
        <label class="col-md-4 control-label" for="latitude">Latitude</label>
        <div class="col-md-4">
          <input id="latitude" name="latitude" type="text"
          placeholder="Enter Users" class="form-control
          input-md"value="{{$locate->latitude}}">
        </div>
      </div>

      <div class="form-group">
        <label class="col-md-4 control-label" for="longitude">Longitude</label>
        <div class="col-md-4">
          <input id="longitude" name="longitude" type="text"
          placeholder="Enter Users" class="form-control
          input-md"value="{{$locate->longitude}}">
        </div>
      </div>

 <div class="form-group">
       
        <div class="col-md-4">
          <button id="submit" name="submit" class="btn btn-primary">Update
           </button>
        </div>
      </div>
    </fieldset>
  </form>

<form class="form-horizontal" method="post" action="/locates/{{$locate->id}}">
  @csrf
  @method('delete')
  <div class="form-group">
        <label class="col-md-4 control-label" for="submit"></label>
        <div class="col-md-4">
          <button id="submit" name="submit" class="btn btn-primary">Delete</button>
        </div>
      </div>
</form>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    
<div>
  <a href="/locates">Show User</a>
</div>
@endsection