
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Test</title>
	
</head>
<body>

	<div class="container">
		@yield('content')
	</div>

	@yield('footer')
</body>
</html>
