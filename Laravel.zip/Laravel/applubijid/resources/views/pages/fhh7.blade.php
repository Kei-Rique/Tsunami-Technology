<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>{{$title}}</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i, 700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/line-awesome/css/line-awesome.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">


  <!-- Template Main CSS File -->
  <link href="assets/css/fhh7.css" rel="stylesheet">
</head>

<body>

  <!-- ======= IDENTIFICATION Section ======= -->
   <section id="about" class="about" style="background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:45px; color: black; margin-left: -391px; padding-bottom: 40px; font-family: Raleway; margin-top: -10px;"> 
              Hunger</p>
              </div>
              </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

  <!-- End IDENTIFICATION Section -->

                                        
        <!-- HOUSING CHARACTERISTICS 2 Services Section -->
        <form method="post" action="/fhh7">
                @csrf
               <section id="services" class="services" style=" background:#b7d8ef">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -135px; height: 210%; padding-bottom: 55px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;">

                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;">
                                  (148) In the last 3 months, did it happen even once that your household experienced hunger and did not have naything to eat?</label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q148" id="q148" name="q148" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > 3 years and above (GO TO 149)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q148" id="q148" name="q148" class="form-check-input" type="radio"   value="No">
                                  <label class="form-check-label"  > Not more than 3 years (GO TO 151)</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>

            <!-- HOUSING CHARACTERISTICS 2 Services Section -->
           

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 2px; font-weight: 600; font-size: 15px; margin-top: -170px; margin-left: -285px; width: 50rem;">
                           <br><b><b>During the past 3 months, how many days did your household  experience hunger and did not have anything to eat?</b></b>
                          </p>
                        </div>
                    </div></div></div></div>
</section>
  <section id="services2" class="services2" style=" background: #b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -192px; height: 90%; margin-left: -295px; width: 50rem; padding-bottom: 120px;background-color: #b7d8ef;" >

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 340px; width: 150px;">
                                  <b>(149) Name of Month</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group">
                              <label style="margin-left: 70px;">
                                  <b>(150) Name of Month</b></label><br>
                            </div> <!-- form-group end.// -->   
           </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px; margin-top: 20px; width: 320px;">
                                 a. First Month  </label><br>
                          </div>

                           <div class="col form-group" style="margin-top: 17px;">
                             <input for="q149_1" id="q149_1" name="q149_1" type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                          </div>    
                           <div class="col form-group" style="margin-top: 17px;">
                             <input for="q150_1" id="q150_1" name="q150_1" type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                          </div>    
                         </div>

                         <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-top: 20px; width: 320px;">
                                  b. Second Month </label><br>
                          </div>

                          <div class="col form-group" style="margin-top: 17px;">
                             <input for="q149_2" id="q149_2" name="q149_2" type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                          </div>    
                           <div class="col form-group" style="margin-top: 17px;">
                             <input for="q150_2" id="q150_2" name="q150_2" type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                          </div>    
                         </div>

                         <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 60px; margin-top: 20px; width: 320px;">
                                  c. Third Month </label><br>
                          </div>

                           <div class="col form-group" style="margin-top: 17px;">
                             <input for="q149_3" id="q149_3" name="q149_3" type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                          </div>    
                           <div class="col form-group" style="margin-top: 17px;">
                             <input for="q150_3" id="q150_3" name="q150_3" type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                          </div>    
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="about" class="about" style="background-color: white; margin-top:-180px;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:45px; color: black; margin-left: -141px; padding-bottom: 40px; font-family: Raleway; margin-top: -10px;"> 
              Household members who died</p>
              </div>
              </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->
               <section id="services" class="services" style=" background:white; margin-top:-100px; margin-bottom: -120px;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: 20px; height: 60%; padding-bottom: 75px; margin-left: -295px; width: 50rem; margin-top: -20px;" >

                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                 <b> (151) Were there any household members who died in the past 12 months?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q151" id="q151" name="q151" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes (GO TO 152)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q151" id="q151" name="q151" class="form-check-input" type="radio"   value="No">
                                  <label class="form-check-label"  > No (GO TO 156 )</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>

               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
                  
    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services" style=" background: white; margin-bottom: -170px; ">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -65px; height: 80%; padding-bottom: 100px; margin-left: -295px; width: 50rem; background-color: white;" >
                      
                       
                         <div class="form-row" style="font-size: 11px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>(152) What is the name of the person who died?</b></label><br>
                            </div>
                            <div class="col form-group">
                                <label style="margin-left: 40px;margin-bottom: 1px; ">
                                  <b>(153)What is _____’s sex?</b></label>
                            </div>
                            <div class="col form-group">
                              <label style="margin-left: 40px;margin-bottom: 1px; ">
                                  <b>(154) What was ____’s age at the time of death?</b></label><br>
                            </div>
                            <div class="col form-group">
                                <label style="margin-left: 30px;margin-bottom: 1px; ">
                                  <b>(155) What was the cause of ____’s death?</b></label>
                            </div>

                        </div> <!-- form-row end.// -->

                        <div class="form-row" style="font-size: 11px; margin-top: 40px;">

                            
<div class="col form-group">
                            <input for="q152_1" id="q152_1" name="q152_1" type="text" class="form-control1" style="margin-left: 50px; width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-left: 95px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q153_1" id="q153_1" name="q153_1" class="form-check-input" type="radio"   value="Male">
                                  <label class="form-check-label"  > Male </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q153_1" id="q153_1" name="q153_1" class="form-check-input" type="radio"   value="Female">
                                  <label class="form-check-label"  >  Female </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input for="q154_1" id="q154_1" name="q154_1" type="text" class="form-control1" style="margin-left: 35px; width: 100px; height: 20px;"placeholder="">
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select for="q155_1" id="q155_1" name="q155_1"required style="margin-left: 30px; margin-top: -10px; width: 100px; font-size: 10px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                        
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px; margin-top: 30px;">

                        
                           <div class="col form-group">
                            <input for="q152_2" id="q152_2" name="q152_2" type="text" class="form-control1" style="margin-left: 50px; width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-left: 95px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q153_2" id="q153_2" name="q153_2" class="form-check-input" type="radio"   value="Male">
                                  <label class="form-check-label"  > Male </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q153_2" id="q153_2" name="q153_2" class="form-check-input" type="radio"   value="Female">
                                  <label class="form-check-label"  >  Female </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input for="q154_2" id="q154_2" name="q154_2" type="text" class="form-control1" style="margin-left: 35px; width: 100px; height: 20px;"placeholder="">
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select for="q155_2" id="q155_2" name="q155_2"required style="margin-left: 30px; margin-top: -10px; width: 100px; font-size: 10px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                        
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px; margin-top: 30px;">

                           
<div class="col form-group">
                            <input for="q152_3" id="q152_3" name="q152_3" type="text" class="form-control1" style="margin-left: 50px; width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-left: 95px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q153_3" id="q153_3" name="q153_3" class="form-check-input" type="radio"   value="Male">
                                  <label class="form-check-label"  > Male </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q153_3" id="q153_3" name="q153_3" class="form-check-input" type="radio"   value="Female">
                                  <label class="form-check-label"  >  Female </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input for="q154_3" id="q154_3" name="q154_3" type="text" class="form-control1" style="margin-left: 35px; width: 100px; height: 20px;"placeholder="">
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select for="q155_3" id="q155_3" name="q155_3"required style="margin-left: 30px; margin-top: -10px; width: 100px; font-size: 10px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                        
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->


              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>

              
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
              <section id="about" class="about" style="background-color: #b7d8ef; margin-top: 50px;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:45px; color: black; margin-left: -391px; padding-bottom: 40px; font-family: Raleway; margin-top: -20px;"> 
              Programs</p>
              </div>
              </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->
<section id="about" class="about" style="background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:15px; color: black; margin-left: -391px; padding-bottom: 40px; font-family: Raleway; margin-top: -120px;"> 
              (156) During the past 12 months, did you or any<br> member of your household receive or avail of any of<br> the following programs?</p>
              </div>
              </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->
  <!-- End IDENTIFICATION Section -->

                                        
        <!-- HOUSING CHARACTERISTICS 2 Services Section -->

               <section id="services" class="services" style=" background:#b7d8ef">
                   
>
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="container" style="padding-top: 28px; padding-left: 10px; margin-top: -155px; height: 40px; ; margin-left: 100px; width: 25rem; background-color: #6bb9ef; border-color: transparent;"> 
                       
                         <div class="form-row">

                            <div class="col form-group" style="margin-top: -4px; ">
                            <div class="dropdown">
                        <select required style="margin-left: 5px; width: 350px; font-size: 10px; height: 25px;">
                          <option value=""disabled>Type of program...</option>
                          <option value="Yes">Fully-owned</option>
                          <option value="No">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                         </select>
                     </div>
                         
                         </div> <!-- form-row end.// -->

              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>

               <section id="services" class="services" style=" background:#b7d8ef;">
                   
>
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="container" style="padding-top: 28px; padding-left: 10px; margin-top: -253px; height: 40px; ; margin-left: 117px; width: 23rem; background-color: #e6eaee; border-color: gray;">
                       
                         <div class="form-row">

                            <div class="col form-group" style="margin-top: -13px; ">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 350px; font-size: 10px;"placeholder="Name of the program...">
                          </div>  
                         </div> <!-- form-row end.// -->

              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>

                   <div class="container" style="padding-top: 28px; padding-left: 10px; margin-top: 10px; height: 40px; ; margin-left: 117px; width: 23rem; background-color: #e6eaee; border-color: gray;">
                       
                         <div class="form-row">

                            <div class="col form-group" style="margin-top: -13px; ">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 350px; font-size: 10px;"placeholder="How many household members are benefiting from the program...">
                          </div>  
                         </div> <!-- form-row end.// -->

              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>

                    <div class="container" style="padding-top: 28px; padding-left: 10px; margin-top: 10px; height: 40px; ; margin-left: 117px; width: 23rem; background-color: #e6eaee; border-color: gray;">
                       
                         <div class="form-row">

                            <div class="col form-group" style="margin-top: -13px; ">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 350px; font-size: 10px;"placeholder="Name of household benefiting from the program...">
                          </div>  
                         </div> <!-- form-row end.// -->

              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>

                    <div class="container" style="padding-top: 28px; padding-left: 10px; margin-top: 10px; height: 40px; ; margin-left: 117px; width: 23rem; background-color: #e6eaee; border-color: gray;">
                         <div class="form-row">

                            <div class="col form-group" style="margin-top: -13px; ">
                           <div class="dropdown">
                        <select required style="margin-left: 5px; width: 350px; font-size: 10px; height: 25px;">
                          <option value=""disabled>Who implemented the program?</option>
                          <option value="Yes">Fully-owned</option>
                         </select>
                     </div>
                          </div>  
                         </div> <!-- form-row end.// -->

              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>

                   <div class="container" style="padding-top: 28px; padding-left: 10px; margin-top: 17px; height: 40px; ; margin-left: 100px; width: 25rem; background-color: #6bb9ef; border-color: transparent;">
                      
                       
                         <div class="form-row">

                            <div class="col form-group" style="margin-top: -13px; ">
                            <div class="dropdown">
                        <select required style="margin-left: 5px; width: 350px; font-size: 10px; height: 25px;">
                          <option value=""disabled>Type of program...</option>
                          <option value="Yes">Fully-owned</option>
                          <option value="No">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                         </select>
                     </div>
                          </div>  
                         </div> <!-- form-row end.// -->

              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>
               <!-- ======= NEXT PAGE BUTTON Section ======= -->
       <section id="testimonials" class="testimonials section-bg" style="margin-top: -80px;">
         <div class="container">
            <div class="form-group">
              <button type="submit" class="btn btn-primary btn-block"> Submit Form </button>
            </div> <!-- form-group// -->
          </div>
       </section>
       </html>
     </body>

        <!-- End NEXT PAGE BUTTON Section -->
