<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>{{$title}}</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i, 700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/line-awesome/css/line-awesome.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">


  <!-- Template Main CSS File -->
  <link href="assets/css/fhh7.css" rel="stylesheet">
</head>

<body>

  <!-- ======= IDENTIFICATION Section ======= -->
   <section id="about" class="about" style="background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:45px; color: black; margin-left: -391px; padding-bottom: 40px; font-family: Raleway; margin-top: -10px;"> 
              Hunger</p>
              </div>
              </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

  <!-- End IDENTIFICATION Section -->

                                        
        <!-- HOUSING CHARACTERISTICS 2 Services Section -->

               <section id="services" class="services" style=" background:#b7d8ef">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -135px; height: 210%; padding-bottom: 45px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;">

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  (148) In the last 3 months, did it happen even once that your household experienced hunger and did not have naything to eat?</label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> 3 years and above (GO TO 149)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> Not more than 3 years (GO TO 151)</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>

            <!-- HOUSING CHARACTERISTICS 2 Services Section -->
           

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 2px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                           <br><b><b>During the past 3 months, how many days did your household  experience hunger and did not have anything to eat?</b></b>
                          </p>
                        </div>
                    </div></div></div></div>
</section>
  <section id="services2" class="services2" style=" background: #b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -172px; height: 90%; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 340px;margin-bottom: 33px; width: 150px;">
                                  <b>(149) Name of Month</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group">
                              <label style="margin-left: 70px;margin-bottom: 33px;">
                                  <b>(150) Name of Month</b></label><br>
                            </div> <!-- form-group end.// -->   
           </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 60px; margin-top: 20px; width: 320px;">
                                 a. First Month  </label><br>
                          </div>

                           <div class="col form-group" style="margin-top: 17px;">
                             <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                          </div>    
                           <div class="col form-group" style="margin-top: 17px;">
                             <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                          </div>    
                         </div>

                         <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 60px; margin-top: 20px; width: 320px;">
                                  b. Second Month </label><br>
                          </div>

                          <div class="col form-group" style="margin-top: 17px;">
                             <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                          </div>    
                           <div class="col form-group" style="margin-top: 17px;">
                             <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                          </div>    
                         </div>

                         <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 60px; margin-top: 20px; width: 320px;">
                                  c. Third Month </label><br>
                          </div>

                           <div class="col form-group" style="margin-top: 17px;">
                             <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                          </div>    
                           <div class="col form-group" style="margin-top: 17px;">
                             <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                          </div>    
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="about" class="about" style="background-color: white; margin-top:-180px;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:45px; color: black; margin-left: -141px; padding-bottom: 40px; font-family: Raleway; margin-top: -10px;"> 
              Household members who died</p>
              </div>
              </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->
               <section id="services" class="services" style=" background:white; margin-top:-100px; margin-bottom: -120px;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: 20px; height: 60%; padding-bottom: 65px; margin-left: -295px; width: 50rem; margin-top: -20px;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                 <b> (151) Were there any household members who died in the past 12 months?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes (GO TO 152)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No (GO TO 156 )</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>

               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
                  
    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services" style=" background: white; margin-bottom: -170px; ">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -65px; height: 80%; padding-bottom: 10px; margin-left: -295px; width: 50rem; background-color: white;" >

                      <form>
                       
                         <div class="form-row" style="font-size: 11px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>(152) What is the name of the person who died?</b></label><br>
                            </div>
                            <div class="col form-group">
                                <label style="margin-left: 40px;margin-bottom: 1px; ">
                                  <b>(153)What is _____’s sex?</b></label>
                            </div>
                            <div class="col form-group">
                              <label style="margin-left: 40px;margin-bottom: 1px; ">
                                  <b>(154) What was ____’s age at the time of death?</b></label><br>
                            </div>
                            <div class="col form-group">
                                <label style="margin-left: 40px;margin-bottom: 1px; ">
                                  <b>(155) What was the cause of ____’s death?</b></label>
                            </div>

                        </div> <!-- form-row end.// -->

                        <div class="form-row" style="font-size: 11px; margin-top: 40px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>1. Typhoon</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top:-10px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select required style="margin-left: 30px; margin-top: -10px; width: 100px; font-size: 10px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px; margin-top: 30px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>2. Flood</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top:-10px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select required style="margin-left: 30px; margin-top: -10px; width: 100px; font-size: 10px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px; margin-top: 30px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>3. Drought</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top:-10px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select required style="margin-left: 30px; margin-top: -10px; width: 100px; font-size: 10px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->


              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>

              
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
              <section id="about" class="about" style="background-color: #b7d8ef; margin-top: 50px;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:45px; color: black; margin-left: -391px; padding-bottom: 40px; font-family: Raleway; margin-top: -20px;"> 
              Programs</p>
              </div>
              </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->
<section id="about" class="about" style="background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:15px; color: black; margin-left: -391px; padding-bottom: 40px; font-family: Raleway; margin-top: -120px;"> 
              (156) During the past 12 months, did you or any<br> member of your household receive or avail of any of<br> the following programs?</p>
              </div>
              </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->
  <!-- End IDENTIFICATION Section -->

                                        
        <!-- HOUSING CHARACTERISTICS 2 Services Section -->

               <section id="services" class="services" style=" background:#b7d8ef">
                   
>
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="container" style="padding-top: 28px; padding-left: 10px; margin-top: -155px; height: 40px; ; margin-left: 100px; width: 25rem; background-color: #6bb9ef; border-color: transparent;"> 
                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group" style="margin-top: -4px; ">
                            <div class="dropdown">
                        <select required style="margin-left: 5px; width: 350px; font-size: 10px; height: 25px;">
                          <option value=""disabled>Type of program...</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                         </select>
                     </div>
                         
                         </div> <!-- form-row end.// -->

              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>

               <section id="services" class="services" style=" background:#b7d8ef;">
                   
>
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="container" style="padding-top: 28px; padding-left: 10px; margin-top: -253px; height: 40px; ; margin-left: 117px; width: 23rem; background-color: #e6eaee; border-color: gray;">
                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group" style="margin-top: -13px; ">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 350px; font-size: 10px;"placeholder="Name of the program...">
                          </div>  
                         </div> <!-- form-row end.// -->

              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>

                   <div class="container" style="padding-top: 28px; padding-left: 10px; margin-top: 10px; height: 40px; ; margin-left: 117px; width: 23rem; background-color: #e6eaee; border-color: gray;">
                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group" style="margin-top: -13px; ">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 350px; font-size: 10px;"placeholder="How many household members are benefiting from the program...">
                          </div>  
                         </div> <!-- form-row end.// -->

              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>

                    <div class="container" style="padding-top: 28px; padding-left: 10px; margin-top: 10px; height: 40px; ; margin-left: 117px; width: 23rem; background-color: #e6eaee; border-color: gray;">
                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group" style="margin-top: -13px; ">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 350px; font-size: 10px;"placeholder="Name of household benefiting from the program...">
                          </div>  
                         </div> <!-- form-row end.// -->

              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>

                    <div class="container" style="padding-top: 28px; padding-left: 10px; margin-top: 10px; height: 40px; ; margin-left: 117px; width: 23rem; background-color: #e6eaee; border-color: gray;">
                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group" style="margin-top: -13px; ">
                           <div class="dropdown">
                        <select required style="margin-left: 5px; width: 350px; font-size: 10px; height: 25px;">
                          <option value=""disabled>Who implemented the program?</option>
                          <option value="1">Fully-owned</option>
                         </select>
                     </div>
                          </div>  
                         </div> <!-- form-row end.// -->

              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>

                   <div class="container" style="padding-top: 28px; padding-left: 10px; margin-top: 17px; height: 40px; ; margin-left: 100px; width: 25rem; background-color: #6bb9ef; border-color: transparent;">
                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group" style="margin-top: -13px; ">
                            <div class="dropdown">
                        <select required style="margin-left: 5px; width: 350px; font-size: 10px; height: 25px;">
                          <option value=""disabled>Type of program...</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                         </select>
                     </div>
                          </div>  
                         </div> <!-- form-row end.// -->

              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>
               <!-- ======= NEXT PAGE BUTTON Section ======= -->
       <section id="testimonials" class="testimonials section-bg" style="margin-top: -80px;">
         <div class="container">
            <div class="form-group">
              <button type="submit" class="btn btn-primary btn-block"> <a href="/ty"> SUBMIT FORM</a> </button>
            </div> <!-- form-group// -->
          </div>
       </section>

        <!-- End NEXT PAGE BUTTON Section -->
