<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>{{$title}}</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i, 700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/line-awesome/css/line-awesome.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">


  <!-- Template Main CSS File -->
  <link href="assets/css/fhh1.css" rel="stylesheet">

</head>

<body>
  <!-- ======= IDENTIFICATION Section ======= -->
  <section id="about" class="about">
    <div class="page-wrap">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:45px; color: black; margin-left: -471px; font-family: Raleway;"> 
              HOUSEHOLD INFORMATION </p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </div>
  </section><!-- End IDENTIFICATION Section -->

  <!-- ======= LOCATION Section ======= -->
  <section id="counts" class="counts">
    <div class="page-wrap">
    <div class="container">

      <div class="row counters">

        <div class="row justify-content-center" style=" background: #b7d8ef;">
          <div class="col-md-6">
            <div class="card" style=" background: #b7d8ef; border-color: transparent; margin-left: -295px; margin-top: 40px; margin-bottom: 30px; width: 50rem; ">

              <form>
                <p style="font-weight: bolder; font-size:30px; color: black; margin-top: 17px; margin-left: 14px;"> <b> Demography </b></p>
               
              <div class="demog">
                <div class="form-row" style="margin-bottom: 15px;">
                  <div class="col form-group">
                    <label>(1) Surname </label>   
                    <input type="text" class="form-control" placeholder="">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group1" style="margin-left: 20px;">
                    <label> (2) First Name</label>   
                    <input type="text" class="form-control" placeholder="">
                  </div> <!-- form-group end.//-->

                  <div class="col form-group1" style="margin-left: 20px;">
                    <label> (3) Middle Name</label>   
                    <input type="text" class="form-control" placeholder="">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group">
                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                <div class="form-row" style="margin-bottom: 5px;">
                  <div class="col form-group">
                    <label>(4) Date of Birth</label> 
                    <input type="Date" class="form-control" placeholder="mm/dd/yyyy" style="margin-top: 35px;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group1" style="margin-left: 15px;">
                    <label>(5) Age </label>   
                    <input type="number" class="form-control" placeholder="" style="width: 80px; margin-top: 35px;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group1" style="margin-left: 20px;">
                    <label style="width: 150px;">(6) Sex <br> 1 - male 2 - female</label>   
                    <input type="number" class="form-control" placeholder="" style="width: 80px; margin-top: 13px;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group1" style="margin-left: 20px;">
                    <label style="width: 200px;">(7) In which nuclear family do you belong?</label>   
                    <input type="text" class="form-control" placeholder="" style="width: 80px; margin-top: 13px;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group">
                    <label> <br> </label>   
                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                <div class="form-row" style="margin-bottom: 15px;">
                  <div class="col form-group">
                    <label>(8) What is your relationship to the head of the household? </label>   

                    <div class="dropdown">
                      <select required style="font-size: 13px;margin-top: 23px;">
                        <option value="" disabled="">Select your option</option>
                        <option value="1">Head </option>
                        <option value="2">Spouse </option>
                        <option value="3">Son/Daughter</option>
                        <option value="4">Son/Daughter-in-law</option>
                        <option value="5">Grandchildren</option>
                        <option value="6">Parents</option>
                        <option value="7">Other relatives, specify</option>
                        <option value="8">Housemaid/boy</option>
                        <option value="9">Others, specify</option>
                      </select>
                    </div>
                  </div> <!-- form-group end.// -->

                  
                  <div class="col form-group" style="margin-left: 140px;">
                    <label>(9) Was your birth registered with the civil registry office?<br> 1 - Yes 2 - No</label>   
                    <input type="number" class="form-control" placeholder="">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group">
                    <label> <br> </label>
                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                <div class="form-row" style="margin-bottom: 15px;">
                  <div class="col form-group">
                    <label>(10) <b>FOR 10 YEARS OLD AND ABOVE </b> What is your marital (civil) status? </label>   
                    
                    <div class="dropdown">
                      <select style="margin-top: 7px; font-size: 10px;" required>
                        <option value="" disabled="">Select your option</option>
                        <option value="1">Single </option>
                        <option value="2">Married </option>
                        <option value="3">Widowed </option>
                        <option value="4">Divorced/Separated</option>
                        <option value="5">Common-law/Live-in</option>
                        <option value="6">Unknown</option>
                      </select>
                    </div>
                  </div> <!-- form-group end.// -->

                  <div class="col form-group" style="margin-left: 140px;">
                    <label>(11) What is your Ethnicity by blood? <i style="font-size: 10px;"> Mention the predominant/common IP or NON-IP Groups in the area </i> </label>   
                    <input type="text" class="form-control" placeholder="">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group">
                    <label> <br> </label>


                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                <div class="form-row">
                  <div class="col form-group">
                    <label>(12) <b>IF A MEMBER IS AN OFW AND <br> AGE IS 10 YEARS OLD AND ABOVE <br></b> Are you an overseas worker? <br><br> 1 - yes (proceed to <b> (18) </b>) 2 - no </label>   
                    <input type="number" class="form-control" placeholder="" style="margin-top: 23px;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group" style="margin-left: -10px;">
                    <label>(13) <b>FOR 3 YEARS OLD AND ABOVE</b><br> Where were you residing 3 years ago? <br><br> 1 - same address now  <br>2 - other address, specify </label>   
                    <input type="number" class="form-control" placeholder="" style="margin-top: 23px;">
                  </div> <!-- form-group end.// -->
</div>
                </div>

              </form>
            </article> <!-- card-body end .// -->

          </div> <!-- col.//-->

        </div> <!-- row.//-->

        <!--container end.//-->

        <br><br>

      </div>

    </div>
  </div>
  </section><!-- End LOCATION Section -->


  <!-- ======= HOUSING CHARACTERISTICS 1 Section ======= -->
  <section id="clients" class="clients section-bg">
    <div class="container">

        <div class="row justify-content-center" >
          <div class="col-md-6" >
            <div class="card" style=" background: #ffffff; border-color: transparent; margin-left: -300px; margin-top: 35px; margin-bottom: 30px; width: 50rem;">

              <form>
                <p style="font-weight: bolder; font-size:30px; color: black; margin-top: 1px; margin-left: -440px; font-family: Raleway; text-align: center;"> <b>Education and Literacy</b> </p>

                <div class="educ">
                <div class="form-row" style="">
                  <div class="col form-group">
                    <label style="margin-bottom: 25px;">(14) Are you currently attending school?<br> 1 - Yes (leave <b> (17)</b> blank ) 2 - No (skip to<b> (17
                    )</b>) </label>   
                    <input type="number" class="form-control1" placeholder="">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group">
                    <label> <br> </label>
                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                        </div>

                  </div>
                      </div>
                </form>
              </article> <!-- card-body end .// -->

            </div> <!-- col.//-->
          </div>
        </section>

        <!-- End HOUSING CHARACTERISTICS 1 Section -->
        <section id="clients" class="clients section-bg">
    <div class="container">

        <div class="row justify-content-center" >
          <div class="col-md-6" >
            <div class="card" style=" background: #ffffff; border-color: black; width: 81rem; margin-left: -300px; margin-top: -20px; padding-bottom: 20px; width: 50rem;" >

              <form>
                

                <div class="educ">
                <div class="form-row">
                  <p style="margin: 30px 10px; margin-bottom: 20px;"> <b>For 3 years old and above</b>
                  </p></div>


                  <div class="form-row">
                    <div class="col form-group">
                      <label>(15) What grade or year are you currently attending? </label>   

                      <div class="dropdown">
                        <select style="width: 300px; height: 30px;   border-radius: 0px; background-color: white; margin-top: 3px; "required>
                          <option value="" disabled="">Select your option</option>
                          <option value="0">No Grade </option>
                          <option value="01">Daycare </option>
                          <option value="02">Kindergarten/Preparatory</option>
                          <option value="11">Grade I</option>
                          <option value="12">Grade II</option>
                          <option value="13">Grade III</option>
                          <option value="14">Grade IV</option>
                          <option value="15">Grade V</option>
                          <option value="16">Grade VI</option>
                          <option value="17">Grade 7 </option>
                          <option value="18">Grade 8 </option>
                          <option value="19">Grade 9/3rd Year HS</option>
                          <option value="20">Grade 10/4th Year HS</option>
                          <option value="21">Grade 11</option>
                          <option value="22">Grade 12</option>
                          <option value="23">1st Year PS/N-T/TV</option>
                          <option value="24">2nd Year PS/N-T/TV</option>
                          <option value="25">3rd Year PS/N-T/TV</option>
                          <option value="31">1st Year College </option>
                          <option value="32">2nd Year College </option>
                          <option value="33">3rd Year College</option>
                          <option value="34">4th Year College or higher</option>
                          <option value="41">Post Grad w/ units</option>
                          <option value="51">ALS Elementary</option>
                          <option value="52">ALS Secondary</option>
                          <option value="53">SPED Elementary</option>
                          <option value="54">SPED Secondary</option>
                          <option value="hurr">Grade school graduate</option>
                          <option value="hurr">High school graduate</option>
                          <option value="hurr">Post secondary graduate,specify course</option>
                          <option value="hurr">College graduate,specify course</option>
                          <option value="hurr">Masters/PhD graduate,specify course</option>
                        </select>
                      </div>
                    </div> <!-- form-group end.// -->


                    <div class="col form-group" style="margin-left: 100px;">
                      <label style="width: 250px;">(16) Where do you attend school? <br> 1 - public 2 - private</label>   
                      <input type="number" class="form-control1" placeholder="">
                    </div> <!-- form-group end.// -->

                    <div class="col form-group">
                      <label> <br> </label>
                    </div> <!-- form-group end.// -->
                  </div> <!-- form-row end.// -->

                  <div class="form-row" style="margin-top: 20px;">
                    <div class="col form-group">
                      <label>(17) Why are you not attending school? </label>   

                      <div class="dropdown">
                        <select style="margin-top: 45px; font-size: 10px;"required >
                          <option value=""disabled>Select your option</option>
                          <option value="1">Schools are very far </option>
                          <option value="2">No school within the bgy </option>
                          <option value="3">No regular transportation</option>
                          <option value="4">High cost of education </option>
                          <option value="5">Illness/Disability</option>
                          <option value="6">Housekeeping/Taking care of siblings</option>
                          <option value="7">Marriage</option>
                          <option value="8">Employment/looking for work</option>
                          <option value="9">Lack of personal interest</option>
                          <option value="10">Cannot cope with school work </option>
                          <option value="11">Finished schooling </option>
                          <option value="12">Problem with school record</option>
                          <option value="13">Problem with birth certificate</option>
                          <option value="14">Too young to go to school</option>
                          <option value="15">Others, specify</option> </select>
                        </div>
                      </div> <!-- form-group end.// -->


                  <div class="col form-group" style="margin-left: 100px;">
                      <label style="width: 300px">(18) What is the highest educational attainment you have completed? If you are a college graduate, what is your course?</label>   

                        <div class="dropdown">
                        <select style="width: 300px;   margin-top: 3px;"required>
                          <option value="" disabled="">Select your option</option>
                          <option value="0">No Grade </option>
                          <option value="01">Daycare </option>
                          <option value="02">Kindergarten/Preparatory</option>
                          <option value="11">Grade I</option>
                          <option value="12">Grade II</option>
                          <option value="13">Grade III</option>
                          <option value="14">Grade IV</option>
                          <option value="15">Grade V</option>
                          <option value="16">Grade VI</option>
                          <option value="17">Grade 7 </option>
                          <option value="18">Grade 8 </option>
                          <option value="19">Grade 9/3rd Year HS</option>
                          <option value="20">Grade 10/4th Year HS</option>
                          <option value="21">Grade 11</option>
                          <option value="22">Grade 12</option>
                          <option value="23">1st Year PS/N-T/TV</option>
                          <option value="24">2nd Year PS/N-T/TV</option>
                          <option value="25">3rd Year PS/N-T/TV</option>
                          <option value="31">1st Year College </option>
                          <option value="32">2nd Year College </option>
                          <option value="33">3rd Year College</option>
                          <option value="34">4th Year College or higher</option>
                          <option value="41">Post Grad w/ units</option>
                          <option value="51">ALS Elementary</option>
                          <option value="52">ALS Secondary</option>
                          <option value="53">SPED Elementary</option>
                          <option value="54">SPED Secondary</option>
                          <option value="hurr">Grade school graduate</option>
                          <option value="hurr">High school graduate</option>
                          <option value="hurr">Post secondary graduate,specify course</option>
                          <option value="hurr">College graduate,specify course</option>
                          <option value="hurr">Masters/PhD graduate,specify course</option>
                        </select>
                      </div>
                      </div> <!-- form-group end.// -->

                      <div class="col form-group">
                        <label> <br> </label>
                      </div> <!-- form-group end.// -->
                    </div> <!-- form-row end.// -->
                        </div>

</div>
                      </div>


                </form>
              </article> <!-- card-body end .// -->

            </div> <!-- col.//-->
          </div>
        </section>

        <!-- End HOUSING CHARACTERISTICS 1 Section -->
         <section id="clients" class="clients section-bg">
    <div class="container">

        <div class="row justify-content-center" >
          <div class="col-md-6" >
            <div class="card" style=" background: #ffffff; border-color: black; width: 81rem; margin-left: -300px; margin-top: -40px; padding-bottom: 20px; width: 50rem;" >

              <form>
                

                <div class="educ">
                    <div class="form-row" style="margin-top: 15px;">
                      <p style="margin: 20px 10px; margin-bottom: 20px;"> <b>For 5 years old and above</b>
                      </p>
                    </div>

                      <div class="form-row">
                        <div class="col form-group">
                          <label style="width: 700px">(19) Can you read and write a simple message in any language or dialect? <br><br> 1 - Yes   2 - No </label>   
                          <input type="text" class="form-control1" placeholder="">
                        </div> <!-- form-group end.// -->

                        <div class="col form-group">
                          <label> <br> </label>


                        </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                        </div>

</div>
                      </div>


                </form>
              </article> <!-- card-body end .// -->

            </div> <!-- col.//-->
          </div>
        </section>

        <!-- End HOUSING CHARACTERISTICS 1 Section -->

          <section id="clients" class="clients section-bg">
    <div class="container">

        <div class="row justify-content-center" >
          <div class="col-md-6" >
            <div class="card" style=" background: #ffffff; border-color: black; width: 81rem; margin-left: -300px; margin-top: -40px; margin-bottom: 30px; padding-bottom: 20px; width: 50rem;" >

              <form>
                

                <div class="educ">
                    <div class="form-row">
                      <p style="margin: 30px 10px; margin-bottom: 20px;"> <b>For 15 years old and above</b>
                      </p>
                    </div>

                      <div class="form-row">
                        <div class="col form-group">
                          <label style="width: 700px">(20) Are you a registered voter? <br><br> 1 - Yes   2 - No (skip to <b>(22)</b>) </label>   
                          <input type="text" class="form-control1" placeholder="">
                        </div> <!-- form-group end.// -->

                         <div class="col form-group" style="margin-left: 1px; ">
                          <label style="width: 700px">(21) Did you vote in the last election? <b> If OFW go to next number</b> <br><br> 1 - Yes 2 - No  3 - I don't know </label>   
                          <input type="text" class="form-control1" placeholder="">
                        </div> <!-- form-group end.// -->

                        <div class="col form-group">
                          <label> <br> </label>


                        </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                        </div>

</div>
                      </div>


                </form>
              </article> <!-- card-body end .// -->

            </div> <!-- col.//-->
          </div>
        </section>

        <!-- End HOUSING CHARACTERISTICS 1 Section -->

        <!-- ======= HOUSING CHARACTERISTICS 2 Section ======= -->
        <section id="services" class="services"style=" background: #b7d8ef">
          <div class="container">

            <div class="row counters">
          
              <div class="row justify-content-center" >
                <div class="col-md-6" >
                  <p style="font-weight: bolder; font-size:30px; color: black; margin-top: 1px; margin-left: -540px; font-family: Raleway; text-align: center;"><B> Economic Activity </B></p>

                  <div class="card" style="padding-bottom: 1px; padding-top: 18px; padding-left: 10px; height:92%;margin-bottom: -68px; margin-left: -300px; width: 50rem;" >

                    <form>
                      <div class="form-row">
                        <p style="margin: 2px 20px; margin-bottom: 20px; color: black; font-weight: 600;"> <b>For 5 years old and above</b>
                        </p></div>


                        <div class="form-row">

                          <div class="col form-group">
                            <label style="width: 250px;">(22) Did you do any work for at <br> least 1 hour during the past week?<br><br><br> 1 - yes 2 - no (skip to <b>(22)</b>)</label>   <br>
                            <input type="number" class="form-control" placeholder="" style="width: 150px;"><br>
                          </div> <!-- form-group end.// --> 

                          <div class="col form-group" style="margin-left: 20px;">
                            <label>(23) Although you did not work, did you have a job or business during the past week? <br><br> 1 - yes 2 - no (skip to <b>(32)</b>)</label>   <br>
                            <input type="number" class="form-control" placeholder="" style="width: 150px;">
                          </div> <!-- form-group end.// -->

                          <div class="col form-group" style="margin-left: 20px;">
                            <label>(24) How many work, jobs<br> or businesses do you have? </label>   <br>
                            <input type="number" class="form-control" placeholder="" style="width: 150px; margin-top: 65px;">
                          </div> <!-- form-group end.// -->

                        </div>

                        <div class="form-row">

                          <div class="col form-group">

                            <label style="margin-left: 5px; width: 270px;">
                              (25) What was your primary occupation during the past week <br><br><br> (SPECIFY OCCUPATION, E.G.,<br> ELEMENTARY TEACHER, RICE<br> FARMER, ETC.) </label>   <br>
                              <input class="form-control" type="text">
                          </div> <!-- form-group end.// -->

                          <div class="col form-group" style="margin-left: -40px">

                              <label style="margin-left: 5px; width: 290px;">
                                (26) In what kind of industry did you work during the past week? <br><br><br> (SPECIFY INDUSTRY, E.G.,<br> PRIMARY/ELEMENTARY EDUCATION, GROWING PADDY RICE, ETC) </label>   
                                <br>

                                <input class="form-control" type="text">
                          </div> <!-- form-group end.// -->
                        </div> <!-- form-row end.// -->


                            <div class="col form-group">
                              <label> <br> </label>

                            </div> <!-- form-group end.// -->
                          </div> <!-- form-row end.// -->

                        </div>
                      </section>

      <!-- HOUSING CHARACTERISTICS 2 Services Section -->

       <section id="services" class="services"style=" background: #b7d8ef">
            <div class="container">

                <div class="row counters">
                        

                   <div class="row justify-content-center" >
                     <div class="col-md-6">
                        <div class="card" style="padding-top: 18px; padding-left: 10px; margin-top: -50px; height: 130%; margin-bottom:-150px; width: 50rem; margin-left: -300px;" >

                       <form>
                           <div class="form-row">
                              <p style="margin: 2px 20px; margin-bottom: 48px; font-weight: 600"> <b>For 15 years old and above</b>
                                      </p></div>


                          <div class="form-row">
                             <div class="col form-group">
                               <label style="margin-left: 5px;">
                                      (27) What is your nature<br> of employment? </label><br>


                                    <div class="dropdown">
                                      <select style="margin-bottom: 90px; width: 60%;" required>
                                        <option value=""disabled>Select your option</option>
                                         <option value="1">Permanent job/business/unpaid family work </option>
                                         <option value="2">Short-term or seasonal or casual job/business/unpaid family work </option>
                                         <option value="3">Worked for different employers or customers on day-to-day or week-to-week basis</option>
                                      </select>
                                    </div>



                             </div> <!-- form-group end.// -->

                             <div class="col form-group" style="margin-left: -110px">
                                <label style="margin-left: 5px; margin-bottom: 12px;">
                                        (28) What was your normal working hours<br> per day during the past week? </label><br>

                                    
                                    <input class="form-control" type="number">

                            </div> <!-- form-group end.// -->
                          </div> <!-- form-row end.// -->

                          <div class="form-row">
<div class="page-wrap">
                            <div class="col form-group">
                                <label style="margin-left: 5px">
                                       (29) What was your total number <br> of hours worked during the past week? </label><br>

                                    <input class="form-control" type="number">
                           </div> <!-- form-group end.// -->
</div>
                             <div class="col form-group" style="margin-left: 50px">
                                <label style="margin-left: 5px; margin-bottom: 18px;">
                                       (30) Did you want more hours of<br> work  during the past week? 
                                </label><br>

                             <div class="form-check form-check-inline">
                                   <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                       <label class="form-check-label" for="inlineCheckbox1"> Yes</label></div>
                             <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                       <label class="form-check-label" for="inlineCheckbox2"> No</label>
                                        </div>
                            </div> <!-- form-group end.// -->
                          </div> <!-- form-row end.// -->


                           <div class="col form-group">
                              <label> <br> </label>
                                              </div> <!-- form-group end.// -->
                                            </div> <!-- form-row end.// -->

                                          </div>
                                        </section>
                                        
        <!-- HOUSING CHARACTERISTICS 2 Services Section -->

               <section id="services" class="services" style=" background:#b7d8ef">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 18px; padding-left: 10px; margin-top: -105px; height: 550%; margin-bottom: -65px; width: 50rem; margin-left: -300px;" >

                      <form>
                         <div class="form-row">
                          <p style="margin: 10px 20px; margin-bottom: 28px; font-weight: 600"> <b> If YES in (22) or YES in (23)</b>
                          </p>
                        </div>

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 5px;margin-bottom: 16px;">
                                  (31) Did you look for additional work during<br>the past week? </label><br>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                            </div> <!-- form-group end.// -->

                            <div class="col form-group" style="margin-left: -110px">
                                <label style="margin-left: 5px; margin-bottom: 2px;">
                                    (32) What is your class of worker? </label><br>


                           <div class="dropdown">
                              <select style="margin-top: 26px; width: 60%" required>
                                <option value=""disabled>Select your option</option>
                                <option value="1">Working for private household</option>
                                <option value="2">Working for private business/establishment /farm</option>
                                <option value="3">Working for government/government corporation</option>
                                <option value="4">Self-employed with no paid employee</option>
                                <option value="5">Employer in own family- operated farm or business</option>
                                <option value="6">Working with pay on own family-operated farm or business</option>
                                <option value="7">Working without pay on own family-operated farm or business</option>
                              </select>
                            </div>

                            </div> <!-- form-group end.// -->
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

            <!-- HOUSING CHARACTERISTICS 2 Services Section -->

              <section id="services" class="services"style=" background: #b7d8ef">
                  <div class="container">
                     <div class="row counters">
                        <div class="row justify-content-center" >
                              <div class="col-md-6">
                                <div class="card" style="padding-top: 18px; padding-left: 10px;  margin-top: -85px; height: 155%; width: 50rem; margin-left: -300px;" >

                 <form>
                    <div class="form-row">
                       <p style="margin: 10px 20px; margin-bottom: 28px;font-weight: 600"> <b> If NO in (22) or YES in (23)</b>
                       </p>
                    </div>


                    <div class="form-row">

                      <div class="col form-group">
                        <label style="margin-left: 5px;margin-bottom: 16px;">
                            (33) Did you look for work or try to establish <br> business during the past week? 
                        </label><br>

                      <div class="form-check form-check-inline">
                         <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                           <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                      </div>

                      <div class="form-check form-check-inline">
                         <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                          <label class="form-check-label" for="inlineCheckbox2"> No (proceed to <b>(37)</b>)
                          </label>
                     </div>
                      </div> <!-- form-group end.// -->
                  </div> <!-- form-row end.// -->
                  
                  <div class="form-row">

                     <div class="col form-group">
                        <label> <br> </label>
                      </div> <!-- form-group end.// -->
                       </div> <!-- form-row end.// -->
                        </div>
                         </section>

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->

         <section id="services" class="services"style=" background:#b7d8ef">
            <div class="container">
              <div class="row counters">
                 <div class="row justify-content-center" >
                              <div class="col-md-6">
                                <div class="card" style="padding-top: 18px; padding-left: 10px; height: 130%; margin-top: -150px; margin-bottom: 10px; width: 50rem; margin-left: -300px;" >

           <form>
             <div class="form-row">
               <p style="margin: 10px 20px; margin-bottom: 34px;font-weight: 600"> <b>If YES in (33) </b>
                                      </p></div>


                 <div class="form-row">

                    <div class="col form-group">
                      <label style="margin-left: 5px">
                        (34) Was this your first time to look for<br>work or try to establish a business? 
                      </label><br>


                    <div class="form-check form-check-inline" style="margin-bottom: 50px;">
                        <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                            <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                    </div>

                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                            <label class="form-check-label" for="inlineCheckbox2"> No</label>
                    </div>

                    </div> <!-- form-group end.// -->

                    <div class="col form-group" style="margin-left: -110px">
                        <label style="margin-left: 5px; margin-bottom: 7px;">
                            (35) What have you been doing to find work? </label><br>


                          <div class="dropdown">
                              <select style="margin-top: 26px; width: 60%"required>
                                <option value=""disabled>Select your option</option>
                                <option value="1">Registered in public employment agency</option>
                                <option value="2">Registered in private employment agency</option>
                                <option value="3">Approached employer directly</option>
                                <option value="4">Approached relatives or friends</option>
                                <option value="5">Placed or answered advertisements</option>
                                <option value="6">Searched and applied online</option>
                                <option value="7">Others, specify</option>
                               </select>
                          </div>

                        </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->

                      <div class="form-row">

                        <div class="col form-group">
                            <label style="margin-left: 5px">
                            (36) How many weeks have you been<br> looking for work? <b>(Proceed to 46) </b><br>
                            </label><br>

                        <input class="form-control" type="number">
                       </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->


                        <div class="col form-group">
                          <label> <br> </label>
                            </div> <!-- form-group end.// -->
                             </div> <!-- form-row end.// -->
                            </div>
                </section>

      <!-- HOUSING CHARACTERISTICS 2 Services Section -->

             <section id="services" class="services"style=" background: #b7d8ef">
                <div class="container">
                    <div class="row counters">
                      <div class="row justify-content-center" >
                              <div class="col-md-6">
                                <div class="card" style="padding-top: 18px; padding-left: 10px; height: 170%; margin-top: -208px; margin-bottom: 1px; width: 50rem; margin-left: -300px;" >

           <form>
              <div class="form-row">
                <p style="margin: 10px 20px; margin-bottom: 83px;font-weight: 600"> <b>If NO in (33) </b>
                </p>
              </div>

              <div class="form-row">

                <div class="col form-group">
                  <label style="margin-left: 5px; margin-bottom: 20px;">
                    (37) Why did you not look for work? 
                  </label> <br>

                      <div class="dropdown" style="width:50%;">
                        <select required>
                          <option value=""disabled>Select your option</option>
                          <option value="1">Tired/Believes no work is available</option>
                          <option value="2">Awaiting results of previous job application</option>
                          <option value="3">Temporary illness/ disability</option>
                          <option value="4">Bad weather</option>
                          <option value="5">Waiting for rehire/job recall</option>
                          <option value="6">Too young/old or retired/permanent disability</option>
                          <option value="7">Household, family duties</option>
                          <option value="8">Schooling</option>
                          <option value="9">Others, specify</option>

                         </select>
                     </div>
                </div> <!-- form-group end.// -->

                <div class="col form-group" style="margin-left: -130px">
                   <label style="margin-left: 5px; margin-bottom: 15px;">
                      (38) When was the last time you looked for work? 
                  </label><br>

                      <div class="form-check form-check-inline" style="margin-bottom: 10px;">
                        <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                         <label class="form-check-label" for="inlineCheckbox1"> Within last month</label>
                       </div>

                       <div class="form-check form-check-inline" style="margin-left: 90px;">
                        <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                         <label class="form-check-label" for="inlineCheckbox2"> One to six months</label>
                       </div>

                        <div class="form-check form-check-inline" style="margin-top: -80px; margin-bottom: 40px;">
                        <input class="form-check-input" type="radio" id="inlineCheckbox3" value="3">
                         <label class="form-check-label" for="inlineCheckbox3" > More than six months ago</label>
                       </div>

                    </div> <!-- form-group end.// -->
                  </div> <!-- form-row end.// -->

                     <div class="col form-group">
                          <label> <br> </label>
                        </div> <!-- form-group end.// -->
                         </div> <!-- form-row end.// -->
                        </div>
              </section>

      <!-- HOUSING CHARACTERISTICS 2 Services Section -->

            <section id="services" class="services"style=" background: #b7d8ef">
              <div class="container">
                <div class="row counters">
                  <div class="row justify-content-center" >
                    <div class="col-md-6">
                      <div class="card" style="padding-top: 18px; padding-left: 10px; height: 170px; margin-top: -264px; margin-bottom: 1px; width: 50rem; margin-left: -300px;" >

           <form>
            <div class="form-row">

              <div class="col form-group">
                 <label style="margin-left: 5px; margin-bottom: 15px; margin-top: 9px;">
                        (39) Had opportunity for work existed last<br> week or within two weeks, would you been <br> available? 
                 </label> <br>

                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                      <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                    </div>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                      <label class="form-check-label" for="inlineCheckbox2"> No</label>
                    </div>
              </div> <!-- form-group end.// -->

              <div class="col form-group" style="margin-left: 20px">
                 <label style="margin-left: 5px; margin-bottom: 40px; margin-top: 9px;">
                        (40) Were you willing to take up work <br> during the past week or within 2 weeks? 
                 </label><br>
                
                    <div class="form-check form-check-inline">
                         <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                           <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                   </div>
                   <div class="form-check form-check-inline">
                         <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                           <label class="form-check-label" for="inlineCheckbox2"> No</label>
                   </div>
                </div> <!-- form-group end.// -->
              </div> <!-- form-row end.// -->
        
          <div class="col form-group">
              <label> <br> </label>
              </div> <!-- form-group end.// -->
            </div> <!-- form-row end.// -->
          </div>
         </section>

        <!-- HOUSING CHARACTERISTICS 2 Services Section -->


            <section id="services" class="services"style=" background: #b7d8ef">
              <div class="container">
                <div class="row counters">
                  <div class="row justify-content-center" >
                    <div class="col-md-6">
                      <div class="card" style="padding-top: 18px; padding-left: 10px; height: 130%;  margin-top: -180px; margin-bottom: 1px; width: 50rem; margin-left: -300px;" >

           <form>
            <div class="form-row">

              <div class="col form-group">
                 <label style="margin-left: 5px; margin-bottom: 15px; margin-top: 9px;">
                        (41) In the past 12 months, how much total salary/wages did you receive? <br><br> DO NOT INCLUDE SALARY OF HOUSEHOLD MEMBERS WHO ARE OFW AND <br> HOUSEMAIDS/BOYS
                 </label> <br>

                    <label>(A) Cash </label>   
                    <input type="number" class="form-control" placeholder="">
              </div> <!-- form-group end.// -->

              <div class="col form-group">
                 <label style="margin-left: 5px; margin-bottom: 15px; margin-top: 9px;">
                        <br><br><br><br><br><br>
                 </label> <br>

                    <label>(B) In Kind </label>   
                    <input type="text" class="form-control" placeholder="">
              </div> <!-- form-group end.// -->

            
              </div> <!-- form-row end.// -->
         <div class="form-row">

          <div class="col form-group">
            <label style="margin-bottom: 15px; margin-top: 70px;">
                (42) Is ____ a member of SSS or GSIS?
             </label> <br>

             <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                    <label class="form-check-label" for="inlineCheckbox1"> Yes, SSS</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                    <label class="form-check-label" for="inlineCheckbox2"> Yes, GSIS</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" id="inlineCheckbox3" value="3">
                    <label class="form-check-label" for="inlineCheckbox2"> Yes, both</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" id="inlineCheckbox4" value="4">
                    <label class="form-check-label" for="inlineCheckbox2"> No</label>
              </div>
          </div> <!-- form-group end.// --> 
        </div> <!-- form-row end.// -->

          <div class="col form-group">
              <label> <br> </label>
              </div> <!-- form-group end.// -->
            </div> <!-- form-row end.// -->
          </div>
         </section>

        <!-- HOUSING CHARACTERISTICS 2 Services Section -->


      <!-- ======= NEXT PAGE BUTTON Section ======= -->
       <section id="testimonials" class="testimonials section-bg">
         <div class="container" style="padding-top: 1px;">
            <div class="form-group">
              <button type="submit" class="btn btn-primary btn-block"> <a href="/fhh2"> NEXT FORM </a> </button>
            </div> <!-- form-group// -->
          </div>
       </section>
        <!-- End NEXT PAGE BUTTON Section -->
