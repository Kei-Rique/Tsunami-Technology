<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>{{$title}}</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i, 700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/line-awesome/css/line-awesome.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">


  <!-- Template Main CSS File -->
  <link href="assets/css/fhh4.css" rel="stylesheet">
</head>

<body>

        <!-- ======= IDENTIFICATION Section ======= -->
  <section id="about" class="about" style="background-color: #b7d8ef; margin-top: -50px;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:45px; color: black; margin-left: -471px; font-family: Raleway; margin-top: 30px; margin-bottom: -10px;"> 
              <b>Sources of Income</b> </p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section>

  <!-- End IDENTIFICATION Section -->

 <section id="services2" class="services2" style=" background:#b7d8ef; margin-bottom: -200px;" >
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -40px; height: 80%; padding-bottom: 120px;margin-bottom: 85px; margin-left: -295px; width: 50rem;" >

                      <form>
                         
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 68px;">
                                  During the past 12 months, did you or any member of your household operate any of the following entrepreneurial activities? <br><br> <b> ENTERPRENEURIAL ACTIVITIES  </b> </label><br>
                            </div> <!-- form-group end.// -->

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 85px;margin-bottom: 68px;">
                                  What was the total net value of <br>income from these activities during <br>the past 12 months? (in pesos) </label><br>
                            </div> <!-- form-group end.// -->
                         </div> <!-- form-row end.// -->

<div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 48px; width: 270px;">
                                  (66) CROP FARMING AND GARDENING</label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -5px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group" style="margin-right: -70px; margin-top: -45px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                  <b>(A) IN CASH</b> </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="margin-left: px; margin-top: -45px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                  <b>(B) IN KIND</b> </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    
                         </div>
                     
                     <div class="form-row" style="margin-top: -40px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;width: 270px;">
                                  (67) LIVESTOCK AND POULTRY RAISING</label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -5px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group" style="margin-left:-45px;margin-right: -88px; margin-top: -5px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="margin-left:-2px; margin-top: -5px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                  </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    
                         </div>

                          <div class="form-row" style="margin-top: -5px;">
                         
                          <div class="col form-group">
                            <label style="margin-left: 20px;width: 270px;">
                                  (68) FISHING</label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -5px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group" style="margin-left:-45px;margin-right: -88px; margin-top: -5px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="margin-left:-2px; margin-top: -5px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                  </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    
                         </div>

                          <div class="form-row" style="margin-top: -3px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;width: 270px;">
                                  (69) FORESTRY AND HUNTING</label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -5px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group" style="margin-left:-45px;margin-right: -88px; margin-top: -5px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="margin-left:-2px; margin-top: -5px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                  </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    
                         </div>

                          <div class="form-row" style="margin-top: -3px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;width: 270px;">
                                  (70) WHOLESALE AND RETAIL</label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -5px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group" style="margin-left:-45px;margin-right: -88px; margin-top: -5px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="margin-left:-2px; margin-top: -5px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                  </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    
                         </div>

                         <div class="form-row" style="margin-top: 15px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 48px; width: 270px;">
                                  (71) MANUFACTURING</label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -5px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group" style="margin-right: -70px; margin-top: -5px;">
                              
                                <input type="text" class="form-control1" style="margin-left: 21px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="margin-left: px; margin-top: -5px;">
                              
                                <input type="text" class="form-control1" style="margin-left: 21px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    
                         </div>
                     
                     <div class="form-row" style="margin-top: -40px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;width: 270px;">
                                  (72) COMMUNITY, SOCIAL, RECREATIONAL, AND PERSONAL SERVICES</label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -5px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group" style="margin-left:-45px;margin-right: -88px; margin-top: -5px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="margin-left:-2px; margin-top: -5px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                  </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    
                         </div>

                          <div class="form-row" style="margin-top: -5px;">
                         
                          <div class="col form-group">
                            <label style="margin-left: 20px;width: 270px;">
                                  (73) TRANSPORTATION, STORAGE AND COMMUNICATION SERVICES</label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -5px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group" style="margin-left:-45px;margin-right: -88px; margin-top: -5px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="margin-left:-2px; margin-top: -5px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                  </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    
                         </div>

                          <div class="form-row" style="margin-top: -3px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;width: 270px;">
                                  (74) MINING AND QUARRYING</label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -5px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group" style="margin-left:-45px;margin-right: -88px; margin-top: -5px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="margin-left:-2px; margin-top: -5px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                  </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    
                         </div>

                          <div class="form-row" style="margin-top: -3px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;width: 270px;">
                                  (75) CONSTRUCTION</label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -5px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group" style="margin-left:-45px;margin-right: -88px; margin-top: -5px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="margin-left:-2px; margin-top: -5px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                  </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    
                         </div>

                         <div class="form-row" style="margin-top: 15px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 48px; width: 270px;">
                                  (76) ACTIVITIES NOT ELSEWHERE CLASSIFIED</label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -5px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group" style="margin-right: -70px; margin-top: -5px;">
                              
                                <input type="text" class="form-control1" style="margin-left: 21px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="margin-left: px; margin-top: -5px;">
                              
                                <input type="text" class="form-control1" style="margin-left: 21px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    
                         </div>





                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>
       <!-- HOUSING CHARACTERISTICS 2 Services Section -->

    
 <section id="services2" class="services2" style=" background:#b7d8ef">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 10px; padding-bottom: 30px; padding-left: 10px; margin-top: -175px; height: 85px;margin-left: -295px; width: 50rem; background-color: white; border-color: black;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;width: 450px;">
                                  (77)<b> TOTAL NET INCOME FROM ENTREPRENEURIAL ACTIVITIES</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group" style="margin-right: -70px; margin-top: 18px;">
                              
                                <input type="text" class="form-control1" style="margin-left: 30px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="margin-top: 18px;">
                              
                                <input type="text" class="form-control1" style="margin-left: 25px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    

                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

                <!-- ======= IDENTIFICATION Section ======= -->
  <section id="about" class="about" style="background-color: #b7d8ef; margin-top: -50px;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:15px; color: black; margin-left: -392px; font-family: Raleway; margin-top: -120px; margin-bottom: -10px;"> 
              <b>Salaries and Wages From Employed Members</b> </p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section>

  <!-- End IDENTIFICATION Section -->

               <!--salaries and wages-->
               <section id="services2" class="services2" style=" background:#b7d8ef">
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-md-6">
          
                                <div class="card" style="padding-top: 10px; padding-bottom: 30px; padding-left: 10px; margin-top: -220px; height: 85px;margin-left: -295px; width: 50rem; background-color: white; border-color: black;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;width: 450px;">
                                  (78)<b> TOTAL SALARIES AND WAGES FROM EMPLOYED MEMBERS</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group" style="margin-right: -70px; margin-top: 18px;">
                              
                                <input type="text" class="form-control1" style="margin-left: 30px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="margin-top: 18px;">
                              
                                <input type="text" class="form-control1" style="margin-left: 25px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    

                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

                 <!-- ======= IDENTIFICATION Section ======= -->
  <section id="about" class="about" style="background-color: #b7d8ef; margin-top: -50px;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:15px; color: black; margin-left: -392px; font-family: Raleway; margin-top: -170px; margin-bottom: -10px;"> 
              <b>Other Sources of Income</b> </p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section>

  <!-- End IDENTIFICATION Section -->

      <section id="services2" class="services2" style=" background:#b7d8ef; margin-bottom: -200px;" >
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -270px; height: 80%; padding-bottom: 40px;margin-bottom: 85px; margin-left: -295px; width: 50rem;" >

                      <form>
                         
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 68px;">
                                  During the past 12 months, how much did you or any member of your household receive from the following? <br><br><br> <b> ENTERPRENEURIAL ACTIVITIES  </b> </label><br>
                            </div> <!-- form-group end.// -->

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 155px;margin-bottom: 68px; font-weight: 600;">
                                 <br> GROSS INCOME </label><br>
                            </div> <!-- form-group end.// -->
                         </div> <!-- form-row end.// -->

<div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 48px; width: 400px;">
                                  <b>(79)</b> Net share of crops, fruits, and vegetables produced, aquaculture
        products harvested or livestock and poultry raised by other households?</label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -5px;">
                            
                          </div>

                          <div class="col form-group" style="margin-right: 40px; margin-top: -45px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 10px;">
                                  <b>(A) IN CASH</b> </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="padding-right: 40px;margin-top: -45px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 10px;">
                                  <b>(B) IN KIND</b> </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    
                         </div>
                     
                     <div class="form-row" style="margin-top: -10px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;width: 350px;">
                                 <b>(80)</b> Remittances from Overseas Filipino workers</label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -5px;">
                          
                          </div>

                          <div class="col form-group" style="margin-right: 40px; margin-top: -25px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="padding-right: 40px;margin-top: -25px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                  </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    
                         </div>

                          <div class="form-row" style="margin-top: 5px;">
                         
                          <div class="col form-group">
                            <label style="margin-left: 20px;width: 350px;">
                                 <b> (81)</b> Cash receipts, gifts, support, relief, and other froms of assistance
from abroad</label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -5px;">
                            
                          </div>

                          <div class="col form-group" style="margin-right: 40px; margin-top: -15px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="padding-right: 40px; margin-top: -15px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                  </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    
                         </div>

                          <div class="form-row" style="margin-top: 5px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;width: 350px;">
                                 <b>(82)</b> Cash receipts, support, assitance, and relief from domestic
sources</label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -5px;">
                           
                          </div>

                          <div class="col form-group" style="margin-right: 40px; margin-top: -15px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="padding-right: 40px; margin-top: -15px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                  </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    
                         </div>

                          <div class="form-row" style="margin-top: 5px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;width: 350px;">
                                 <b> (83)</b> Rentals received from non-agricultural lands, buildings, spaces,
and other properties</label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -5px;">
                           
                          </div>

                          <div class="col form-group" style="margin-right: 40px; margin-top: -15px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="padding-right: 40px; margin-top: -15px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                  </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    
                         </div>

                         <div class="form-row" style="margin-top: 30px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 48px; width: 350px;">
                                 <b> (84)</b> Interest from bank deposits, interest from loans extended to other
families</label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -5px;">
                            
                          </div>

                          <div class="col form-group" style="margin-right: 40px; margin-top: 5px;">
                              
                                <input type="text" class="form-control1" style="margin-left: 21px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="padding-right: 40px; margin-top: 5px;">
                              
                                <input type="text" class="form-control1" style="margin-left: 21px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    
                         </div>
                     
                     <div class="form-row" style="margin-top: -15px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;width: 350px;">
                                  <b>(85)</b> Pension and retirement, workmen’s compensation, and social
security benefits</label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -5px;">
                          
                          </div>

                          <div class="col form-group" style="margin-right: 40px; margin-top: -15px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="padding-right: 40px; margin-top: -15px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                  </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    
                         </div>

                          <div class="form-row" style="margin-top: 10px;">
                         
                          <div class="col form-group">
                            <label style="margin-left: 20px;width: 350px;">
                                 <b>(86)</b> Dividends from investments</label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -5px;">
                            
                          </div>

                          <div class="col form-group" style="margin-right: 40px; margin-top: -25px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="padding-right: 40px; margin-top: -25px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                  </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    
                         </div>

                          <div class="form-row" style="margin-top: 5px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;width: 350px;">
                                 <b>(87)</b> Other sources of income not elsewhere classified</label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -5px;">
                           
                          </div>

                          <div class="col form-group" style="margin-right: 40px; margin-top: -15px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="padding-right: 40px; margin-top: -15px;">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 1px;">
                                  </label>
                                <input type="text" class="form-control1" style="margin-left: 20px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>
       <!-- HOUSING CHARACTERISTICS 2 Services Section -->

      <section id="services2" class="services2" style=" background:#b7d8ef">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 10px; padding-bottom: 30px; padding-left: 10px; margin-top: -335px; height: 85px;margin-left: -295px; width: 50rem; background-color: white; border-color: black;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;width: 450px;">
                                  (88)<b> TOTAL INCOME FROM OTHER SOURCES OF INCOME</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group" style="margin-right: -70px; margin-top: 18px;">
                              
                                <input type="text" class="form-control1" style="margin-left: 30px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="margin-top: 18px;">
                              
                                <input type="text" class="form-control1" style="margin-left: 25px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    

                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                  </form>
                   </div>
               </div>
               </section>

       <!-- HOUSING CHARACTERISTICS 2 Services Section -->
<section id="services2" class="services2" style=" background:#b7d8ef">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 10px; padding-bottom: 30px; padding-left: 10px; margin-top: -355px; height: 85px;margin-left: -295px; width: 50rem; background-color: white; border-color: black;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:12px;margin-left: 20px;width: 450px;">
                                  (89)<b> TOTAL IMPUTED RENT FROM OWNED OR RENT-FREE HOUSE AND/OR LOT</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group" style="margin-right: -70px; margin-top: 18px;">
                              
                                <input type="text" class="form-control1" style="margin-left: 30px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="margin-top: 18px;">
                              
                                <input type="text" class="form-control1" style="margin-left: 25px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    

                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>
       <!-- HOUSING CHARACTERISTICS 2 Services Section -->
<section id="services2" class="services2" style=" background:#b7d8ef">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 10px; padding-bottom: 30px; padding-left: 10px; margin-top: -375px; height: 85px;margin-left: -295px; width: 50rem; background-color: white; border-color: black;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;width: 450px;">
                                  (90)<b> TOTAL INCOME IN CASH AND IN KIND</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group" style="margin-right: -70px; margin-top: 18px;">
                              
                                <input type="text" class="form-control1" style="margin-left: 30px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="margin-top: 18px;">
                              
                                <input type="text" class="form-control1" style="margin-left: 25px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    

                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

  <!-- End IDENTIFICATION Section -->
<section id="services2" class="services2" style=" background:#b7d8ef">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 10px; padding-bottom: 30px; padding-left: 10px; margin-top: -395px; height: 85px;margin-left: -295px; width: 50rem; background-color: white; border-color: black;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;width: 450px;">
                                  (91)<b> TOTAL HOUSEHOLD INCOME</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group" style="margin-right: -70px; margin-top: 18px;">
                              
                                <input type="text" class="form-control1" style="margin-left: 30px; width: 100px;"placeholder="">
                            </div> <!-- form-group end.// -->    

                            <div class="col form-group" style="margin-top: 18px;">
                              
                                <input type="text" class="form-control1" style="margin-left: 25px; width: 100px;"placeholder="">
                              
                            </div> <!-- form-group end.// -->    

                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

      <!-- ======= NEXT PAGE BUTTON Section ======= -->
       <section id="testimonials" class="testimonials section-bg" style="margin-top: -190px;">
         <div class="container">
            <div class="form-group">
              <button type="submit" class="btn btn-primary btn-block"> <a href="/fhh5"> NEXT PAGE</a> </button>
            </div> <!-- form-group// -->
          </div>
       </section>

        <!-- End NEXT PAGE BUTTON Section -->
