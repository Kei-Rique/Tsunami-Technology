@extends('layouts.layout')
@section('mainContent')

  <!-- ======= ALUBIJID Section ======= -->
  <section id="hero">
    <div class="hero-container">
      <h1><b>Alubijid</b></h1>
      <h2>Community-based monitoring system <br> Household profile questionnaire</h2>
      <a href="#about" class="btn-get-started scrollto">Start</a>
    </div>
  </section><!-- End ALUBIJID -->

  <!-- ======= IDENTIFICATION Section ======= -->
  <section id="about" class="about">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <img class="img-left" src="http://assets.barcroftmedia.com.s3-website-eu-west-1.amazonaws.com/assets/images/recent-images-11.jpg"/>
              <div class="content-heading"><h3>IDENTIFICATION &nbsp </h3></div>

              <p>Donec id elit non mi porta gravida at eget metus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.</p>

            </div>
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

  <!-- ======= LOCATION Section ======= -->
  <form method="post" action="/start_form">
    @csrf> 

  <section id="counts" class="counts">
    <div class="container" style="padding-bottom: 20px;">

      <div class="row counters">

        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">


        <div class="row justify-content-center" style=" background: #b7d8ef">
          <div class="col-md-6">
            <div class="card" style=" background: transparent; border-color: transparent; width: 50rem;">

              
                <p style="font-size:30px; font-family: Raleway"><b> Location </b></p>
                <div class="form-row">
                  <div class="col form-group">
                    <label>Purok/Sitio </label>   
                    <input type="text" for="purok" id="purok" name="purok" class="form-control" placeholder="" style="width: 50px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group">
                    <label> <br> </label>
                    <span class="col form-group-btn" 
                    style="width:0px;"></span>
                    <input type="text" class="form-control" placeholder=" " style="width: 50px; margin-left: -348px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group1" style="margin-left: -410px;">
                    <label>Street </label>   
                    <input type="text" for="street" id="street" name="street" class="form-control" placeholder="" style="width: 190px; padding-left: -200px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent; margin-bottom: 15px;">
                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                <div class="form-row">
                  

                

                  <div class="col form-group">
                    <label> <br> </label>   
                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                <div class="form-row">
                  <div class="col form-group1">
                    <label>Zone </label>   
                    <input type="text" for="zone" id="zone" name="zone" class="form-control" placeholder="" style="width: 50px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group" style="margin-left: 10px">
                    <label> <br> </label>
                    <span class="col form-group-btn" 
                    style="width:0px;"></span>
                    <input type="text" class="form-control" placeholder=" " style="width: 50px; margin-left: -153px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group1" style="margin-left: -13px;">
                    <label>House Number </label>   
                    <input type="text" for="house_number" id="house_number" name="house_number" class="form-control" placeholder="" style="width: 190px; padding-left: -200px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group">
                    <label> <br> </label>
                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                <div class="form-row">
                  <div class="col form-group1">
                    <label>Baranggay </label>   
                    <select for="baranggay" id="baranggay" name="baranggay" style="width: 200px; font-size: 15px;  border-radius: 0px; background-color: white;"required>
                      <option value="">Select your option</option>
                      <option value="Baybay">Baybay</option>
                      <option value="Benigwayan">Benigwayan</option>
                      <option value="Calatcat">Calatcat</option>
                      <option value="Lagtang">Lagtang</option>
                      <option value="Lanao">Lanao</option>
                      <option value="Loguilo">Loguilo</option>
                      <option value="Lourdes">Lourdes</option>
                      <option value="Lumbo">Lumbo</option>
                      <option value="Molocboloc">Molocboloc9</option>
                      <option value="Poblacion">Poblacion</option>
                      <option value="Sampatulog">Sampatulog</option>
                      <option value="Sungay">Sungay</option>
                      <option value="Talaba">Talaba</option>
                      <option value="Taparak">Taparak</option>
                      <option value="Tugasnon">Tugasnon</option>
                      <option value="Tula">Tula</option>
                    </select>

                    <label style="font-size: 12px; margin-top: 23px;">Household Identification Number</label>   
                    <input type="text" for="house_identification_number" id="house_identification_number" name="house_identification_number" class="form-control" placeholder="" style="width: 190px; padding-left: -200px;  border-radius: 0px; background-color: #f4f4f4; border-color: transparent;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group" style="margin-left: -5px">
                    <label> <br> </label>
                    <span class="col form-group-btn" 
                    style="width:0px;"></span>
                  </div> <!-- form-group end.// -->

                  <div class="col form-group1"style="margin-left: -6px">
                    <p style="margin-bottom: 16px; "><b> Coordinates </b></p>
                    <label">Latitude</label>   
                    <input type="text" for="latitude" id="latitude" name="latitude" class="form-control1" placeholder="" style="width: 190px; height: 20px; padding-left: -200px;    border-radius: 0px;background-color: #f4f4f4; border-color: transparent; font-size: 10px;">
                    <label>Longitude </label>   
                    <input type="text" for="longitude" id="longitude" name="longitude" class="form-control1" placeholder="" style="width: 190px; height: 20px; padding-left: -200px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent; font-size: 10px;">
                  </div> <!-- form-group end.// -->
                  <div class="col form-group">
                    <label> <br> </label>


                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                <div class="form-group">
                  <label style="margin-top: 10px;">Name of Respondent</label>
                  <input class="form-control" for="name_of_respondent" id="name_of_respondent" name="name_of_respondent" type="text" style="width: 550px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent;"required>
                </div> <!-- form-group end.// -->  

             
            </article> <!-- card-body end .// -->
          </div> <!-- col.//-->
        </div> <!-- row.//-->
        <!--container end.//-->

        <br><br>
      </div>
    </div>
  </section><!-- End LOCATION Section -->


  <!-- ======= HOUSING CHARACTERISTICS 1 Section ======= -->
  <section id="clients" class="clients section-bg">
    <div class="container">

      <div class="row counters">
        <div class="row justify-content-center" >
          <div class="col-md-6" >
            <div class="card" style=" background: #ffffff; border-color: transparent;" >

              
                <p style="font-size:30px; margin-left: -461px; font-family: Raleway"> Housing Characteristics </p>
                <div class="form-row">
                  <div class="col form-group">
                    <label style="margin-left: -381px">
                    1. In what type of building does the household reside? </label>   
                    <br>


                    <select for="q1" id="q1" name="q1" style="width: 500px;   border-radius: 0px; margin-left: -280px;"required>
                      <option value="">Select your option</option>
                      <option value="Single house">Single house</option>
                      <option value="Duplex">Duplex</option>
                      <option value="Multi-unit residential">Multi-unit residential (three units or more)</option>
                      <option value="Commercial/ industrial/ agricultural building/house">Commercial/ industrial/ agricultural building/house (e.g., office, factory, or others)</option>
                      <option value="Other housing unit">Other housing unit (boat, cave, and others)</option>
                    </select>



                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                <div class="form-row">
                  <div class="form-row">
                    <div class="col form-group">
                      <label  style="margin-left: -20px; width: 450px;">
                      2. How many bedrooms does this housing unit have? </label>   
                      

                      <input for="q2" id="q2" name="q2" class="form-control" type="number" style="width: 200px; height: 27px;   border-radius: 0px; margin-left: 12px; background-color: #f4f4f4; border-color: transparent;"required>
                    </div> <!-- form-group end.// -->
                  </div> <!-- form-row end.// -->


                  <div class="col form-group">
                    <label> <br> </label>


                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                <div class="form-row">
                  <div class="form-row">
                    <div class="col form-group">
                      <label  style="margin-left: -38px">
                      3. What type of construction materials are the roof made of? </label>   
                      <br>


                      <select for="q3" id="q3" name="q3" style="width: 500px;   border-radius: 0px; margin-left: 14px;"required>
                        <option value="">Select your option</option>
                        <option value="Strong materials">Strong materials (galvanized iron, aluminum, tile, concrete, brick, stone, asbestos)</option>
                        <option value="Light materials">Light materials (cogon, nipa, anahaw)</option>
                        <option value="Salvaged/makeshift materials">Salvaged/makeshift materials</option>
                        <option value="Mixed but predominantly strong materials">Mixed but predominantly strong materials</option>
                        <option value="Mixed but predominantly light materials">Mixed but predominantly light materials</option>
                        <option value="Mixed but predominantly salvaged materials">Mixed but predominantly salvaged materials</option>
                        <option value="Not applicable">Not applicable</option>
                      </select>



                    </div> <!-- form-group end.// -->
                  </div> <!-- form-row end.// -->

                  <div class="form-row">
                    <div class="col form-group">
                      <label  style="margin-left: 0px">
                      4. What type of construction materials are the roof outer walls made of? </label>   
                      <br>


                      <select for="q4" id="q4" name="q4" style="width: 500px;   border-radius: 0px; margin-left: -30px;" required>
                        <option value="">Select your option</option>
                        <option value="Strong materials">Strong materials (aluminum, tile, concrete, brick, stone, wood, plywood, asbestos)</option>
                        <option value="Light materials">Light materials (bamboo, sawali, cogon, nipa, anahaw)</option>
                        <option value="Salvaged/makeshift materials">Salvaged/makeshift materials</option>
                        <option value="Mixed but predominantly strong materials">Mixed but predominantly strong materials</option>
                        <option value="Mixed but predominantly light materials">Mixed but predominantly light materials</option>
                        <option value="Mixed but predominantly salvaged materials">Mixed but predominantly salvaged materials</option>
                        <option value="Not applicable">Not applicable</option>
                      </select>

                    </div> <!-- form-group end.// -->
                  </div> <!-- form-row end.// -->

                
              </article> <!-- card-body end .// -->

            </div> <!-- col.//-->
          </div>
        </section><!-- End HOUSING CHARACTERISTICS 1 Section -->

        <!-- ======= HOUSING CHARACTERISTICS 2 Section ======= -->
        <section id="services" class="services"style=" background: #b7d8ef">
          <div class="container">

            <div class="row counters">
              <div class="row justify-content-center" >
                <div class="col-md-6" >
                  <div class="card" style=" background: #b7d8ef; border-color: transparent; margin-bottom: -18px;" >

                    
                      <p style="font-size:30px; margin-left: 1px; margin-top: -50px; font-family: Raleway"> <b>Household Characteristics </b> </p>
                      <div class="form-row">
                        <div class="col form-group">
                          <label style="margin-left: 1px">
                          How many household members are overseas workers? </label>   
                          <br>


                          <input for="q5" id="q5" name="q5" class="form-control" type="number" style="width: 200px; height: 27px;   border-radius: 0px; margin-left: 1px; background-color: #f4f4f4; border-color: transparent;">


                        </div> <!-- form-group end.// -->


                      </div> <!-- form-row end.// -->

                      <div class="form-row">
                        <div class="form-row">
                          <div class="col form-group">
                            <label style="margin-left: 5px">
                            How many nuclear families are there in the household? </label>   
                            <br>


                            <input for="q6" id="q6" name="q6" class="form-control" type="number" style="width: 200px; height: 27px;   border-radius: 0px; margin-left: 5px; background-color: #f4f4f4; border-color: transparent;">



                          </div> <!-- form-group end.// -->
                        </div> <!-- form-row end.// -->


                        <div class="col form-group">
                          <label> <br> </label>


                        </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->

                      <div class="form-row">
                        <div class="form-row">
                          <div class="col form-group">
                            <label style="margin-left: 5px">
                            Is any member of the household pregnant? </label>   
                            <br>


                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="checkbox" for="q7" name="q7" id="q7" value="Yes" style="margin-left: 5px;">
                              <label class="form-check-label" >Yes</label>
                            </div>
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="checkbox" for="q7" name="q7" id="q7" value="No">
                              <label class="form-check-label" >No</label>
                            </div>

                            <br>
                            <div class="form-row">
                              <div class="form-row">
                                <div class="col form-group">
                                  <label style="margin-left: 8px; margin-top: 18px;">
                                  Is any member of the household a solo parent? </label>   
                                  <br>


                                  <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" for="q8" name="q8" id="q8" value="Yes" style="margin-left: 10px;">
                                    <label class="form-check-label" >Yes       </label>
                                  </div>
                                  <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" for="q8" name="q8" id="q8" value="No">
                                    <label class="form-check-label" >No</label>
                                  </div>



                                </div> <!-- form-group end.// -->
                              </div> <!-- form-row end.// -->
                            </div>

                            <div class="form-row">
                              <div class="form-row">
                                <div class="col form-group">
                                  <label style="margin-left: 8px;">
                                  Is any member of the household disabled? </label>   
                                  <br>


                                  <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" for="q9" name="q9" id="q9" value="Yes" style="margin-left: 10px;">

                                    <label class="form-check-label" >Yes       </label>
                                  </div>
                                  <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" for="q9" name="q9" id="q9" value="No">
                                    <label class="form-check-label" >No</label>
                                  </div>



                                </div> <!-- form-group end.// -->
                              </div> <!-- form-row end.// -->
                            </div>

                          
                        </article> <!-- card-body end .// -->

                      </div> <!-- col.//-->

                    </div>
                  </section><!-- HOUSING CHARACTERISTICS 2 Services Section -->

                  <!-- ======= NEXT PAGE BUTTON Section ======= -->
                 <section id="testimonials" class="testimonials section-bg">
         <div class="container">
            <div class="form-group">
              <button id="submit" for="submit" name="submit" type="submit" class="btn btn-primary btn-block"> Next Form </button>

              
            </div> <!-- form-group// -->
          </div>
       </section>
      </form>            <!-- End NEXT PAGE BUTTON Section -->

@stop