<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>{{$title}}</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i, 700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/line-awesome/css/line-awesome.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">


  <!-- Template Main CSS File -->
  <link href="assets/css/fhh2.css" rel="stylesheet">

</head>

<body>

  <!-- ======= IDENTIFICATION Section ======= -->
   <section id="about" class="about">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:45px; color: black; margin-left: -471px; font-family: Raleway;"> 
              HOUSEHOLD INFORMATION </p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

  <!-- End IDENTIFICATION Section -->

                                        
        <!-- HOUSING CHARACTERISTICS 2 Services Section -->

               <section id="services" class="services" style=" background:white">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 1px; padding-left: 10px; margin-top: -100px; height: 300%; margin-bottom: -65px; margin-left: -295px; width: 50rem;" >

                      <form>
                         <div class="form-row">
                          <p style="margin: 20px 30px; margin-bottom: 28px; font-weight: 600"> <b> If female household is pregnant</b>
                          </p>
                        </div>

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 30px;">
                                  (43) Is she pregnant? </label><br>

                        <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                            </div> <!-- form-group end.// -->

                            
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

            <!-- HOUSING CHARACTERISTICS 2 Services Section -->

              <section id="services" class="services"style=" background: white">
                  <div class="container">
                     <div class="row counters">
                        <div class="row justify-content-center" >
                              <div class="col-md-6">
                                <div class="card" style="padding-top: 18px; padding-left: 10px; margin-top: -95px; height: 120%; margin-left: -295px; width: 50rem;" >

                 <form>
                    <div class="form-row">
                       <p style="margin: 10px 30px; margin-bottom: 38px;font-weight: 600"> <b> If household is a solo parent</b>
                       </p>
                    </div>


                    <div class="form-row">

                      <div class="col form-group">
                        <label style="margin-left: 20px;margin-bottom: 30px;">
                            (44) Are you a solo parent taking care of a <br> child/children?
                        </label><br>

                      <div class="radio">
                      <div class="form-check form-check-inline">
                         <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                           <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                      </div>

                      <div class="form-check form-check-inline">
                         <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                          <label class="form-check-label" for="inlineCheckbox2"> No (proceed to <b>(37)</b>)
                          </label>
                     </div>
                   </div>
                      </div> <!-- form-group end.// -->
                  </div> <!-- form-row end.// -->
                  
                  <div class="form-row">

                     <div class="col form-group">
                        <label> <br> </label>
                      </div> <!-- form-group end.// -->
                       </div> <!-- form-row end.// -->
                        </div>
                         </section>

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->

         <section id="services" class="services" style=" background:white">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 18px; padding-left: 10px; margin-top: -179px; height: 180%; margin-bottom: 25px; margin-left: -295px; width: 50rem;" >

                      <form>
                         <div class="form-row">
                          <p style="margin: 10px 30px; margin-bottom: 38px;font-weight: 600"> <b> If household is a solo parent </b>
                          </p>
                        </div>

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 30px;">
                                  (45) Do you have any physical or mental <br> disability? <b>(Proceed to 48) </label><br>

                        <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                            </div> <!-- form-group end.// -->

                            
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

      <!-- HOUSING CHARACTERISTICS 2 Services Section -->

             <section id="services" class="services"style=" background: white">
                <div class="container">
                    <div class="row counters">
                      <div class="row justify-content-center" >
                              <div class="col-md-6">
                                <div class="card" style="padding-top: 18px; padding-bottom: 10px;padding-left: 10px; height: 170%; margin-top: -208px; margin-bottom: 50px;margin-left: -295px; width: 50rem;" >

           <form>
              <div class="form-row">
                <p style="margin: 10px 30px; margin-bottom: 38px;font-weight: 600"> <b>If YES in (45)</b>
                </p>
              </div>

              <div class="form-row">

                <div class="col form-group">
                  <label style="margin-left: 20px;margin-bottom: 30px;">
                    (46) What type of disability do you have? 
                  </label> <br>

                      <div class="dropdown">
                        <select required style="margin-left: 20px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Total blindness</option>
                          <option value="2">Partial blindness</option>
                          <option value="3">Low vision</option>
                          <option value="4">Totally deaf</option>
                          <option value="5">Partially deaf</option>
                          <option value="6">Oral defect</option>
                          <option value="7">One hand</option>
                          <option value="8">No hands</option>
                          <option value="9">One leg</option>
                          <option value="10">No legs</option>
                          <option value="11">Mild Cerebral palsy</option>
                          <option value="12">Severe Cerebral palsy</option>
                          <option value="13">Retarded</option>
                          <option value="14">Mentally ill</option>
                          <option value="15">Mental retardation</option>
                          <option value="16">Multiple impairment</option>
                          <option value="17">Others, specify</option>
                         </select>
                     </div>
                </div> <!-- form-group end.// -->

                <div class="col form-group" style="margin-left: -200px">
                   <label style="margin-left: 60px; margin-bottom: 30px;">
                      (47) Do you have PWD's ID?

                  </label><br>

                        <div class="radio" style="margin-left: 60px;">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                    </div> <!-- form-group end.// -->
                  </div> <!-- form-row end.// -->

                     <div class="col form-group">
                          <label> <br> </label>
                        </div> <!-- form-group end.// -->
                         </div> <!-- form-row end.// -->
                        </div>
              </section>

      <!-- HOUSING CHARACTERISTICS 2 Services Section -->

            <section id="services" class="services"style=" background: white; margin-bottom: -70px;">
                <div class="container">
                    <div class="row counters">
                      <div class="row justify-content-center" >
                              <div class="col-md-6">
                                <div class="card" style="padding-top: 18px; padding-bottom: 20px; padding-left: 10px; height: 250%; margin-top: -259px; margin-bottom: 40px;margin-left: -295px; width: 50rem;" >

           <form>
              <div class="form-row">
                <p style="margin: 10px 30px; margin-bottom: 60px;font-weight: 600"> <b>FOR 60 YEARS OLD AND ABOVE</b>
                </p>
              </div>

              <div class="form-row">

                <div class="col form-group">
                  <label style="margin-left: 20px;margin-bottom: 30px;">
                    (48) Do you have a Senior Citizen's ID?
                  </label> <br>

                       <div class="radio" style="margin-left: 30px;">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No (proceed to <b>(49)</b>)</label>
                          </div>
                        </div>
                </div> <!-- form-group end.// -->

                
                  </div> <!-- form-row end.// -->

                     <div class="col form-group">
                          <label> <br> </label>
                        </div> <!-- form-group end.// -->
                         </div> <!-- form-row end.// -->
                        </div>
              </section>

        <!-- HOUSING CHARACTERISTICS 2 Services Section -->

        <!-- ======= IDENTIFICATION Section ======= -->
  <section id="about" class="about" style="background-color: #b7d8ef">
     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:35px; color: black; margin-left: -380px; font-family: Raleway; margin-top: -30px; margin-bottom: -30px;"> 
              <b>Crime</b> </p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section>

  <!-- End IDENTIFICATION Section -->

 <section id="services2" class="services2" style=" background:#b7d8ef">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 5px; padding-left: 10px; margin-top: -85px; height: 350%; margin-bottom: -55px; margin-left: -295px; width: 50rem;" >

                      <form>
                     
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 28px;">
                                  (49) Have you been a victim of crime in the past 12 months? </label><br>

                        <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No (proceed to <b> (51) </b>)</label>
                          </div>
                        </div>
                            </div> <!-- form-group end.// -->

                            
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

       <!-- HOUSING CHARACTERISTICS 2 Services Section -->

 <section id="services2" class="services2" style=" background:#b7d8ef; margin-bottom: -50px;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 18px; padding-left: 10px; margin-top: -107px; height: 120%; margin-bottom: 10px; margin-left: -295px; width: 50rem;" >

                      <form>
                     <div class="form-row">
                <p style="margin: 10px 30px; margin-bottom: 30px;font-weight: 600"> <b>If YES in (49)</b>
                </p>
              </div>

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 28px;">
                                  (50-A) What crime/s was/were you a victim of? </label><br>
                  <div class="dropdown">
                        <select required style="margin-left: 20px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Theft</option>
                          <option value="2">Robbery</option>
                          <option value="3">Rape</option>
                          <option value="4">Physical injury</option>
                          <option value="5">Carnapping</option>
                          <option value="6">Cattle rustling</option>
                          <option value="7">Others, specify</option>
                         </select>
                     </div>

                            </div> <!-- form-group end.// -->


                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 28px;">
                                  (50-B) Where did the crime happen? </label><br>
                    <div class="dropdown">
                        <select required style="margin-left: 20px; width: 50%;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Within the barangay</option>
                          <option value="2">Outside the barangay but within municipality/city</option>
                          <option value="3">Outside the municipality/city but within province</option>
                          <option value="4">Outside the province</option>
                        </select>
                     </div>

                            </div> <!-- form-group end.// -->

                            
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

       <!-- HOUSING CHARACTERISTICS 2 Services Section -->
       <!-- ======= IDENTIFICATION Section ======= -->
  <section id="about" class="about" style="background-color: #ffffff">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:35px; color: black; margin-left: -380px; font-family: Raleway; margin-top: -30px; margin-bottom: -10px;"> 
              <b>Nutrition</b> </p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section>

  <!-- End IDENTIFICATION Section -->

       <section id="services" class="services" style=" background:#ffffff">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 18px; padding-left: 10px; margin-top: -75px; height: 80%; margin-bottom: 85px; margin-left: -295px; width: 50rem;" >

                      <form>
                     <div class="form-row">
                <p style="margin: 10px 30px; margin-bottom: 30px;font-weight: 600"> <b>FOR 5 YEARS OLD AND BELOW</b>
                </p>
              </div>

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 28px;">
                                  (51) NUTRITIONAL STATUS OF CHILDREN 0-5 YEARS OLD AND DATE OF RECORD OF BARANGAY <BR> NUTRITION SCHOLAR </label><br>

                  <div class="dropdown">
                        <select required style="margin-left: 20px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Above normal</option>
                          <option value="2">Normal</option>
                          <option value="3">Below normal (moderate)</option>
                          <option value="4">Below normal (severe)</option>
                         </select>
                     </div>

                            </div> <!-- form-group end.// -->    
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

       <!-- HOUSING CHARACTERISTICS 2 Services Section -->

      <!-- ======= NEXT PAGE BUTTON Section ======= -->
       <section id="testimonials" class="testimonials section-bg">
         <div class="container">
            <div class="form-group">
              <button type="submit" class="btn btn-primary btn-block"> <a href="/fhh3"> ADD HOUSEHOLD </a> </button>
            </div> <!-- form-group// -->
          </div>
       </section>

        <!-- End NEXT PAGE BUTTON Section -->
