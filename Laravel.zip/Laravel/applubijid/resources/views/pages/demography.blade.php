<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>{{$title}}</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i, 700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/line-awesome/css/line-awesome.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">



  <!-- Template Main CSS File -->
  <link href="assets/css/demog.css" rel="stylesheet">

</head>

<body>

  <!-- ======= IDENTIFICATION Section ======= -->
    <section id="about" class="about">
      <div class="container">

       <div class="container">
  <div class="row">  
  <div class="block">
      <div class="row" style="margin-top: -65px;">
        <div class="span4">
          <img class="img-left" src="http://assets.barcroftmedia.com.s3-website-eu-west-1.amazonaws.com/assets/images/recent-images-11.jpg"/>
          <div class="content-heading"><h3>IDENTIFICATION &nbsp </h3></div>

          <p>Donec id elit non mi porta gravida at eget metus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.</p>
        
        </div>
     </div>
     <br> 
  </div>
  </div>
      </div>
    </section><!-- End IDENTIFICATION Section -->

    <!-- ======= ADD HOUSEHOLD Section ======= -->
    <section id="counts" class="counts">
      <div class="container">

        <div class="row counters">

    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">


<div class="row justify-content-center" style=" background: #b7d8ef">
<div class="col-md-6">
<div class="card" style=" background: transparent; border-color: transparent;">

<form>
 
<div class="card1" style="margin: auto;">
  <div class="card-body">
    Juan Thomas <button type="button" class="btn btn-primary " style="float:right; background-color:#ef7a7a; border-color: transparent; border-radius: 0px;"> <i class="far fa-trash-alt" style="display: flex;
    justify-content: center;
    align-items: center;"></i></button>

    <button type="button" class="btn btn-primary " style="float:right; background-color:#98ef7a; border-color: transparent; border-radius: 0px;"> <i class="fas fa-pencil-alt" style="display: flex;
    justify-content: center;
    align-items: center;"></i></button>
  </div> 
</div>

 <br>

<div class="card1" style="margin: auto;">
  <div class="card-body">
    Dezza Naut <button type="button" class="btn btn-primary " style="float:right; background-color:#ef7a7a; border-color: transparent; border-radius: 0px;"> <i class="far fa-trash-alt" style="display: flex;
    justify-content: center;
    align-items: center;"></i></button>

    <button type="button" class="btn btn-primary " style="float:right; background-color:#98ef7a; border-color: transparent; border-radius: 0px;"> <i class="fas fa-pencil-alt" style="display: flex;
    justify-content: center;
    align-items: center;"></i></button>
  </div>
</div>

<br>

<div class="card1" style="margin: auto;">
  <div class="card-body">
    Abby Gaylas <button type="button" class="btn btn-primary " style="float:right; background-color:#ef7a7a; border-color: transparent; border-radius: 0px;"> <i class="far fa-trash-alt" style="display: flex;
    justify-content: center;
    align-items: center;"></i></button>

    <button type="button" class="btn btn-primary " style="float:right; background-color:#98ef7a; border-color: transparent; border-radius: 0px;"> <i class="fas fa-pencil-alt" style="display: flex;
    justify-content: center;
    align-items: center;"></i></button>
  </div>
</div>

<br>

<div class="card1" style="margin: auto;">
  <div class="card-body">
    Sanna Lhodes <button type="button" class="btn btn-primary " style="float:right; background-color:#ef7a7a; border-color: transparent; border-radius: 0px;"> <i class="far fa-trash-alt" style="display: flex;
    justify-content: center;
    align-items: center;"></i></button>

    <button type="button" class="btn btn-primary " style="float:right; background-color:#98ef7a; border-color: transparent; border-radius: 0px;"> <i class="fas fa-pencil-alt" style="display: flex;
    justify-content: center;
    align-items: center;"></i></button>
  </div>
</div>

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

 <button type="button" class="btn btn-primary btn-circle btn-xl" style="margin-left: 373px;"><i class="fas fa-plus"></i>

</form>
</article> <!-- card-body end .// -->

</div> <!-- col.//-->

</div> <!-- row.//-->


<!--container end.//-->

<br><br>


          
        </div>

      </div>
    </section><!-- End ADD HOUSEHOLD Section -->


    <!-- ======= NEXT PAGE BUTTON Section ======= -->
    <section id="testimonials" class="testimonials section-bg">
      <div class="container" style="padding-top: 1px;">

        <div class="form-group">
        <a href="/fhh1"><button type="submit" class="btn btn-primary btn-block">  NEXT PAGE </button></a>
    </div> <!-- form-group// -->

      </div>
    </section><!-- End NEXT PAGE BUTTON Section -->