
@extends('layouts.app')
@section('content')

	<h1>post </h1>
@stop

