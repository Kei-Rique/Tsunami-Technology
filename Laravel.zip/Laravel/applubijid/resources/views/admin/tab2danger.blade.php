@extends('layouts.adminLayout')
@section('tab2danger')

            <!--FORM 2 START-->
            <div class="tab-pane fade" id="tab2danger">
             <div class="container">
 <input class="form-control" id="myInput" type="text" placeholder="Search..">
  <br>
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>ADDRESS</th>
        <th>COORDINATES</th>
        <th>FIRST NAME</th>
        <th>LAST NAME</th>
        <th>MIDDLE NAME</th>
        <th>HOUSE TYPE</th>
      </tr>
    </thead>
    <tbody id="myTable">
      <tr>
        <td>1</td>
        <td>3RD ST, PASAY</td>
        <td>23213</td>
        <td>SAM</td>
        <td>SDASDA</td>
        <td>R</td>
        <td>CASAD</td>
        <td style="width: 10px;"><i class="fa fa-trash" aria-hidden="true" style="font-size:24px"></i>
</td>
      </tr>
    </tbody>
  </table>

  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Popup image</button>

<div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-body">
            <img src="chart.png" style="height:300px; width: 500px;" class="img-responsive">
        </div>
    </div>
  </div>
</div>


<script type="text/javascript">
 function centerModal() {
    $(this).css('display', 'block');
    var $dialog = $(this).find(".modal-dialog");
    var offset = ($(window).height() - $dialog.height()) / 2;
    // Center modal vertically in window
    $dialog.css("margin-top", offset);
}

$('.modal').on('show.bs.modal', centerModal);
$(window).on("resize", function () {
    $('.modal:visible').each(centerModal);
});
</script>


  <div class="file btn btn-lg btn-primary" style=" position: relative; overflow: visible; height: 25px; border-radius: 2px; display: table-cell;
vertical-align: middle; font-size: 15px; background-color: #10a023; border-color: transparent;">
              Upload .csv
      <input type="file" name="file" style=" position: absolute; font-size: 50px; opacity: 0; right: 0; top: 0;" />
  </div>

  </div>
</div>
<!--FORM 2 END-->

@stop
