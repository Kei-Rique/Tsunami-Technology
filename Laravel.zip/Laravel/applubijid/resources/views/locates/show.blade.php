@extends('layout')

@section('mainContent')
	<hi>Show User</h1>
	<div style="color: {{$locate->color}}">
		<strong>{{$locate->Users}}</strong><br>
	</div>
	<strong> Province </strong>
		<p>{{$locate->province}}</p>
		<strong> City </strong>
		<p>{{$locate->City}}</p>
		<strong> Street </strong>
		<p>{{$locate->street}}</p>
		<strong> Zone </strong>
		<p>{{$locate->zone}}</p>
		<strong> House Number </strong>
		<p>{{$locate->house_number}}</p>
		<strong> Baranggay </strong>
		<p>{{$locate->baranggay}}</p>
		<strong> Latitude </strong>
		<p>{{$locate->latitude}}</p>
		<strong> Longitude </strong>
		<p>{{$locate->longitude}}</p>
		
	
	<a href="{{$locate->id}}/edit">Edit User</a>
@endsection