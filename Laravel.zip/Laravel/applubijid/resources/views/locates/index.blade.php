@extends('layout')

@section('mainContent')
	<hi>List of User</h1>
	<table class="table table-striped">
		<thead>
			<tr>
				<th>Users</th>
			
			</tr>
		</thead>
		<tbody>
	@foreach ($locates as $locate)	
		<tr>
			<td><a href="locates/{{$locate->id}}">{{$locate->Users}}</a></td>
			
		@endforeach
		</tbody>
	</table>
	<div><a href="locates/create"> Create User</a> </div>
@endsection
