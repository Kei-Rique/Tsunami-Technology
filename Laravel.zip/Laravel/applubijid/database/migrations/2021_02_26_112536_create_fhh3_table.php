<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFhh3Table extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fhh3', function (Blueprint $table) {
              $table->id();
            $table->string('q52');
            $table->string('q53');
            $table->string('q54');
            $table->string('q55');
            $table->string('q56');
            $table->string('q57');
            $table->string('q58_1');
            $table->string('q58_2');
            $table->string('q58_3');
            $table->string('q58_4');
            $table->string('q58_5');
            $table->string('q59_1');
            $table->string('q59_2');
            $table->string('q59_3');
            $table->string('q59_4');
            $table->string('q59_5');
            $table->string('q59_6');
            $table->string('q59_7');
            $table->string('q59_8');
            $table->string('q59_9');
            $table->string('q59_10');
            $table->string('q59_11');
            $table->string('q59_12');
            $table->string('q59_13');
            $table->string('q59_14');
            $table->string('q59_15');
            $table->string('q59_16');
            $table->string('q59_17');
            $table->string('q59_18');
            $table->string('q59_19');
            $table->string('q59_20');
            $table->string('q59_21');
            $table->string('q59_22');
            $table->string('q59_23');
            $table->string('q59_24');
            $table->string('q59_25');

            $table->string('q60_1');
            $table->string('q60_2');
            $table->string('q60_3');
            $table->string('q60_4');
            $table->string('q60_5');
            $table->string('q60_6');
            $table->string('q60_7');
            $table->string('q60_8');
            $table->string('q60_9');
            $table->string('q60_10');
            $table->string('q60_11');
            $table->string('q60_12');
            $table->string('q60_13');
            $table->string('q60_14');
            $table->string('q60_15');
            $table->string('q60_16');
            $table->string('q60_17');
            $table->string('q60_18');
            $table->string('q60_19');
            $table->string('q60_20');
            $table->string('q60_21');
            $table->string('q60_22');
            $table->string('q60_23');
            $table->string('q60_24');
            $table->string('q60_25');

            $table->string('q61_1');
            $table->string('q61_2');
            $table->string('q61_3');
            $table->string('q61_4');

            $table->string('q62_1');
            $table->string('q62_2');
            $table->string('q62_3');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fhh3');
    }
}
