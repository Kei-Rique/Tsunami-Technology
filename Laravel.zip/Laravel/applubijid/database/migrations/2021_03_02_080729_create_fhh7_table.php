<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFhh7Table extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fhh7', function (Blueprint $table) {
            $table->id();

            $table->string('q148');

            $table->string('q149_1');
            $table->string('q149_2');
            $table->string('q149_3');


            $table->string('q150_1');
            $table->string('q150_2');
            $table->string('q150_3');

            $table->string('q151');


            $table->string('q152_1');
            $table->string('q152_2');
            $table->string('q152_3');


            $table->string('q153_1');
            $table->string('q153_2');
            $table->string('q153_3');


            $table->string('q154_1');
            $table->string('q154_2');
            $table->string('q154_3');


            $table->string('q155_1');
            $table->string('q155_2');
            $table->string('q155_3');
            $table->timestamps();
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fhh7');
    }
}
