<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLocatesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('locates', function (Blueprint $table) {
            $table->id();
            $table->string('Users');
            $table->string('City');
            $table->string('Purok');
            $table->string('province');
            $table->string('street');
            $table->string('zone');
            $table->string('house_number');
            $table->string('baranggay');
            $table->string('latitude');
            $table->string('longitude');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('locates');
    }
}
