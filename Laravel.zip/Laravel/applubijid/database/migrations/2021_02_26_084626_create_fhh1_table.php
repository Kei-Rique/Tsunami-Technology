<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFhh1Table extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fhh1', function (Blueprint $table) {
            $table->id();
            $table->string('surname');
            $table->string('first_name');
            $table->string('middle_name');
            $table->string('date_of_birth');
            $table->string('age');
            $table->string('sex');
            $table->string('nfamily');
            $table->string('rhousehold');
            $table->string('registered_civilregistry');
            $table->string('marital_status');
            $table->string('ethnicity_by_blood');
            $table->string('q12');
            $table->string('q13');
            $table->string('q14');
            $table->string('q15');
            $table->string('q16');
            $table->string('q17');
            $table->string('q18');
            $table->string('q19');
            $table->string('q20');
            $table->string('q21');
            $table->string('q22');
            $table->string('q23');
            $table->string('q24');
            $table->string('q25');
            $table->string('q26');
            $table->string('q27');
            $table->string('q28');
            $table->string('q29');
            $table->string('q30');
            $table->string('q31');
            $table->string('q32');
            $table->string('q33');
            $table->string('q34');
            $table->string('q35');
            $table->string('q36');
            $table->string('q37');
            $table->string('q38');
            $table->string('q39');
            $table->string('q40');
            $table->string('q41');
            $table->string('q42');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fhh1');
    }
}
