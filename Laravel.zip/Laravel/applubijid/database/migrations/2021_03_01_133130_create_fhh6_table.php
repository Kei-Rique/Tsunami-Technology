<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFhh6Table extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fhh6', function (Blueprint $table) {
            $table->id();
            $table->string('q109');
            $table->string('q110');
            $table->string('q111');
            $table->string('q112');
            $table->string('q113_1');
            $table->string('q113_2');
            $table->string('q114_1');
            $table->string('q114_2');
            $table->string('q115_1');
            $table->string('q115_2');
            $table->string('q116_1');
            $table->string('q116_2');
            $table->string('q117');
            $table->string('q118');
            $table->string('q119');
            $table->string('q120');
            $table->string('q121');
            $table->string('q122');
            $table->string('q123');
            $table->string('q124');
            $table->string('q125');
            $table->string('q126');
            $table->string('q127');
            $table->string('q128');
            $table->string('q129');
            $table->string('q130');
            $table->string('q131');
            $table->string('q132');
            $table->string('q133');
            $table->string('q134');
            $table->string('q135');
            $table->string('q136');
            $table->string('q137');
            $table->string('q138');
            $table->string('q139');
            $table->string('q140');
            $table->text('q141_1');
            $table->text('q141_2');
            $table->text('q141_3');
            $table->text('q141_4');
            $table->text('q141_5');
            $table->text('q141_6');
            $table->text('q141_7');
            $table->text('q141_8');
            $table->text('q141_9');
            $table->text('q141_10');
            $table->text('q141_11');
            $table->string('q142_1');
            $table->string('q142_2');
            $table->string('q142_3');
            $table->string('q142_4');
            $table->string('q142_5');
            $table->string('q142_6');
            $table->string('q142_7');
            $table->string('q142_8');
            $table->string('q142_9');
            $table->string('q142_10');
            $table->text('q142_11');
            $table->text('q143_1');
            $table->text('q143_2');
            $table->text('q143_3');
            $table->text('q143_4');
            $table->text('q143_5');
            $table->text('q143_6');
            $table->text('q143_7');
            $table->text('q143_8');
            $table->text('q143_9');
            $table->text('q143_10');
            $table->text('q143_11');
            $table->string('q144_1');
            $table->string('q144_2');
            $table->string('q144_3');
            $table->string('q144_4');
            $table->string('q144_5');
            $table->string('q144_6');
            $table->string('q144_7');
            $table->string('q144_8');
            $table->string('q144_9');
            $table->string('q144_10');
            $table->string('q144_11');
            $table->string('q145');
            $table->text('q146_1');
            $table->text('q146_2');
            $table->text('q146_3');
            $table->text('q146_4');
            $table->text('q146_5');
            $table->text('q146_6');
            $table->text('q146_7');
            $table->text('q146_8');
            $table->text('q146_9');
            $table->text('q146_10');
            $table->text('q146_11');
            $table->text('q146_12');
            $table->text('q146_13');
            $table->string('q147_1');
            $table->string('q147_2');
            $table->string('q147_3');
            $table->string('q147_4');
            $table->string('q147_5');
            $table->string('q147_6');
            $table->string('q147_7');
            $table->string('q147_8');
            $table->string('q147_9');
            $table->string('q147_10');
            $table->string('q147_11');
            $table->string('q147_12');
            $table->string('q147_13');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fhh6');
    }
}
