<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFhh5Table extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fhh5', function (Blueprint $table) {
            $table->id();
            $table->string('q92');

            $table->string('q93');

            $table->text('q94_1');
            $table->text('q94_2');
            $table->text('q94_3');
            $table->text('q94_4');
            $table->text('q94_5');

            $table->text('q95_1');
            $table->text('q95_2');
            $table->text('q95_3');
            $table->text('q95_4');
            $table->text('q95_5');

            $table->text('q96_1');
            $table->text('q96_2');
            $table->text('q96_3');
            $table->text('q96_4');
            $table->text('q96_5');
            $table->text('q96_6');
            $table->text('q96_7');
            $table->text('q96_8');
            $table->text('q96_9');
            $table->text('q96_10');
            $table->text('q96_11');
            $table->text('q96_12');
            $table->text('q96_13');
            $table->text('q96_14');
            $table->text('q96_15');
            $table->text('q96_16');
            $table->text('q96_17');
            $table->text('q96_18');

            $table->text('q97');

            $table->text('q98_1');
            $table->text('q98_2');
            $table->text('q98_3');
            $table->text('q98_4');
            $table->text('q98_5');

            $table->string('q99_a1');
            $table->string('q99_a2');
            $table->string('q99_a3');
            $table->string('q99_a4');
            $table->string('q99_a5');
            $table->string('q99_b1');
            $table->string('q99_b2');
            $table->string('q99_b3');
            $table->string('q99_b4');
            $table->string('q99_b5');

            $table->string('q100_1');
            $table->string('q100_2');

            $table->string('q101');

            $table->string('q102_1');
            $table->string('q102_2');
            $table->string('q102_3');
            $table->string('q102_4');
            $table->string('q102_5');
          

            $table->string('q104_1');
            $table->string('q104_2');
            $table->string('q104_3');
            $table->string('q104_4');
            $table->string('q104_5');

            $table->string('q105_1');
            $table->string('q105_2');
            $table->string('q105_3');
            $table->string('q105_4');
            $table->string('q105_5');

            $table->string('q106_1');
            $table->string('q106_2');
            $table->string('q106_3');
            $table->string('q106_4');
            $table->string('q106_5');
            $table->string('q106_6');
            $table->string('q106_7');
            $table->string('q106_8');
            $table->string('q106_9');

            $table->string('q107_1');
            $table->string('q107_2');
            $table->string('q107_3');
            $table->string('q107_4');
            $table->string('q107_5');

            $table->string('q108_1');
            $table->string('q108_2');
            $table->string('q108_3');
            $table->string('q108_4');
            $table->string('q108_5');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fhh5');
    }
}
