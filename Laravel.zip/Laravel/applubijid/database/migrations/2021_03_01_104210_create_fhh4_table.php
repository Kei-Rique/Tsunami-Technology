<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFhh4Table extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fhh4', function (Blueprint $table) {
            $table->id();
            $table->string('crop'); 
            $table->string('crop_cash'); 
            $table->string('crop_kind');
            $table->string('livestock');
            $table->string('livestock_cash');
            $table->string('livestock_kind');
            $table->string('fishing');
            $table->string('fishing_cash');
            $table->string('fishing_kind');
            $table->string('forestry');
            $table->string('forestry_cash');
            $table->string('forestry_kind');
            $table->string('wholesale');
            $table->string('wholesale_cash');
            $table->string('wholesale_kind');
            $table->string('manufacturing');
            $table->string('manufacturing_cash');
            $table->string('manufacturing_kind');
            $table->string('community');
            $table->string('community_cash');
            $table->string('community_kind');
            $table->string('transportation');
            $table->string('transportation_cash');
            $table->string('transportation_kind');
            $table->string('mining');
            $table->string('mining_cash');
            $table->string('mining_kind');
            $table->string('construction');
            $table->string('construction_cash');
            $table->string('construction_kind');
            $table->string('activities');
            $table->string('activities_cash');
            $table->string('activities_kind');
            
            $table->string('total_ent_act');
            $table->string('total_salaries');
            
            $table->string('share_crops_cash');
            $table->string('share_crops_kind');
            $table->string('remittance_cash');
            $table->string('remittance_kind');
            $table->string('cashreceipts_cash');
            $table->string('cashreceipts_kind');
            $table->string('cashsupport_cash');
            $table->string('cashsupport_kind');
            $table->string('rentals_cash');
            $table->string('rentals_kind');
            $table->string('interest_cash');
            $table->string('interest_kind');
            $table->string('pension_cash');
            $table->string('pension_kind');
            $table->string('dividends_cash');
            $table->string('dividends_kind');
            $table->string('other_sources_cash');
            $table->string('other_sources_kind');
            
            $table->string('q88_cash');
            $table->string('q88_kind');
            $table->string('q89_cash');
            $table->string('q89_kind');
            $table->string('q90_cash');
            $table->string('q90_kind');
            $table->string('q91_cash');
            $table->string('q91_kind');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fhh4');
    }
}
