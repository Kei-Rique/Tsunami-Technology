<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFhh2Table extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fhh2', function (Blueprint $table) {
            $table->id();
            $table->string('q43');
            $table->string('q44');
            $table->string('q45');
            $table->string('q46');
            $table->string('q47');
            $table->string('q48');
            $table->string('q49');
            $table->string('q50');
            $table->string('q50b');
            $table->string('q51');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fhh2');
    }
}
