<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PostController;

//Route::resource('post', 'PostController');

Route::get('/login', [PostController::class, 'login']);
Route::get('/chub', [PostController::class, 'chub']);
Route::get('/start_form', [PostController::class, 'start_form']);
Route::get('/demography', [PostController::class, 'demography']);
Route::get('/fhh1', [PostController::class, 'fhh1']);
Route::get('/fhh2', [PostController::class, 'fhh2']);
Route::get('/fhh3', [PostController::class, 'fhh3']);


/*Route::get('/login', function () {
     return view('login');

     
});

Route::get('/create1', function () {
     return view('create1');

     
});
*/
