<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FormController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\fhh1_Controller;
use App\Http\Controllers\Fhh2Controller;
use App\Http\Controllers\Fhh3Controller;
use App\Http\Controllers\Fhh4Controller;
use App\Http\Controllers\Fhh5Controller;
use App\Http\Controllers\Fhh6Controller;
use App\Http\Controllers\Fhh7Controller;

//Route::resource('post', 'PostController');
Route::get('/start_form', [FormController::class, 'create']);
Route::post('/start_form', [FormController::class, 'store']);
Route::get('/fhh1', [fhh1_Controller::class, 'create']);
Route::post('/fhh1', [fhh1_Controller::class, 'store']);
Route::get('/fhh2', [Fhh2Controller::class, 'create']);
Route::post('/fhh2', [Fhh2Controller::class, 'store']);
Route::get('/fhh3', [Fhh3Controller::class, 'create']);
Route::post('/fhh3', [Fhh3Controller::class, 'store']);
Route::get('/fhh4', [Fhh4Controller::class, 'create']);
Route::post('/fhh4', [Fhh4Controller::class, 'store']);
Route::get('/fhh5', [Fhh5Controller::class, 'create']);
Route::post('/fhh5', [Fhh5Controller::class, 'store']);
Route::get('/fhh6', [Fhh6Controller::class, 'create']);
Route::post('/fhh6', [Fhh6Controller::class, 'store']);
Route::get('/fhh7', [Fhh7Controller::class, 'create']);
Route::post('/fhh7', [Fhh7Controller::class, 'store']);




Route::get('/login', [PostController::class, 'login']);
Route::get('/chub', [PostController::class, 'chub']);
Route::get('/start_form', [PostController::class, 'start_form']);
Route::get('/demography', [PostController::class, 'demography']);
Route::get('/fhh1', [PostController::class, 'fhh1']);
Route::get('/fhh2', [PostController::class, 'fhh2']);
Route::get('/fhh3', [PostController::class, 'fhh3']);
Route::get('/fhh4', [PostController::class, 'fhh4']);
Route::get('/fhh5', [PostController::class, 'fhh5']);
Route::get('/fhh6', [PostController::class, 'fhh6']);
Route::get('/fhh7', [PostController::class, 'fhh7']);
Route::get('/ty', [PostController::class, 'ty']);

Route::get('/admin', [PostController::class, 'admin']);
Route::get('/chart', [PostController::class, 'chart']);

/*Route::get('/login', function () {
     return view('login');

     
});

Route::get('/create1', function () {
     return view('create1');

     
});
*/
