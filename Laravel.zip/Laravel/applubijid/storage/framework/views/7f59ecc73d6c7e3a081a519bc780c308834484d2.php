<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo e($title); ?></title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i, 700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/line-awesome/css/line-awesome.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">


  <!-- Template Main CSS File -->
  <link href="assets/css/fhh6.css" rel="stylesheet">
</head>

<body>

  <!-- ======= IDENTIFICATION Section ======= -->
   <section id="about" class="about" style="background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:45px; color: black; margin-left: -391px; padding-bottom: 40px; font-family: Raleway; margin-top: -10px;"> 
              Climate Change</p>
              </div>
              </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

  <!-- End IDENTIFICATION Section -->

                                        
        <!-- HOUSING CHARACTERISTICS 2 Services Section -->

               <section id="services" class="services" style=" background:#b7d8ef">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -135px; height: 300%; padding-bottom: 45px; margin-left: -295px; width: 50rem; background-color: #b7d8ef" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  (109) How many years has the household been living in the barangay </label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> 3 years and above (GO TO 110)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> Not more than 3 years (GO TO 141)</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>

            <!-- HOUSING CHARACTERISTICS 2 Services Section -->
           <section id="about" class="about">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -395px; margin-bottom: 30px; font-family: Raleway; margin-top: -10px;"> 
              Crop Farming</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: white;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change <br><br><br><b><b>Ask Questions (98) - (99) if CODE ‘1’ in (67), IF CODE ‘2’ in (67), PROCEED TO(100)</b></b>
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -135px; height: 300%; padding-bottom: 45px; margin-left: -295px; width: 50rem;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(110) How many years has the household been engaged in crop farming?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> 3 years and above (GO TO 111)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> Not more than 3 years (GO TO 117)</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services" class="services" style=" background:white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -150px; height: 300%; padding-bottom: 55px; margin-left: -295px; width: 50rem;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                 <b> (111) Compared with 3 years ago, did your harvest _____ ? </b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Decrease (GO TO 112)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> Increase (GO TO 115)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> Remain the same (GO TO 115))</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>

               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services" class="services" style=" background:white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -173px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(112) What is the primary reason for the decrease in the harvest?</b> </label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Decrease (GO TO 112)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> Increase (GO TO 115)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> Remain the same (GO TO 115))</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>

            <!-- HOUSING CHARACTERISTICS 2 Services Section -->
            <section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -192px; height: 90%; margin-left: -295px; width: 50rem; background-color: white;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 33px;">
                                  <b>(113) During the past 3 years, did you do the following in the last planting season?</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group">
                              <label style="margin-left: 180px;margin-bottom: 33px;">
                                  <b>(114) Why?</b></label><br>
                            </div> <!-- form-group end.// -->   
           </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 60px; margin-top: 20px; width: 320px;">
                                  113.1 - Changed the variety of the same crop  </label><br>
                          </div>

                          <div class="col form-group" style="margin-top: 15px; margin-left: -10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>
                          <div class="col form-group">
                            <div class="dropdown">
                        <select required style="margin-left: 5px; margin-top: 20px; width: 170px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 60px; margin-top: 20px; width: 320px;">
                                  113.2 - Changed major crop </label><br>
                          </div>

                          <div class="col form-group" style="margin-top: 15px; margin-left: -10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>
                          <div class="col form-group">
                            <div class="dropdown">
                        <select required style="margin-left: 5px; margin-top: 20px; width: 170px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

               <!-- HOUSING CHARACTERISTICS 2 Services Section -->

 <section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-bottom:40px;padding-left: 10px; margin-top: -312px; height: 110%; margin-left: -295px; width: 50rem; background-color: white;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 33px;">
                                  <b>(115) Do you have an insurance for the following?</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group">
                              <label style="margin-left: 180px;margin-bottom: 33px;">
                                  <b>(116) Who is the insurance provider?</b></label><br>
                            </div> <!-- form-group end.// -->   
           </div> <!-- form-row end.// -->

                         <div class="form-row" style="margin-top: 20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 60px; margin-top: 20px; width: 320px;">
                                  115.1 - Crops  </label><br>
                          </div>

                          <div class="col form-group" style="margin-top: 15px; margin-left: -10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>
                          <div class="col form-group">
                            <div class="dropdown">
                        <select required style="margin-left: 5px; margin-top: 20px; width: 170px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: 20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 60px; margin-top: 20px; width: 320px;">
                                  115.2 - Agricultural equipment/facilities </label><br>
                          </div>

                          <div class="col form-group" style="margin-top: 15px; margin-left: -10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>
                          <div class="col form-group">
                            <div class="dropdown">
                        <select required style="margin-left: 5px; margin-top: 20px; width: 170px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

        <!-- ======= IDENTIFICATION Section ======= -->
   <section id="about" class="about" style="margin-top: -350px;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -394px; margin-bottom: 30px; font-family: Raleway; margin-top: -10px;"> 
              Livestock and Poultry</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: white;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change <br><br><br><b><b>Ask Questions (117) - (121) if CODE ‘1’ in (67) and in (109)</b></b>
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -165px; height: 300%; padding-bottom: 70px; margin-left: -295px; width: 50rem;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(117) How many years has the household been engaged in livestock and poultry raising?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> 3 years and above (GO TO 118)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> Not more than 3 years (GO TO 120)</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services" class="services" style=" background:white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -185px; height: 300%; padding-bottom: 85px; margin-left: -295px; width: 50rem;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                 <b> (118) Compared with 3 years ago, did the number of your livestock and poultry _____?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Decrease (GO TO 119) </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> Increase (GO TO 120) </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> Remain the same (GO TO 120)</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>

               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services" class="services" style=" background:white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -203px; height: 300%; padding-bottom: 100px; margin-left: -295px; width: 50rem;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(119) What is the primary reason for the decrease in the number of livestock and poultry?</b> </label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="dropdown">
                        <select required style="margin-left: 20px; margin-top: 20px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>

            <!-- HOUSING CHARACTERISTICS 2 Services Section -->
            <section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -204px; height: 90%; margin-left: -295px; width: 50rem; background-color: white; padding-bottom: 90px;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 33px;">
                                  <b>(120) Do you have livestock and poultry<br> insurance?</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group">
                              <label style="margin-left: 8px;margin-bottom: 33px;">
                                  <b>(121) Who is the insurance provider?</b></label><br>
                            </div> <!-- form-group end.// -->   
           </div> <!-- form-row end.// -->

                         <div class="form-row" style="margin-top: 40px;">
                       <div class="col form-group" style="margin-top: 15px; margin-left: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>
                          <div class="col form-group">
                            <div class="dropdown">
                        <select required style="margin-left: 5px; margin-top: 20px; width: 170px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>
                         </div>

                         <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
<section id="about" class="about" style="margin-top: -350px;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -393px; margin-bottom: 30px; font-family: Raleway; margin-top: 50px;"> 
              Fishing</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: white;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change <br><br><br><b><b>Ask Questions (122) - (126) if CODE ‘1’ in (68) and in (109)</b></b>
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -165px; height: 300%; padding-bottom: 70px; margin-left: -295px; width: 50rem;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(122) How many years has the household been engaged in fishing?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> 3 years and above (GO TO 123)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> Not more than 3 years (GO TO 125)</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services" class="services" style=" background:white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -185px; height: 300%; padding-bottom: 85px; margin-left: -295px; width: 50rem;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                 <b> (123) Compared with 3 years ago, did your fish catch _____?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Decrease (GO TO 124) </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> Increase (GO TO 125) </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> Remain the same (GO TO 125)</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>

               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services" class="services" style=" background:white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -203px; height: 300%; padding-bottom: 100px; margin-left: -295px; width: 50rem;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(124) What is the primary reason for the decrease in fish catch?</b> </label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="dropdown">
                        <select required style="margin-left: 20px; margin-top: 20px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>

            <!-- HOUSING CHARACTERISTICS 2 Services Section -->
            <section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -204px; height: 90%; margin-left: -295px; width: 50rem; background-color: white; padding-bottom: 90px;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 33px;">
                                  <b>(125) Do you have fisheries insurance?</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group">
                              <label style="margin-left: 8px;margin-bottom: 33px;">
                                  <b>(126) Who is the insurance provider?</b></label><br>
                            </div> <!-- form-group end.// -->   
           </div> <!-- form-row end.// -->

                         <div class="form-row" style="margin-top: 40px;">
                       <div class="col form-group" style="margin-top: 15px; margin-left: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>
                          <div class="col form-group">
                            <div class="dropdown">
                        <select required style="margin-left: 5px; margin-top: 20px; width: 170px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>
                         </div>

                         <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>
 
       <!-- HOUSING CHARACTERISTICS 2 Services Section -->
       <!-- ======= IDENTIFICATION Section ======= -->
  <section id="about" class="about" style="margin-top: -230px; background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -401px; margin-bottom: 30px; font-family: Raleway; margin-top: -10px; "> 
              Temperature</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(127) Compared with 3 years ago, is the temperature hotter now in your area?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1">Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">No</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>
       <!-- HOUSING CHARACTERISTICS 2 Services Section -->
<section id="about" class="about" style="margin-top: -230px; background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -401px; margin-bottom: 30px; font-family: Raleway; margin-top: -10px; "> 
              Electricity</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(128) Compared with 3 years ago, are brownouts more frequent now in your area?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1">Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">No</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="about" class="about" style="margin-top: -230px; background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -401px; margin-bottom: 30px; font-family: Raleway; margin-top: -10px; "> 
              Sea Level</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(129) Compared with 3 years ago, did the sea level  _____ in your area?</b></label><br>

                                  <div class="col form-group" style="margin-top: 20px;">
                             <div class="dropdown">
                        <select required style="margin-left: 5px; width: 250px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>
                 <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="about" class="about" style="margin-top: -230px; background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -401px; margin-bottom: 30px; font-family: Raleway; margin-top: -10px; "> 
              Water</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(130) Compared with 3 years ago, did the water supply _____ in your area?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                             <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Decrease (GO TO 130)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  Increase (GO TO 131)  </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  Remain the same (GO TO 131)  </label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(131) What is the primary reason for the decrease in water supply</b></label><br>

                                  <div class="col form-group" style="margin-top: 20px;">
                             <div class="dropdown">
                        <select required style="margin-left: 5px; width: 250px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>
                 <!-- HOUSING CHARACTERISTICS 2 Services Section -->

                  <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="about" class="about" style="margin-top: -230px; background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -401px; margin-bottom: 30px; font-family: Raleway; margin-top: -10px; "> 
              Flooding</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(132) Compared with 3 years ago, do floods occur more often in your area now?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                             <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes (GO TO 132)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no (GO TO 135) </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  Did not experience flood (GO TO 135)  </label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 90px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(133) Three years ago, how long did it usually take for the flood to subside? (In Hours)</b></label><br>

                                  <div class="col form-group" style="margin-top: 20px;">
                             <input type="text" class="form-control1" style="margin-left: 20px; width: 200px;"placeholder="">
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>

                 <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -224px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(134) During the past 12 months, how long did it usually take for the flood to subside? (In Hours)</b></label><br>

                                  <div class="col form-group" style="margin-top: 20px;">
                             <div class="dropdown">
                        <select required style="margin-left: 5px; width: 250px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>

              <section id="about" class="about" style="margin-top: -230px; background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -401px; margin-bottom: 30px; font-family: Raleway; margin-top: 20px; "> 
              Drought</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(135) Compared 3 years ago, does drought occur more often in your area now?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                             <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes (GO TO 136)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no (GO TO 137 )  </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> Did not experience drought (GO TO 137)  </label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(136) In the past 3 years, how long did the last drought occur?</b></label><br>

                                  <div class="col form-group" style="margin-top: 20px;">
                             <div class="dropdown">
                        <select required style="margin-left: 5px; width: 250px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>
                 <!-- HOUSING CHARACTERISTICS 2 Services Section -->
                 <section id="about" class="about" style="margin-top: -230px; background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -401px; margin-bottom: 30px; font-family: Raleway; margin-top: 20px; "> 
              Evacuation</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(137) During the past 3 years, did you move out of/from your previous dwelling unit?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                             <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes (GO TO 136)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no (GO TO 137 )  </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> Did not experience drought (GO TO 137)  </label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
                <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(138) What was your primary reason for moving out of your previous dwelling unit?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                             <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes (GO TO 136)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no (GO TO 137 )  </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> Did not experience drought (GO TO 137)  </label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
                <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(139) During the past 3 years, did you temporarily evacuate your house because of any calamity?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                             <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes (GO TO 136)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no (GO TO 137 )  </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> Did not experience drought (GO TO 137)  </label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->

               <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(140) Where did you stay when you temporarily evacuated?</b></label><br>

                                  <div class="col form-group" style="margin-top: 20px;">
                             <div class="dropdown">
                        <select required style="margin-left: 5px; width: 250px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="about" class="about" style="margin-top: -230px; background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -401px; margin-bottom: 30px; font-family: Raleway; margin-top: 20px; "> 
              Calamity</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 140%; padding-bottom: 20px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                      <form>
                       
                         <div class="form-row" style="font-size: 11px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>(141) During the past 12 months, did your household experience destructive calammities such as a/an:</b></label><br>
                            </div>
                            <div class="col form-group">
                                <label style="margin-left: 40px;margin-bottom: 1px; ">
                                  <b>(142) How many times <br> did the ___ happen?</b></label>
                            </div>
                            <div class="col form-group">
                              <label style="margin-left: 40px;margin-bottom: 1px; ">
                                  <b>(143) Did you receive <br> any kind of assistance?</b></label><br>
                            </div>
                            <div class="col form-group">
                                <label style="margin-left: 40px;margin-bottom: 1px; ">
                                  <b>(144) Where did it <br> come from?</b></label>
                            </div>

                        </div> <!-- form-row end.// -->

                        <div class="form-row" style="font-size: 11px; margin-top: 40px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>1. Typhoon</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top:-10px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select required style="margin-left: 30px; margin-top: -10px; width: 100px; font-size: 10px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px; margin-top: -10px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>2. Flood</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top:-10px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select required style="margin-left: 30px; margin-top: -10px; width: 100px; font-size: 10px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px; margin-top: -10px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>3. Drought</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top:-10px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select required style="margin-left: 30px; margin-top: -10px; width: 100px; font-size: 10px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px; margin-top: -10px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>4. Earthquake</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top:-10px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select required style="margin-left: 30px; margin-top: -10px; width: 100px; font-size: 10px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px; margin-top: -10px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>5. Volcanic<br> Eruption</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top:-10px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select required style="margin-left: 30px; margin-top: -10px; width: 100px; font-size: 10px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px; margin-top: -10px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>6. Landslide<br>/Mudslide</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top:-10px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select required style="margin-left: 30px; margin-top: -10px; width: 100px; font-size: 10px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px; margin-top: -10px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>7. Tsunami</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top:-10px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select required style="margin-left: 30px; margin-top: -10px; width: 100px; font-size: 10px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px; margin-top: -10px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>8. Fire</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top:-10px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select required style="margin-left: 30px; margin-top: -10px; width: 100px; font-size: 10px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px; margin-top: -10px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>9. Forest Fire</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top:-10px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select required style="margin-left: 30px; margin-top: -10px; width: 100px; font-size: 10px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px; margin-top: -10px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>10. Armed <br> conflict</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top:-10px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select required style="margin-left: 30px; margin-top: -10px; width: 100px; font-size: 10px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px; margin-top: -10px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>11. Others,<br> specify</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top:-10px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-top:-10px;margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select required style="margin-left: 30px; margin-top: -10px; width: 100px; font-size: 10px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
              <section id="about" class="about" style="margin-top: -230px; background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -401px; margin-bottom: 30px; font-family: Raleway; margin-top: 50px; "> 
              Disaster Preparedness</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(145) Do you have a disaster preparedness kit?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                             <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> yes (GO TO 146) </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2">  no (GO TO 147) </label>
                          </div>
                          </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services2" class="services2" style=" background: #b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -204px; height: 80%; margin-left: -295px; width: 50rem; background-color: #b7d8ef; padding-bottom: 40px;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 33px;">
                                  <b>(146) Do you have the following in your disaster preparedness kit?</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group">
                              <label style="margin-left: 88px;margin-bottom: 33px;">
                                  <b>(147) How many days will it last?</b></label><br>
                            </div> <!-- form-group end.// -->   
           </div> <!-- form-row end.// -->

                         <div class="form-row" style="margin-top: 10px;">
                          <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; margin-top: 20px; ">
                                  <b>1. Water</b></label><br>
                            </div>
                       <div class="col form-group" style="margin-top: 15px; margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top: 20px;width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -10px;">
                          <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; margin-top: 20px; ">
                                  <b>2. Food (canned goods, biscuits, bread)</b></label><br>
                            </div>
                       <div class="col form-group" style="margin-top: 15px; margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top: 20px;width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -10px;">
                          <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; margin-top: 20px; ">
                                  <b>3. Matches/Lighter</b></label><br>
                            </div>
                       <div class="col form-group" style="margin-top: 15px; margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top: 20px;width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -10px;">
                          <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; margin-top: 20px; ">
                                  <b>4. Flashlight/Emergency ligHt</b></label><br>
                            </div>
                       <div class="col form-group" style="margin-top: 15px; margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top: 20px;width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -10px;">
                          <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; margin-top: 20px; ">
                                  <b>5. Radio/Transistor (battery-operated)</b></label><br>
                            </div>
                       <div class="col form-group" style="margin-top: 15px; margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top: 20px;width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -10px;">
                          <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; margin-top: 20px; ">
                                  <b>6. Candle</b></label><br>
                            </div>
                       <div class="col form-group" style="margin-top: 15px; margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top: 20px;width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -10px;">
                          <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; margin-top: 20px; ">
                                  <b>7. Medical Kit</b></label><br>
                            </div>
                       <div class="col form-group" style="margin-top: 15px; margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top: 20px;width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -10px;">
                          <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; margin-top: 20px; ">
                                  <b>8. Whistle</b></label><br>
                            </div>
                       <div class="col form-group" style="margin-top: 15px; margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top: 20px;width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -10px;">
                          <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; margin-top: 20px; ">
                                  <b>9. Clothes</b></label><br>
                            </div>
                       <div class="col form-group" style="margin-top: 15px; margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top: 20px;width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -10px;">
                          <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; margin-top: 20px; ">
                                  <b>10. Blanket</b></label><br>
                            </div>
                       <div class="col form-group" style="margin-top: 15px; margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top: 20px;width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -10px;">
                          <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; margin-top: 20px; ">
                                  <b>11. Battery (Cellphone, flashlight, radio etc.)</b></label><br>
                            </div>
                       <div class="col form-group" style="margin-top: 15px; margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top: 20px;width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -10px;">
                          <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; margin-top: 20px; ">
                                  <b>12. Important documents (land title, birth certificate, etc.)</b></label><br>
                            </div>
                       <div class="col form-group" style="margin-top: 15px; margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top: 20px;width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -10px;">
                          <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; margin-top: 20px; ">
                                  <b>13. Others, Specify</b></label><br>
                            </div>
                       <div class="col form-group" style="margin-top: 15px; margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 30px; margin-top: 20px;width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>





                         <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>
 
               <!-- ======= NEXT PAGE BUTTON Section ======= -->
       <section id="testimonials" class="testimonials section-bg" style="margin-top: -90px;">
         <div class="container">
            <div class="form-group">
              <button type="submit" class="btn btn-primary btn-block"> <a href="/fhh7"> NEXT PAGE</a> </button>
            </div> <!-- form-group// -->
          </div>
       </section>

        <!-- End NEXT PAGE BUTTON Section -->
<?php /**PATH C:\Users\ASUS\Desktop\Laravel\applubijid\resources\views//pages/fhh6.blade.php ENDPATH**/ ?>