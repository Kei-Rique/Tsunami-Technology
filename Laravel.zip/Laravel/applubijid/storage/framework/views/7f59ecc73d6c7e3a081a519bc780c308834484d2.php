<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo e($title); ?></title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i, 700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/line-awesome/css/line-awesome.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">


  <!-- Template Main CSS File -->
  <link href="assets/css/fhh6.css" rel="stylesheet">
</head>

<body>

  <!-- ======= IDENTIFICATION Section ======= -->
   <section id="about" class="about" style="background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:45px; color: black; margin-left: -391px; padding-bottom: 40px; font-family: Raleway; margin-top: -10px;"> 
              Climate Change</p>
              </div>
              </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

  <!-- End IDENTIFICATION Section -->

                                        
        <!-- HOUSING CHARACTERISTICS 2 Services Section -->
        <form method="post" action="/fhh6">
                <?php echo csrf_field(); ?>
               <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 20px; padding-left: 10px; margin-top: -135px; height: 300%; padding-bottom: 55px; margin-left: -295px; width: 50rem; background-color: #b7d8ef" >

                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  (109) How many years has the household been living in the barangay </label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q109" id="q109" name="q109" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > 3 years and above (GO TO 110)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q109" id="q109" name="q109" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > Not more than 3 years (GO TO 141)</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>

            <!-- HOUSING CHARACTERISTICS 2 Services Section -->
           <section id="about" class="about">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -395px; margin-bottom: 30px; font-family: Raleway; margin-top: -10px;"> 
              Crop Farming</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: white;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change <br><br><br><b><b>Ask Questions (98) - (99) if CODE ‘1’ in (67), IF CODE ‘2’ in (67), PROCEED TO(100)</b></b>
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -135px; height: 300%; padding-bottom: 50px; margin-left: -295px; width: 50rem;" >

                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(110) How many years has the household been engaged in crop farming?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q110" id="q110" name="q110" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > 3 years and above (GO TO 111)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q110" id="q110" name="q110" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > Not more than 3 years (GO TO 117)</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services" class="services" style=" background:white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -170px; height: 300%; padding-bottom: 65px; margin-left: -295px; width: 50rem;" >

                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                 <b> (111) Compared with 3 years ago, did your harvest _____ ? </b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q111" id="q111" name="q111" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Decrease (GO TO 112)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q111" id="q111" name="q111" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > Increase (GO TO 115)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q111" id="q111" name="q111" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > Remain the same (GO TO 115))</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>

               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services" class="services" style=" background:white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -190px; height: 300%; padding-bottom: 70px; margin-left: -295px; width: 50rem;" >

                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(112) What is the primary reason for the decrease in the harvest?</b> </label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q112" id="q112" name="q112" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Decrease (GO TO 112)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q112" id="q112" name="q112" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > Increase (GO TO 115)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q112" id="q112" name="q112" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > Remain the same (GO TO 115))</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>

            <!-- HOUSING CHARACTERISTICS 2 Services Section -->
            <section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -192px; padding-bottom: 110px;height: 90%; margin-left: -295px; width: 50rem; background-color: white;" >

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;">
                                  <b>(113) During the past 3 years, did you do the following in the last planting season?</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group">
                              <label style="margin-left: 180px;margin-bottom: 33px;">
                                  <b>(114) Why?</b></label><br>
                            </div> <!-- form-group end.// -->   
           </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 30px; margin-top: 10px; width: 320px;">
                                  113.1 - Changed the variety of the same crop  </label><br>
                          </div>

                          <div class="col form-group" style="margin-top: 12px; margin-left: -10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q113_1" id="q113_1" name="q113_1" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q113_1" id="q113_1" name="q113_1" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>
                          <div class="col form-group">
                            <div class="dropdown">
                        <select for="q114_1" id="q114_1" name="q114_1" required style="margin-left: 5px; margin-top: 12px; width: 170px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="ent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 60px; width: 320px;">
                                  113.2 - Changed major crop </label><br>
                          </div>

                          <div class="col form-group" style="margin-left: -10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q113_2" id="q113_2" name="q113_2" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q113_2" id="q113_2" name="q113_2" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>
                          <div class="col form-group">
                            <div class="dropdown">
                        <select for="q114_2" id="q114_2" name="q114_2" required style="margin-left: 5px; width: 170px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT) ">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

               <!-- HOUSING CHARACTERISTICS 2 Services Section -->

 <section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-bottom:170px;padding-left: 10px; margin-top: -312px; height: 110%; margin-left: -295px; width: 50rem; background-color: white;" >

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;">
                                  <b>(115) Do you have an insurance for the following?</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group">
                              <label style="margin-left: 180px;">
                                  <b>(116) Who is the insurance provider?</b></label><br>
                            </div> <!-- form-group end.// -->   
           </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 20px;width: 320px;">
                                  115.1 - Crops  </label><br>
                          </div>

                          <div class="col form-group" style="margin-left: -10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q115_1" id="q115_1" name="q115_1" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q115_1" id="q115_1" name="q115_1" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>
                          <div class="col form-group">
                            <div class="dropdown">
                        <select for="q116_1" id="q116_1" name="q116_1" required style="margin-left: 5px; swidth: 170px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 20px; width: 320px;">
                                  115.2 - Agricultural equipment/facilities </label><br>
                          </div>

                          <div class="col form-group" style="margin-left: -10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input  for="q115_2" id="q115_2" name="q115_2" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q115_2" id="q115_2" name="q115_2" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>
                          <div class="col form-group">
                            <div class="dropdown">
                        <select for="q116_2" id="q116_2" name="q116_2" required style="margin-left: 5px; width: 170px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

        <!-- ======= IDENTIFICATION Section ======= -->
   <section id="about" class="about" style="margin-top: -350px;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -394px; margin-bottom: 30px; font-family: Raleway; margin-top: 20px;"> 
              Livestock and Poultry</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: white;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change <br><br><br><b><b>Ask Questions (117) - (121) if CODE ‘1’ in (67) and in (109)</b></b>
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -165px; height: 300%; padding-bottom: 70px; margin-left: -295px; width: 50rem;" >

                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(117) How many years has the household been engaged in livestock and poultry raising?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q117" id="q117" name="q117" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > 3 years and above (GO TO 118)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q117" id="q117" name="q117" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > Not more than 3 years (GO TO 120)</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services" class="services" style=" background:white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -195px; height: 300%; padding-bottom: 85px; margin-left: -295px; width: 50rem;" >

                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                 <b> (118) Compared with 3 years ago, did the number of your livestock and poultry _____?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q118" id="q118" name="q118" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Decrease (GO TO 119) </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q118" id="q118" name="q118" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > Increase (GO TO 120) </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q118" id="q118" name="q118" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > Remain the same (GO TO 120)</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>

               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services" class="services" style=" background:white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -195px; height: 300%; padding-bottom: 100px; margin-left: -295px; width: 50rem;" >

                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(119) What is the primary reason for the decrease in the number of livestock and poultry?</b> </label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="dropdown">
                        <select for="q119" id="q119" name="q119" required style="margin-left: 20px; margin-top: 20px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>

            <!-- HOUSING CHARACTERISTICS 2 Services Section -->
            <section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -210px; height: 90%; margin-left: -295px; width: 50rem; background-color: white; padding-bottom: 100px;" >

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;">
                                  <b>(120) Do you have livestock and poultry<br> insurance?</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group">
                              <label style="margin-left: 8px;">
                                  <b>(121) Who is the insurance provider?</b></label><br>
                            </div> <!-- form-group end.// -->   
           </div> <!-- form-row end.// -->

                         <div class="form-row">
                       <div class="col form-group" style="margin-left: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q120" id="q120" name="q120" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q120" id="q120" name="q120" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>
                          <div class="col form-group">
                            <div class="dropdown">
                        <select for="q121" id="q121" name="q121" required style="margin-left: 5px; width: 170px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT) ">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>
                         </div>

                         <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
<section id="about" class="about" style="margin-top: -350px;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -393px; margin-bottom: 30px; font-family: Raleway; margin-top: 90px;"> 
              Fishing</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: white;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change <br><br><br><b><b>Ask Questions (122) - (126) if CODE ‘1’ in (68) and in (109)</b></b>
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -165px; height: 300%; padding-bottom: 70px; margin-left: -295px; width: 50rem;" >

                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(122) How many years has the household been engaged in fishing?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q122" id="q122" name="q122" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > 3 years and above (GO TO 123)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q122" id="q122" name="q122" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > Not more than 3 years (GO TO 125)</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services" class="services" style=" background:white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -195px; height: 300%; padding-bottom: 85px; margin-left: -295px; width: 50rem;" >

                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                 <b> (123) Compared with 3 years ago, did your fish catch _____?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q123" id="q123" name="q123" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Decrease (GO TO 124) </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q123" id="q123" name="q123" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > Increase (GO TO 125) </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q123" id="q123" name="q123" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > Remain the same (GO TO 125)</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>

               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services" class="services" style=" background:white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -195px; height: 300%; padding-bottom: 100px; margin-left: -295px; width: 50rem;" >

                       
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(124) What is the primary reason for the decrease in fish catch?</b> </label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="dropdown">
                        <select for="q124" id="q124" name="q124" required style="margin-left: 20px; margin-top: 20px;">
                          <option value=""disabled>Select your option</option>
                          <option value="Yes">Fully-owned</option>
                          <option value="No">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>

            <!-- HOUSING CHARACTERISTICS 2 Services Section -->
            <section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -215px; height: 90%; margin-left: -295px; width: 50rem; background-color: white; padding-bottom: 90px;" >

                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;">
                                  <b>(125) Do you have fisheries insurance?</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group">
                              <label style="margin-left: 8px;">
                                  <b>(126) Who is the insurance provider?</b></label><br>
                            </div> <!-- form-group end.// -->   
           </div> <!-- form-row end.// -->

                         <div class="form-row">
                       <div class="col form-group" style=" margin-left: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q125" id="q125" name="q125" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q125" id="q125" name="q125" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>
                          <div class="col form-group">
                            <div class="dropdown">
                        <select for="q126" id="q126" name="q126" required style="margin-left: 5px;width: 170px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>
                         </div>

                         <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>
 
       <!-- HOUSING CHARACTERISTICS 2 Services Section -->
       <!-- ======= IDENTIFICATION Section ======= -->
  <section id="about" class="about" style="margin-top: -130px; background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -401px; margin-bottom: 30px; font-family: Raleway; margin-top: -20px; "> 
              Temperature</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                       
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(127) Compared with 3 years ago, is the temperature hotter now in your area?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q127" id="q127" name="q127" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  >Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q127" id="q127" name="q127" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >No</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>
       <!-- HOUSING CHARACTERISTICS 2 Services Section -->
<section id="about" class="about" style="margin-top: -230px; background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -401px; margin-bottom: 30px; font-family: Raleway; margin-top: -10px; "> 
              Electricity</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                       
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(128) Compared with 3 years ago, are brownouts more frequent now in your area?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q128" id="q128" name="q128" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  >Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q128" id="q128" name="q128" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >No</label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="about" class="about" style="margin-top: -230px; background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -401px; margin-bottom: 30px; font-family: Raleway; margin-top: -10px; "> 
              Sea Level</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                       
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(129) Compared with 3 years ago, did the sea level  _____ in your area?</b></label><br>

                                  <div class="col form-group" style="margin-top: 20px;">
                             <div class="dropdown">
                        <select for="q129" id="q129" name="q129" required style="margin-left: 5px; width: 250px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>
                 <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="about" class="about" style="margin-top: -230px; background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -401px; margin-bottom: 30px; font-family: Raleway; margin-top: -10px; "> 
              Water</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                       
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(130) Compared with 3 years ago, did the water supply _____ in your area?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                             <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q130" id="q130" name="q130" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Decrease (GO TO 130)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q130" id="q130" name="q130" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  Increase (GO TO 131)  </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q130" id="q130" name="q130" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  Remain the same (GO TO 131)  </label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                       
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(131) What is the primary reason for the decrease in water supply</b></label><br>

                                  <div class="col form-group" style="margin-top: 20px;">
                             <div class="dropdown">
                        <select for="q131" id="q131" name="q131" required style="margin-left: 5px; width: 250px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>
                 <!-- HOUSING CHARACTERISTICS 2 Services Section -->

                  <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="about" class="about" style="margin-top: -230px; background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -401px; margin-bottom: 30px; font-family: Raleway; margin-top: -10px; "> 
              Flooding</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                       
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(132) Compared with 3 years ago, do floods occur more often in your area now?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                             <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q132" id="q132" name="q132" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes (GO TO 132)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q132" id="q132" name="q132" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no (GO TO 135) </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q132" id="q132" name="q132" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  Did not experience flood (GO TO 135)  </label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 90px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                       
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(133) Three years ago, how long did it usually take for the flood to subside? (In Hours)</b></label><br>

                                  <div class="col form-group" style="margin-top: 20px;">
                             <input for="q133" id="q133" name="q133" type="text" class="form-control1" style="margin-left: 20px; width: 200px;"placeholder="">
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>

                 <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -224px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                       
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(134) During the past 12 months, how long did it usually take for the flood to subside? (In Hours)</b></label><br>

                                  <div class="col form-group" style="margin-top: 20px;">
                             <div class="dropdown">
                        <select for="q134" id="q134" name="q134" required style="margin-left: 5px; width: 250px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>

              <section id="about" class="about" style="margin-top: -230px; background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -401px; margin-bottom: 30px; font-family: Raleway; margin-top: 20px; "> 
              Drought</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                       
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(135) Compared 3 years ago, does drought occur more often in your area now?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                             <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q135" id="q135" name="q135" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes (GO TO 136)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q135" id="q135" name="q135" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no (GO TO 137 )  </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q135" id="q135" name="q135" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > Did not experience drought (GO TO 137)  </label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                       
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(136) In the past 3 years, how long did the last drought occur?</b></label><br>

                                  <div class="col form-group" style="margin-top: 20px;">
                             <div class="dropdown">
                        <select for="q136" id="q136" name="q136" required style="margin-left: 5px; width: 250px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>
                 <!-- HOUSING CHARACTERISTICS 2 Services Section -->
                 <section id="about" class="about" style="margin-top: -230px; background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -401px; margin-bottom: 30px; font-family: Raleway; margin-top: 20px; "> 
              Evacuation</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                       
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(137) During the past 3 years, did you move out of/from your previous dwelling unit?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                             <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q137" id="q137" name="q137" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes (GO TO 136)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q137" id="q137" name="q137" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no (GO TO 137 )  </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q137" id="q137" name="q137" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > Did not experience drought (GO TO 137)  </label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
                <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                       
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(138) What was your primary reason for moving out of your previous dwelling unit?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                             <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q138" id="q138" name="q138" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes (GO TO 136)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q138" id="q138" name="q138" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no (GO TO 137 )  </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q138" id="q138" name="q138" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > Did not experience drought (GO TO 137)  </label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
                <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                       
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(139) During the past 3 years, did you temporarily evacuate your house because of any calamity?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                             <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q139" id="q139" name="q139" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes (GO TO 136)</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q139" id="q139" name="q139" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no (GO TO 137 )  </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q139" id="q139" name="q139" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > Did not experience drought (GO TO 137)  </label>
                          </div>
                        </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->

               <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                       
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  <b>(140) Where did you stay when you temporarily evacuated?</b></label><br>

                                  <div class="col form-group" style="margin-top: 20px;">
                             <div class="dropdown">
                        <select for="q140" id="q140" name="q140" required style="margin-left: 5px; width: 250px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="about" class="about" style="margin-top: -230px; background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -401px; margin-bottom: 30px; font-family: Raleway; margin-top: 20px; "> 
              Calamity</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 140%; padding-bottom: 40px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                       
                       
                         <div class="form-row" style="font-size: 11px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;width: 220px; ">
                                  <b>(141) During the past 12 months, did your household experience destructive calammities such as a/an:</b></label><br>
                            </div>
                            <div class="col form-group">
                                <label style="margin-left: 40px;">
                                  <b>(142) How many times <br> did the ___ happen?</b></label>
                            </div>
                            <div class="col form-group">
                              <label style="margin-left: 40px;">
                                  <b>(143) Did you receive <br> any kind of assistance?</b></label><br>
                            </div>
                            <div class="col form-group">
                                <label style="margin-left: 40px;">
                                  <b>(144) Where did it <br> come from?</b></label>
                            </div>

                        </div> <!-- form-row end.// -->

                        <div class="form-row" style="font-size: 11px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>1. Typhoon</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q141_1" id="q141_1" name="q141_1" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q141_1" id="q141_1" name="q141_1" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input for="q142_1" id="q142_1" name="q142_1" type="text" class="form-control1" style="margin-left: 30px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q143_1" id="q143_1" name="q143_1" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q143_1" id="q143_1" name="q143_1" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select for="q144_1" id="q144_1" name="q144_1" required style="margin-left: 30px;width: 100px; font-size: 10px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px; px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>2. Flood</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q141_2" id="q141_2" name="q141_2"class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q141_2" id="q141_2" name="q141_2" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input for="q142_2" id="q142_2" name="q142_2" type="text" class="form-control1" style="margin-left: 30px; width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q143_2" id="q143_2" name="q143_2" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q143_2" id="q143_2" name="q143_2" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select for="q144_2" id="q144_2" name="q144_2" required style="margin-left: 30px; width: 100px; font-size: 10px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>3. Drought</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q141_3" id="q141_3" name="q141_3" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q141_3" id="q141_3" name="q141_3" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input for="q142_3" id="q142_3" name="q142_3" type="text" class="form-control1" style="margin-left: 30px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q143_3" id="q143_3" name="q143_3" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q143_3" id="q143_3" name="q143_3" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select for="q144_3" id="q144_3" name="q144_3" required style="margin-left: 30px; width: 100px; font-size: 10px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px; ">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>4. Earthquake</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q141_4" id="q141_4" name="q141_4" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q141_4" id="q141_4" name="q141_4" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input for="q142_4" id="q142_4" name="q142_4" type="text" class="form-control1" style="margin-left: 30px; width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q143_4" id="q143_4" name="q143_4" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q143_4" id="q143_4" name="q143_4" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select for="q144_4" id="q144_4" name="q144_4" required style="margin-left: 30px; width: 100px; font-size: 10px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px; ">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>5. Volcanic<br> Eruption</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q141_5" id="q141_5" name="q141_5" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q141_5" id="q141_5" name="q141_5" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input for="q142_5" id="q142_5" name="q142_5" type="text" class="form-control1" style="margin-left: 30px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q143_5" id="q143_5" name="q143_5" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q143_5" id="q143_5" name="q143_5" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select for="q144_5" id="q144_5" name="q144_5" required style="margin-left: 30px; width: 100px; font-size: 10px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>6. Landslide<br>/Mudslide</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q141_6" id="q141_6" name="q141_6" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q141_6" id="q141_6" name="q141_6" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input for="q142_6" id="q142_6" name="q142_6" type="text" class="form-control1" style="margin-left: 30px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q143_6" id="q143_6" name="q143_6" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q143_6" id="q143_6" name="q143_6" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select for="q144_6" id="q144_6" name="q144_6" required style="margin-left: 30px; width: 100px; font-size: 10px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px; ">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>7. Tsunami</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q141_7" id="q141_7" name="q141_7" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q141_7" id="q141_7" name="q141_7" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input for="q142_7" id="q142_7" name="q142_7" type="text" class="form-control1" style="margin-left: 30px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q143_7" id="q143_7" name="q143_7" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q143_7" id="q143_7" name="q143_7" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select for="q144_7" id="q144_7" name="q144_7" required style="margin-left: 30px; width: 100px; font-size: 10px;">
                          <option value=""disabled>Select your option</option>
                          <option value="Yes">Fully-owned</option>
                          <option value="No">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px; ">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>8. Fire</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q141_8" id="q141_8" name="q141_8" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q141_8" id="q141_8" name="q141_8" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input for="q142_8" id="q142_8" name="q142_8" type="text" class="form-control1" style="margin-left: 30px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q143_8" id="q143_8" name="q143_8" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q143_8" id="q143_8" name="q143_8" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select for="q144_8" id="q144_8" name="q144_8" required style="margin-left: 30px; width: 100px; font-size: 10px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>9. Forest Fire</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q141_9" id="q141_9" name="q141_9" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q141_9" id="q141_9" name="q141_9" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input for="q142_9" id="q142_9" name="q142_9" type="text" class="form-control1" style="margin-left: 30px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q143_9" id="q143_9" name="q143_9" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q143_9" id="q143_9" name="q143_9" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select for="q144_9" id="q144_9" name="q144_9" required style="margin-left: 30px;  width: 100px; font-size: 10px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px; ">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>10. Armed <br> conflict</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q141_10" id="q141_10" name="q141_10" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q141_10" id="q141_10" name="q141_10" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input for="q142_10" id="q142_10" name="q142_10" type="text" class="form-control1" style="margin-left: 30px; width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q143_10" id="q143_10" name="q143_10" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q143_10" id="q143_10" name="q143_10" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select for="q144_10" id="q144_10" name="q144_10" required style="margin-left: 30px; width: 100px; font-size: 10px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

                         <div class="form-row" style="font-size: 11px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; width: 220px; ">
                                  <b>11. Others,<br> specify</b></label><br>
                            </div>

                            <div class="col form-group" style="margin-left: -160px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q141_11" id="q141_11" name="q141_11" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q141_11" id="q141_11" name="q141_11" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                            
                          <div class="col form-group">
                            <input for="q142_11" id="q142_11" name="q142_11" type="text" class="form-control1" style="margin-left: 30px;width: 100px; height: 20px;"placeholder="">
                          </div>

                            <div class="col form-group" style="margin-left: 10px;">
                               <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q143_11" id="q143_11" name="q143_11" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes </label>
                          </div>

                          <div class="form-check form-check-inline">
                               <input for="q143_11" id="q143_11" name="q143_11" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no </label>
                          </div>
                              </div>
                          </div> 

                          <div class="col form-group">
                            <div class="dropdown">
                        <select for="q144_11" id="q144_11" name="q144_11" required style="margin-left: 30px; width: 100px; font-size: 10px;">
                          <option value="">Select your option</option>
                          <option value="Fully-owned">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                          </div>

                        </div> <!-- form-row end.// -->

              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
              <section id="about" class="about" style="margin-top: -230px; background-color: #b7d8ef;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:25px; color: black; margin-left: -401px; margin-bottom: 30px; font-family: Raleway; margin-top: 50px; "> 
              Disaster Preparedness</p>
             </div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
 <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -150px; margin-left: -285px; width: 50rem;">
                            Climate Change
                          </p>
                        </div>
                    </div></div></div></div>
</section>
 <section id="services" class="services" style=" background:#b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -235px; height: 300%; padding-bottom: 80px; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                       
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px; ">
                                  <b>(145) Do you have a disaster preparedness kit?</b></label><br>

                                  <div class="col form-group" style="margin-top: 10px;">
                             <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q145" id="q145" name="q145" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > yes (GO TO 146) </label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q145" id="q145" name="q145" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  >  no (GO TO 147) </label>
                          </div>
                          </div>
                          </div>    
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
                 </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services2" class="services2" style=" background: #b7d8ef;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -204px; height: 80%; margin-left: -295px; width: 50rem; background-color: #b7d8ef; padding-bottom: 340px;" >

                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;">
                                  <b>(146) Do you have the following in your disaster preparedness kit?</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group">
                              <label style="margin-left: 88px;">
                                  <b>(147) How many days will it last?</b></label><br>
                            </div> <!-- form-group end.// -->   
           </div> <!-- form-row end.// -->

                         <div class="form-row" style="margin-top: 10px;">
                          <div class="col form-group">
                              <label style="margin-left: 20px; width: 220px;">
                                  <b>1. Water</b></label><br>
                            </div>
                       <div class="col form-group" style="margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q146_1" id="q146_1" name="q146_1" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q146_1" id="q146_1" name="q146_1" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input for="q147_1" id="q147_1" name="q147_1" type="text" class="form-control1" style="margin-left: 30px;width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -10px;">
                          <div class="col form-group">
                              <label style="margin-left: 20px; width: 220px; ">
                                  <b>2. Food (canned goods, biscuits, bread)</b></label><br>
                            </div>
                       <div class="col form-group" style="margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q146_2" id="q146_2" name="q146_2" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q146_2" id="q146_2" name="q146_2" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input for="q147_2" id="q147_2" name="q147_2" type="text" class="form-control1" style="margin-left: 30px; width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -10px;">
                          <div class="col form-group">
                              <label style="margin-left: 20px;width: 220px;">
                                  <b>3. Matches/Lighter</b></label><br>
                            </div>
                       <div class="col form-group" style="margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q146_3" id="q146_3" name="q146_3" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q146_3" id="q146_3" name="q146_3" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input for="q147_3" id="q147_3" name="q147_3" type="text" class="form-control1" style="margin-left: 30px;width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                          <div class="col form-group">
                              <label style="margin-left: 20px;width: 220px; ">
                                  <b>4. Flashlight/Emergency light</b></label><br>
                            </div>
                       <div class="col form-group" style=" margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q146_4" id="q146_4" name="q146_4" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q146_4" id="q146_4" name="q146_4" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input for="q147_4" id="q147_4" name="q147_4" type="text" class="form-control1" style="margin-left: 30px; width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                          <div class="col form-group">
                              <label style="margin-left: 20px;width: 220px;">
                                  <b>5. Radio/Transistor (battery-operated)</b></label><br>
                            </div>
                       <div class="col form-group" style=" margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q146_5" id="q146_5" name="q146_5" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q146_5" id="q146_5" name="q146_5" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input for="q147_5" id="q147_5" name="q147_5" type="text" class="form-control1" style="margin-left: 30px; width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                          <div class="col form-group">
                              <label style="margin-left: 20px; width: 220px;">
                                  <b>6. Candle</b></label><br>
                            </div>
                       <div class="col form-group" style=" margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q146_6" id="q146_6" name="q146_6" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q146_6" id="q146_6" name="q146_6" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input for="q147_6" id="q147_6" name="q147_6" type="text" class="form-control1" style="margin-left: 30px; width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                          <div class="col form-group">
                              <label style="margin-left: 20px;width: 220px;">
                                  <b>7. Medical Kit</b></label><br>
                            </div>
                       <div class="col form-group" style=" margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q146_7" id="q146_7" name="q146_7" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q146_7" id="q146_7" name="q146_7" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input for="q147_7" id="q147_7" name="q147_7" type="text" class="form-control1" style="margin-left: 30px;width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                          <div class="col form-group">
                              <label style="margin-left: 20px; width: 220px; ">
                                  <b>8. Whistle</b></label><br>
                            </div>
                       <div class="col form-group" style=" margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q146_8" id="q146_8" name="q146_8" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q146_8" id="q146_8" name="q146_8" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input for="q147_8" id="q147_8" name="q147_8" type="text" class="form-control1" style="margin-left: 30px; width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                          <div class="col form-group">
                              <label style="margin-left: 20px;width: 220px; ">
                                  <b>9. Clothes</b></label><br>
                            </div>
                       <div class="col form-group" style="margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q146_9" id="q146_9" name="q146_9" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q146_9" id="q146_9" name="q146_9" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input for="q147_9" id="q147_9" name="q147_9" type="text" class="form-control1" style="margin-left: 30px; width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                          <div class="col form-group">
                              <label style="margin-left: 20px; width: 220px; ">
                                  <b>10. Blanket</b></label><br>
                            </div>
                       <div class="col form-group" style=" margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q146_10" id="q146_10" name="q146_10" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q146_10" id="q146_10" name="q146_10" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input for="q147_10" id="q147_10" name="q147_10" type="text" class="form-control1" style="margin-left: 30px; width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="">
                          <div class="col form-group">
                              <label style="margin-left: 20px; width: 220px; ">
                                  <b>11. Battery (Cellphone, flashlight, radio etc.)</b></label><br>
                            </div>
                       <div class="col form-group" style=" margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q146_11" id="q146_11" name="q146_11" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q146_11" id="q146_11" name="q146_11" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input for="q147_11" id="q147_11" name="q147_11" type="text" class="form-control1" style="margin-left: 30px; width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                          <div class="col form-group">
                              <label style="margin-left: 20px; width: 220px; ">
                                  <b>12. Important documents (land title, birth certificate, etc.)</b></label><br>
                            </div>
                       <div class="col form-group" style="margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q146_12" id="q146_12" name="q146_12" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q146_12" id="q146_12" name="q146_12" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input for="q147_12" id="q147_12" name="q147_12" type="text" class="form-control1" style="margin-left: 30px; width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="">
                          <div class="col form-group">
                              <label style="margin-left: 20px; width: 220px; ">
                                  <b>13. Others, Specify</b></label><br>
                            </div>
                       <div class="col form-group" style=" margin-left: -50px;">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q146_13" id="q146_13" name="q146_13" class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q146_13" id="q146_13" name="q146_13" class="form-check-input" type="radio"    value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                            <input for="q147_13" id="q147_13" name="q147_13" type="text" class="form-control1" style="margin-left: 30px; width: 100px; height: 20px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>
 
               <!-- ======= NEXT PAGE BUTTON Section ======= -->
       <section id="testimonials" class="testimonials section-bg" style="margin-top: -90px;">
         <div class="container">
            <div class="form-group">
              <button type="submit" class="btn btn-primary btn-block"> Next Page </button>
            </div> <!-- form-group// -->
          </div>
       </section>
     </form>
   </body>
   </html>

        <!-- End NEXT PAGE BUTTON Section -->
<?php /**PATH C:\Users\ASUS\Desktop\Laravel\applubijid\resources\views//pages/fhh6.blade.php ENDPATH**/ ?>