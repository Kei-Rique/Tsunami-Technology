<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>The Alubijid Household Profile Monitoring</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i, 700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/line-awesome/css/line-awesome.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">


  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Valera - v2.2.0
  * Template URL: https://bootstrapmade.com/valera-free-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= ALUBIJID Section ======= -->
  <section id="hero">
    <div class="hero-container">
      <h1><b>Alubijid</b></h1>
      <h2>Community-based monitoring system <br> Household profile questionnaire</h2>
      <a href="#about" class="btn-get-started scrollto">Start</a>
    </div>
  </section><!-- End ALUBIJID -->

  <!-- ======= IDENTIFICATION Section ======= -->
  <section id="about" class="about">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <img class="img-left" src="http://assets.barcroftmedia.com.s3-website-eu-west-1.amazonaws.com/assets/images/recent-images-11.jpg"/>
              <div class="content-heading"><h3>IDENTIFICATION &nbsp </h3></div>

              <p>Donec id elit non mi porta gravida at eget metus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.</p>

            </div>
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

  <!-- ======= LOCATION Section ======= -->
  <section id="counts" class="counts">
    <div class="container">

      <div class="row counters">

        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">


        <div class="row justify-content-center" style=" background: #b7d8ef">
          <div class="col-md-6">
            <div class="card" style=" background: transparent; border-color: transparent;">

              <form>
                <p style="font-size:30px"> Location </p>
                <div class="form-row">
                  <div class="col form-group">
                    <label>Province </label>   
                    <input type="text" class="form-control" placeholder="" style="width: 50px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group">
                    <label> <br> </label>
                    <span class="col form-group-btn" 
                    style="width:0px;"></span>
                    <input type="text" class="form-control" placeholder=" " style="width: 50px; margin-left: -136px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group1">
                    <label>Purok/Sitio </label>   
                    <input type="text" class="form-control" placeholder="" style="width: 50px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group">
                    <label> <br> </label>
                    <span class="col form-group1-btn" 
                    style="width:0px;"></span>
                    <input type="text" class="form-control" placeholder=" " style="width: 50px; margin-left: -136px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent;">
                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                <div class="form-row">
                  <div class="col form-group1">
                    <label>City/Municipality </label>   
                    <input type="text" class="form-control" placeholder="" style="width: 50px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent;">

                  </div> <!-- form-group end.// -->

                  <div class="col form-group" style="margin-left: 1px">
                    <label> <br> </label>
                    <span class="col form-group-btn" 
                    style="width:0px;"></span>
                    <input type="text" class="form-control" placeholder=" " style="width: 50px; margin-left: -136px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group1"style="margin-left: -6px">
                    <label>Street </label>   
                    <input type="text" class="form-control" placeholder="" style="width: 190px; padding-left: -200px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group">
                    <label> <br> </label>   
                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                <div class="form-row">
                  <div class="col form-group1">
                    <label>Zone </label>   
                    <input type="text" class="form-control" placeholder="" style="width: 50px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group" style="margin-left: 1px">
                    <label> <br> </label>
                    <span class="col form-group-btn" 
                    style="width:0px;"></span>
                    <input type="text" class="form-control" placeholder=" " style="width: 50px; margin-left: -136px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group1"style="margin-left: -6px">
                    <label>House Number </label>   
                    <input type="text" class="form-control" placeholder="" style="width: 190px; padding-left: -200px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group">
                    <label> <br> </label>
                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                <div class="form-row">
                  <div class="col form-group1">
                    <label>Baranggay </label>   
                    <input type="text" class="form-control" placeholder="" style="width: 50px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent;">

                    <label style="font-size: 12px">Household Identification Number</label>   
                    <input type="text" class="form-control" placeholder="" style="width: 190px; padding-left: -200px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group" style="margin-left: 1px">
                    <label> <br> </label>
                    <span class="col form-group-btn" 
                    style="width:0px;"></span>
                    <input type="text" class="form-control" placeholder=" " style="width: 50px; margin-left: -136px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group1"style="margin-left: -6px">
                    <p> Coordinates </p>
                    <label">Latitude </label>   
                    <input type="text" class="form-control1" placeholder="" style="width: 190px; height: 20px; padding-left: -200px;   border-radius: 0px;background-color: #f4f4f4; border-color: transparent; font-size: 8px;">
                    <label>Longitude </label>   
                    <input type="text" class="form-control1" placeholder="" style="width: 190px; height: 20px; padding-left: -200px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent;">
                  </div> <!-- form-group end.// -->
                  <div class="col form-group">
                    <label> <br> </label>


                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                <div class="form-group">
                  <label>Name of Respondent</label>
                  <input class="form-control" type="password" style="width: 550px;   border-radius: 0px; background-color: #f4f4f4; border-color: transparent; ">
                </div> <!-- form-group end.// -->  

              </form>
            </article> <!-- card-body end .// -->

          </div> <!-- col.//-->

        </div> <!-- row.//-->


        <!--container end.//-->

        <br><br>



      </div>

    </div>
  </section><!-- End LOCATION Section -->


  <!-- ======= HOUSING CHARACTERISTICS 1 Section ======= -->
  <section id="clients" class="clients section-bg">
    <div class="container">

      <div class="row counters">
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <!------ Include the above in your HEAD tag ---------->

        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">


        <div class="row justify-content-center" >
          <div class="col-md-6" >
            <div class="card" style=" background: #ffffff; border-color: transparent;" >

              <form>
                <p style="font-size:30px; margin-left: -471px; font-family: Raleway"> Housing Characteristics </p>
                <div class="form-row">
                  <div class="col form-group">
                    <label style="margin-left: -391px">
                    1. In what type of building does the household reside? </label>   
                    <br>


                    <select style="width: 500px;   border-radius: 0px; margin-left: -275px;">
                      <option value=""disabled>Select your option</option>
                      <option value="hurr">Apartment</option>
                      <option value="hurr">Condo</option>
                      <option value="hurr">Townhome</option>
                    </select>



                  </div> <!-- form-group end.// -->


                </div> <!-- form-row end.// -->

                <div class="form-row">
                  <div class="form-row">
                    <div class="col form-group">
                      <label style="margin-left: -160px">
                      2. How many bedrooms does this housing unit have? </label>   
                      <br>


                      <input class="form-control" type="password" style="width: 550px; height: 27px;   border-radius: 0px; margin-left: 17px; background-color: #f4f4f4; border-color: transparent;">



                    </div> <!-- form-group end.// -->
                  </div> <!-- form-row end.// -->


                  <div class="col form-group">
                    <label> <br> </label>


                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                <div class="form-row">
                  <div class="form-row">
                    <div class="col form-group">
                      <label style="margin-left: -50px">
                      3. What type of construction materials are the roof made of? </label>   
                      <br>


                      <select style="width: 500px;   border-radius: 0px; margin-left: 18px;">
                        <option value=""disabled>Select your option</option>
                        <option value="hurr">1</option>
                        <option value="hurr">2</option>
                        <option value="hurr">3</option>
                      </select>



                    </div> <!-- form-group end.// -->
                  </div> <!-- form-row end.// -->

                  <div class="form-row">
                    <div class="col form-group">
                      <label style="margin-left: 1px">
                      4. What type of construction materials are the roof outer walls made of? </label>   
                      <br>


                      <select style="width: 500px;   border-radius: 0px; margin-left: -27px;">
                        <option value=""disabled>Select your option</option>
                        <option value="hurr">1</option>
                        <option value="hurr">2</option>
                        <option value="hurr">3</option>
                      </select>

                    </div> <!-- form-group end.// -->
                  </div> <!-- form-row end.// -->

                </form>
              </article> <!-- card-body end .// -->

            </div> <!-- col.//-->
          </div>
        </section><!-- End HOUSING CHARACTERISTICS 1 Section -->

        <!-- ======= HOUSING CHARACTERISTICS 2 Section ======= -->
        <section id="services" class="services"style=" background: #b7d8ef">
          <div class="container">

            <div class="row counters">
              <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
              <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
              <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
              <!------ Include the above in your HEAD tag ---------->

              <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">


              <div class="row justify-content-center" >
                <div class="col-md-6" >
                  <div class="card" style=" background: #b7d8ef; border-color: transparent; margin-bottom: -18px;" >

                    <form>
                      <p style="font-size:30px; margin-left: 1px; margin-top: -50px; font-family: Raleway"> Housing Characteristics </p>
                      <div class="form-row">
                        <div class="col form-group">
                          <label style="margin-left: 1px">
                          How many household members are overseas workers? </label>   
                          <br>


                          <input class="form-control" type="password" style="width: 100px; height: 27px;   border-radius: 0px; margin-left: 1px; background-color: #f4f4f4; border-color: transparent;">


                        </div> <!-- form-group end.// -->


                      </div> <!-- form-row end.// -->

                      <div class="form-row">
                        <div class="form-row">
                          <div class="col form-group">
                            <label style="margin-left: 5px">
                            How many nuclear families are there in the household? </label>   
                            <br>


                            <input class="form-control" type="password" style="width: 100px; height: 27px;   border-radius: 0px; margin-left: 5px; background-color: #f4f4f4; border-color: transparent;">



                          </div> <!-- form-group end.// -->
                        </div> <!-- form-row end.// -->


                        <div class="col form-group">
                          <label> <br> </label>


                        </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->

                      <div class="form-row">
                        <div class="form-row">
                          <div class="col form-group">
                            <label style="margin-left: 5px">
                            Is any member of the household pregnant? </label>   
                            <br>


                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1" style="margin-left: 5px;">
                              <label class="form-check-label" for="inlineCheckbox1">Yes       </label>
                            </div>
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
                              <label class="form-check-label" for="inlineCheckbox2">No</label>
                            </div>

                            <br>
                            <div class="form-row">
                              <div class="form-row">
                                <div class="col form-group">
                                  <label style="margin-left: 8px; margin-top: 18px;">
                                  Is any member of the household a solo parent? </label>   
                                  <br>


                                  <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1" style="margin-left: 10px;">
                                    <label class="form-check-label" for="inlineCheckbox1">Yes       </label>
                                  </div>
                                  <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
                                    <label class="form-check-label" for="inlineCheckbox2">No</label>
                                  </div>



                                </div> <!-- form-group end.// -->
                              </div> <!-- form-row end.// -->
                            </div>

                            <div class="form-row">
                              <div class="form-row">
                                <div class="col form-group">
                                  <label style="margin-left: 8px;">
                                  Is any member of the household disabled? </label>   
                                  <br>


                                  <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1" style="margin-left: 10px;">

                                    <label class="form-check-label" for="inlineCheckbox1">Yes       </label>
                                  </div>
                                  <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
                                    <label class="form-check-label" for="inlineCheckbox2">No</label>
                                  </div>



                                </div> <!-- form-group end.// -->
                              </div> <!-- form-row end.// -->
                            </div>

                          </form>
                        </article> <!-- card-body end .// -->

                      </div> <!-- col.//-->

                    </div>
                  </section><!-- HOUSING CHARACTERISTICS 2 Services Section -->

                  <!-- ======= NEXT PAGE BUTTON Section ======= -->
                  <section id="testimonials" class="testimonials section-bg">
                    <div class="container">

                      <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block"> <a href="demography.html"> NEXT PAGE </a> </button>
                      </div> <!-- form-group// -->

                    </div>
                  </section>
                  <!-- End NEXT PAGE BUTTON Section -->
<?php /**PATH C:\xampp\htdocs\Laravel\applubijid\resources\views/welcome.blade.php ENDPATH**/ ?>