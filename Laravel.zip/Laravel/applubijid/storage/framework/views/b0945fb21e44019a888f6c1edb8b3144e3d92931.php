<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo e($title); ?></title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i, 700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/line-awesome/css/line-awesome.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">


  <!-- Template Main CSS File -->
  <link href="assets/css/TY.css" rel="stylesheet">


</head>

<body>

  <!-- ======= ALUBIJID Section ======= -->
  <section id="hero" style="margin-top: 40px; ">
    <div class="hero-container" style="background-color: #ffffff">
      
      <h2 style="font-size: 25px;"><b>THANK YOU FOR ANSWERING</b></h2>

<img src="8358.png" width="600" height="300">

<div class="form-row">

   <a href="/login"><button type="submit" class="btn btn-primary btn-block" style="width: 170px; 
  height: 50px;
  border-radius: 60px; 
  background-color: #6bb9ef; 
  border-color: transparent;
  font-size: 15px;
  font-color: white;">  CLOSE</button></a> 


</div>

     
    </div>
  </section><!-- End ALUBIJID -->

   <!-- ======= NEXT PAGE BUTTON Section ======= -->
      
        <!-- End NEXT PAGE BUTTON Section --

 <?php /**PATH C:\Users\ASUS\Desktop\Laravel\applubijid\resources\views//pages/ty.blade.php ENDPATH**/ ?>