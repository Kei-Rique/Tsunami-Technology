<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo e($title); ?></title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i, 700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/line-awesome/css/line-awesome.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">


  <!-- Template Main CSS File -->
  <link href="assets/css/fhh3.css" rel="stylesheet">
</head>

<body>

  <!-- ======= IDENTIFICATION Section ======= -->
   <section id="about" class="about">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:45px; color: black; margin-left: -271px; margin-bottom: 30px; font-family: Raleway; margin-top: -10px;"> 
              Agriculture-Farming</p>
              <p style="font-weight: bolder; font-size:15px; color: black; margin-left: -271px; font-family: Raleway;"> 
              Ask Questions (92) - (97) if CODE ‘1’ in (66), IF CODE ‘2’ in (66), PROCEED TO(98)</p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

  <!-- End IDENTIFICATION Section -->

                                        
        <!-- HOUSING CHARACTERISTICS 2 Services Section -->
        <form method="post" action="/fhh5">
                <?php echo csrf_field(); ?>
               <section id="services" class="services" style=" background:white">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -135px; height: 300%; padding-bottom: 65px; margin-left: -295px; width: 50rem;" >

                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  (92) What is the tenure status of the agricultural land being tilled by the household? </label><br>

                                  <div class="dropdown">
                        <select for="q92" id="q92" name="q92" required style="margin-left: 20px; margin-top: 20px;">
                          <option value="">Select your option</option>
                          <option value="Fully">Fully-owned</option>
                          <option value="Owner-like possession">Owner-like possession</option>
                          <option value="Tenanted">Tenanted</option>
                          <option value="Leased/Rented">Leased/Rented</option>
                          <option value="Rent Free">Rent Free</option>
                          <option value="Held under Certificate of Land Transfer(CLT)">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="Held under Certificate of Ancestral Domain title">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="Held under community-based Forest Management Agreement (CBFMA)">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="Others">Others</option>
                         </select>
                     </div>
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>

            <!-- HOUSING CHARACTERISTICS 2 Services Section -->
  <section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 10px; padding-bottom: 30px; padding-left: 10px; margin-top: -155px; height: 85px;margin-left: -295px; width: 50rem; background-color: white; border-color: black;" >

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;width: 450px;">
                                  <b> (93) What is the area of the agricultural land?</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group" style="margin-right: -70px; margin-top: 18px;">
                              
                                <input for="q93" id="q93" name="q93" type="text" class="form-control1" style="margin-left: 30px; width: 200px;"placeholder="">
                            </div> <!-- form-group end.// -->    
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
<section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -172px; 
                                padding-bottom: 30px;height: 120%; margin-left: -295px; width: 50rem; background-color: white;" >

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 28px;">
                                  94) During the past 12 months, what temporary<br>and permanent crops did your household harvest?</label><br>
                            </div> <!-- form-group end.// -->   

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 28px;">
                                  (95) During the past 12 months, how much did<br> you harvest? (in kilograms)
                                </label><br>
                            </div> <!-- form-group end.// -->            
                         </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  1.  </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q94_1" id="q94_1" name="q94_1" type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input for="q95_1" id="q95_1" name="q95_1" type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  2. </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q94_2" id="q94_2" name="q94_2" type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input for="q95_2" id="q95_2" name="q95_2" type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  3. </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q94_3" id="q94_3" name="q94_3"type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input for="q95_3" id="q95_3" name="q95_3" type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  4. </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q94_4" id="q94_4" name="q94_4"type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input for="q95_4" id="q95_4" name="q95_4" type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  5. </label><br>
                          </div>

                         <div class="col form-group">
                            <input for="q94_5" id="q94_5" name="q94_5"type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input for="q95_5" id="q95_5" name="q95_5" type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->

      <section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -203px; 
                                padding-bottom: 50px; height: 120%; margin-left: -295px; width: 50rem; background-color: white;" >

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 28px;">
                                  (96) How many of each of the following agricultural equipment/facilities does the household use?</label><br>
                            </div> <!-- form-group end.// -->        
                         </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px; width: 150px;">
                                  1. Beast of burded  </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q96_1" id="q96_1" name="q96_1" type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>

                           <div class="col form-group">
                            <label style="margin-left: -20px;margin-bottom: 28px;">
                                  7. Farm Tractor  </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q96_7" id="q96_7" name="q96_7" type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <label style="margin-left: -15px;margin-bottom: 28px;">
                                  13. Rice/corn/feed mill  </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q96_13" id="q96_13" name="q96_13" type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -15px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px; width: 150px;">
                                  2. Plow  </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q96_2" id="q96_2" name="q96_2" type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>

                           <div class="col form-group">
                            <label style="margin-left: -20px;margin-bottom: 28px;">
                                  8. Hand Tractor  </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q96_8" id="q96_8" name="q96_8" type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <label style="margin-left: -15px;margin-bottom: 28px;">
                                  14. Harvester, any crop   </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q96_14" id="q96_14" name="q96_14" type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -15px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px; width: 150px;">
                                  3. Harrow  </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q96_3" id="q96_3" name="q96_3" type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>

                           <div class="col form-group">
                            <label style="margin-left: -20px;margin-bottom: 28px;">
                                  9. Turtle/Mudboat  </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q96_9" id="q96_9" name="q96_9" type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <label style="margin-left: -15px;margin-bottom: 28px;">
                                  15. Warehouse granary   </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q96_15" id="q96_15" name="q96_15" type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                         </div>

                        <div class="form-row" style="margin-top: -15px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px; width: 150px;">
                                  4. Mower  </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q96_4" id="q96_4" name="q96_4" type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>

                           <div class="col form-group">
                            <label style="margin-left: -20px;margin-bottom: 28px;">
                                  10. Planter/<br>Transplanter/Dryer  </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q96_10" id="q96_10" name="q96_10" type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <label style="margin-left: -15px;margin-bottom: 28px;">
                                  16. Farmshed   </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q96_16" id="q96_16" name="q96_16" type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -15px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px; width: 150px;">
                                  5. Thresher/Corn Sheller  </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q96_5" id="q96_5" name="q96_5" type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>

                           <div class="col form-group">
                            <label style="margin-left: -20px;margin-bottom: 28px;">
                                  11. Mechanical Dryer   </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q96_11" id="q96_11" name="q96_11" type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <label style="margin-left: -15px;margin-bottom: 28px;">
                                  17. Irrigation pump   </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q96_17" id="q96_17" name="q96_17" type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -15px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px; width: 150px;">
                                  6. Insecticide/<br>Pesticide sprayer  </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q96_6" id="q96_6" name="q96_6" type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>

                           <div class="col form-group">
                            <label style="margin-left: -20px;margin-bottom: 28px;">
                                  12. Multipurpose drying pavement   </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q96_12" id="q96_12" name="q96_12" type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <label style="margin-left: -15px;margin-bottom: 28px;">
                                  18. Others Specify </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q96_18" id="q96_18" name="q96_18" type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->

      <section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 10px; padding-bottom: 30px; padding-left: 10px; margin-top: -220px; height: 85px;margin-left: -295px; width: 50rem; background-color: white; border-color: black;" >

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:10px;margin-left: 20px;width: 450px;">
                                  <b> (97) How many agricultural equipment/facilities does the household own?</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group" style="margin-right: -70px; margin-top: 18px;">
                              
                                <input for="q97" id="q97" name="q97" type="text" class="form-control1" style="margin-left: 30px; width: 200px;"placeholder="">
                            </div> <!-- form-group end.// -->    
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

            <!-- HOUSING CHARACTERISTICS 2 Services Section -->

        <!-- ======= IDENTIFICATION Section ======= -->
  <section id="about" class="about" style="background-color: #b7d8ef; margin-top: -90px;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:45px; color: black; margin-left: -201px; font-family: Raleway; margin-top: -30px; margin-bottom: -10px;"> 
              <b>Agriculture-Livestock Raising</b> </p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section>

  <!-- End IDENTIFICATION Section -->

 <!-- HOUSING CHARACTERISTICS 2 Services Section -->

       <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -80px; margin-left: -295px; width: 50rem;"> <b> Ask Questions (98) - (99) if CODE ‘1’ in (67), IF CODE ‘2’ in (67), PROCEED TO
(100)</b>
                          </p>
                        </div>
                    </div></div></div></div>
</section>

 <section id="services2" class="services2" style=" background: #b7d8ef; margin-bottom: -20px;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -132px; 
                                padding-bottom: 30px; height: 110%; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 28px; width: 300px;">
                                  <b>(98) For the past 12 months, what types of livestocks or other animals were raised and provided the following products?</b></label><br>
                            </div> <!-- form-group end.// -->   

                            <div class="col form-group">
                              <label style="margin-left: 130px;margin-bottom: 28px; width: 100px;">
                                  <b>(99.A) Volume of production sold</b>
                                </label><br>
                            </div> <!-- form-group end.// -->  

                            <div class="col form-group">
                              <label style="margin-left: 70px;margin-bottom: 28px;">
                                  <b>(99.B) Volume of<br> production consumed</b>
                                </label><br>
                            </div> <!-- form-group end.// -->            
                         </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 35px;">
                                  1.  Live Animals (Number of Heads)  </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q98_1" id="q98_1" name="q98_1" type="text" class="form-control1" style="margin-left: 80px; width: 100px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q99_a1" id="q99_a1" name="q99_a1" type="text" class="form-control1" style="margin-left: 60px; width: 100px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q99_b1" id="q99_b1" name="q99_b1"type="text" class="form-control1" style="margin-left: 41px; width: 100px;"placeholder="">
                          </div>
            </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-top: -20px;">
                                  2. Meat (Weight in Kilograms)  </label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -20px;">
                            <input for="q98_2" id="q98_1" name="q98_2"type="text" class="form-control1" style="margin-left: 80px; width: 100px;"placeholder="">
                          </div>

                          <div class="col form-group" style="margin-top: -20px;">
                            <input for="q99_a2" id="q99_a2" name="q99_a2" type="text" class="form-control1" style="margin-left: 60px; width: 100px;"placeholder="">
                          </div>

                          <div class="col form-group" style="margin-top: -20px;">
                            <input for="q99_b2" id="q99_b2" name="q99_b2"type="text" class="form-control1" style="margin-left: 41px; width: 100px;"placeholder="">
                          </div>
            </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 23px;">
                                  3. Milk (in Liters)  </label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -4px;">
                            <input for="q98_3" id="q98_3" name="q98_3"type="text" class="form-control1" style="margin-left: 80px; width: 100px;"placeholder="">
                          </div>

                          <div class="col form-group" style="margin-top: -4px;">
                            <input for="q99_a3" id="q99_a3" name="q99_a3" type="text" class="form-control1" style="margin-left: 60px; width: 100px;"placeholder="">
                          </div>

                          <div class="col form-group" style="margin-top: -4px;">
                            <input for="q99_b3" id="q99_b3" name="q99_b3"type="text" class="form-control1" style="margin-left: 41px; width: 100px;"placeholder="">
                          </div>
            </div>

                         <div class="form-row">
                           
                          <div class="col form-group" >
                            <label style="margin-left: 20px;margin-bottom: 25px;">
                                  4. Eggs (amount)  </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q98_4" id="q98_4" name="q98_4"type="text" class="form-control1" style="margin-left: 80px; width: 100px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q99_a4" id="q99_a4" name="q99_a4" type="text" class="form-control1" style="margin-left: 60px; width: 100px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q99_b4" id="q99_b4" name="q99_b4"type="text" class="form-control1" style="margin-left: 41px; width: 100px;"placeholder="">
                          </div>
            </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 25px;">
                                  5. Others, specify  </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q98_5" id="q98_5" name="q98_5"type="text" class="form-control1" style="margin-left: 80px; width: 100px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q99_a5" id="q99_a5" name="q99_a5" type="text" class="form-control1" style="margin-left: 60px; width: 100px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q99_b5" id="q99_b5" name="q99_b5"type="text" class="form-control1" style="margin-left: 41px; width: 100px;"placeholder="">
                          </div>
            </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

       <!-- HOUSING CHARACTERISTICS 2 Services Section -->
       <!-- ======= IDENTIFICATION Section ======= -->
  <section id="about" class="about" >
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:45px; color: black; margin-left: -271px; margin-bottom: 30px; font-family: Raleway; margin-top: -10px;"> 
              Agriculture-Fishing</p>
              <p style="font-weight: bolder; font-size:15px; color: black; margin-left: -271px; font-family: Raleway;"> 
              Ask Questions (100) - (108) if CODE ‘1’ in (68). IF CODE ‘2’ in (68), PROCEED TO (109)</p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

  <!-- End IDENTIFICATION Section -->

                                        
        <!-- HOUSING CHARACTERISTICS 2 Services Section -->
<section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 20px; padding-bottom: 50px; padding-left: 10px; margin-top: -125px; height: 150px;margin-left: -295px; width: 50rem; background-color: white; border-color: black;" >

                        <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;">
                                  <b>(100) Which fishing activity is the household engaged in?</b></label><br>
                            </div> <!-- form-group end.// -->   
                        </div>

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;width: 450px;">
                                  <b> 1.  Catching/Gathering fishes, crabs, shrimps, etc.</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q100_1" id="q100_1" name="q100_1"class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q100_1" id="q100_1" name="q100_1"class="form-check-input" type="radio"   value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>      
                         </div> <!-- form-row end.// -->

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;width: 450px;">
                                  <b> 2. Culturing fish, seaweeds, etc.</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q100_2" id="q100_2" name="q100_2"class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q100_2" id="q100_2" name="q100_2"class="form-check-input" type="radio"   value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div> 
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

       <!-- HOUSING CHARACTERISTICS 2 Services Section -->
<section id="about" class="about" style="margin-top: -100px;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading">
              <p style="font-weight: bolder; font-size:15px; color: black; margin-left: -401px; font-family: Raleway;"> 
              Ask Questions (101) - (105) if CODE ‘1’ in (100.1)</p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

  <!-- End IDENTIFICATION Section -->

                                        
        <!-- HOUSING CHARACTERISTICS 2 Services Section -->
<section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-left: 10px; margin-top: -125px; height: 80px;margin-left: -295px; width: 50rem; background-color: white; border-color: black;" >

                        
                         <div class="form-row" style="margin-top: 20px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;width: 450px;">
                                  <b> (101) Where did household/s member/s fish in the <br> past 12 months?</b></label><br>
                            </div> <!-- form-group end.// --> 
                <div class="col form-group">
                             <div class="dropdown">
                        <select for="q101" id="q101" name="q101"required style="margin-top: 10px; width: 200px;">
                          <option value="">Select your option</option>
                          <option value="Total blindness">Total blindness</option>
                          <option value="Partial blindness">Partial blindness</option>
                          <option value="Low vision">Low vision</option>
                         </select>
                     </div>
                 </div>
                         </div> <!-- form-row end.// -->
                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -152px; 
                                padding-bottom: 95px;height: 100%; margin-left: -295px; width: 50rem; background-color: white;" >

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 23px;">
                                  <b>(102) How many of each of the following types of boats/vessels does the household use in fishing activities?</b></label><br>
                            </div> <!-- form-group end.// -->   
           </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 20px;">
                                  1.  Boat with engine and outrigger  </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q102_1" id="q102_1" name="q102_1" type="text" class="form-control1" style="margin-left: -50px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 20px;">
                                  2. Boat with engine but without outrigger </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q102_2" id="q102_2" name="q102_2"type="text" class="form-control1" style="margin-left: -50px; width: 200px;"placeholder="">
                          </div>
                          </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 20px;">
                                  3. Boat without engine but with outrigger </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q102_3" id="q102_3" name="q102_3"type="text" class="form-control1" style="margin-left: -50px; width: 200px;"placeholder="">
                          </div>
                          </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 20px;">
                                  4. Boat without engine and outrigger </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q102_4" id="q102_4" name="q102_4"type="text" class="form-control1" style="margin-left: -50px; width: 200px;"placeholder="">
                          </div>
                          </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;">
                                  5. Raft </label><br>
                          </div>

                         <div class="col form-group">
                            <input for="q102_5" id="q102_5" name="q102_5"type="text" class="form-control1" style="margin-left: -50px; width: 200px;"placeholder="">
                          </div>
                          </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

               <!-- HOUSING CHARACTERISTICS 2 Services Section -->

               <section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -250px; padding-bottom: 130px; height: 120%; margin-left: -295px; width: 50rem; background-color: white;" >

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 23px;">
                                  (104) What kind of gears/accessories/devices<br> was/were used?</label><br>
                            </div> <!-- form-group end.// -->   

                            <div class="col form-group">
                              <label style="margin-left: 40px;margin-bottom: 10px;">
                                  (105) How many does the household own?
                                </label><br>
                            </div> <!-- form-group end.// -->            
                         </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 10px;">
                                  1.  </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q104_1" id="q104_1" name="q104_1"type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input for="q105_1" id="q105_1" name="q105_1"type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 10px;">
                                  2. </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q104_2" id="q104_2" name="q104_2"type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input for="q105_2" id="q105_2" name="q105_2"type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 10px;">
                                  3. </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q104_3" id="q104_3" name="q104_3"type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input for="q105_3" id="q105_3" name="q105_3"type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 10px;">
                                  4. </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q104_4" id="q104_4" name="q104_4"type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input for="q105_4" id="q105_4" name="q105_4"type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  5. </label><br>
                          </div>

                         <div class="col form-group">
                            <input for="q104_5" id="q104_5" name="q104_5"type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input for="q105_5" id="q105_5" name="q105_5"type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="about" class="about" style="margin-top: -290px;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading">
              <p style="font-weight: bolder; font-size:15px; color: black; margin-left: -401px; font-family: Raleway;"> 
              Ask Questions (106) - (108) if CODE ‘1’ in (100.2)</p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

  <!-- End IDENTIFICATION Section -->

                                        
        <!-- HOUSING CHARACTERISTICS 2 Services Section -->
<section id="services2" class="services2" style=" background: white;">
                   <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -120px; padding-bottom: 70px;height: 100%; margin-left: -295px; width: 50rem; background-color: white;" >

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 28px;">
                                  <b>(106) What types of aquafarm did the household member/s operate? </b> </label><br>
                            </div> <!-- form-group end.// -->            
                         </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;">
                                  1. Fishpond </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q106_1" id="q106_1" name="q106_1"class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q106_1" id="q106_1" name="q106_1"class="form-check-input" type="radio"   value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -5px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;">
                                  2. Fish penn </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q106_2" id="q106_2" name="q106_2"class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q106_2" id="q106_2" name="q106_2"class="form-check-input" type="radio"   value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -5px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;">
                                  3. Fish cage </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q106_3" id="q106_3" name="q106_3"class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q106_3" id="q106_3" name="q106_3"class="form-check-input" type="radio"   value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -5px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;">
                                  4. Seaweed Farm </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q106_4" id="q106_4" name="q106_4"class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q106_4" id="q106_4" name="q106_4"class="form-check-input" type="radio"   value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -5px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;">
                                  5. Oyster Farm </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q106_5" id="q106_5" name="q106_5"class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q106_5" id="q106_5" name="q106_5"class="form-check-input" type="radio"   value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -5px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;">
                                  6. Musslle Farm </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q106_6" id="q106_6" name="q106_6"class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q106_6" id="q106_6" name="q106_6"class="form-check-input" type="radio"   value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -5px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;">
                                  7. Fish Tank </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q106_7" id="q106_7" name="q106_7"class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q106_7" id="q106_7" name="q106_7"class="form-check-input" type="radio"   value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -5px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;">
                                  8. Hatchery </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q106_8" id="q106_8" name="q106_8"class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q106_8" id="q106_8" name="q106_8"class="form-check-input" type="radio"   value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -5px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;">
                                  9. Others,specify </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q106_9" id="q106_9" name="q106_9"class="form-check-input" type="radio"   value="Yes">
                                  <label class="form-check-label"  > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q106_9" id="q106_9" name="q106_9"class="form-check-input" type="radio"   value="No">
                                  <label class="form-check-label"  > No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -220px; padding-bottom: 110px;height: 120%; margin-left: -295px; width: 50rem; background-color: white;" >

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 20px;">
                                  <b>(107) For the past 12 months, what were the fishes or aquatic animals cultured or caught by your household?</b></label><br>
                            </div> <!-- form-group end.// -->   

                            <div class="col form-group">
                              <label style="margin-left: 40px;margin-bottom: 20px;">
                                  <b>(108) How much was the volume of fish harvest/caught in the past 12 months? (in kilograms) </b>
                                </label><br>
                            </div> <!-- form-group end.// -->            
                         </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 10px;">
                                  1.  </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q107_1" id="q107_1" name="q107_1"type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input for="q108_1" id="q108_1" name="q108_1"type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 10px;">
                                  2. </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q107_2" id="q107_2" name="q107_2"type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input for="q108_2" id="q108_2" name="q108_2"type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 10px;">
                                  3. </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q107_3" id="q107_3" name="q107_3"type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input for="q108_3" id="q108_3" name="q108_3"type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 10px;">
                                  4. </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q107_4" id="q107_4" name="q107_4"type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input for="q108_4" id="q108_4" name="q108_4"type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 10px;">
                                  5. </label><br>
                          </div>

                         <div class="col form-group">
                            <input for="q107_5" id="q107_5" name="q107_5"type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input for="q108_5" id="q108_5" name="q108_5"type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <!-- ======= NEXT PAGE BUTTON Section ======= -->
       <section id="testimonials" class="testimonials section-bg" style="margin-top: -90px;">
         <div class="container">
            <div class="form-group">
              <button type="submit" class="btn btn-primary btn-block"> Next Page </button>
            </div> <!-- form-group// -->
          </div>
       </section>
     </form>
   </body>
   </html>

        <!-- End NEXT PAGE BUTTON Section -->
<?php /**PATH C:\xampp\htdocs\Laravel\applubijid\resources\views//pages/fhh5.blade.php ENDPATH**/ ?>