<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo e($title); ?></title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i, 700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/line-awesome/css/line-awesome.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">


  <!-- Template Main CSS File -->
  <link href="assets/css/fhh3.css" rel="stylesheet">
</head>

<body>

  <!-- ======= IDENTIFICATION Section ======= -->
   <section id="about" class="about">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:45px; color: black; margin-left: -271px; margin-bottom: 30px; font-family: Raleway; margin-top: -10px;"> 
              Agriculture-Farming</p>
              <p style="font-weight: bolder; font-size:15px; color: black; margin-left: -271px; font-family: Raleway;"> 
              Ask Questions (92) - (97) if CODE ‘1’ in (66), IF CODE ‘2’ in (66), PROCEED TO(98)</p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

  <!-- End IDENTIFICATION Section -->

                                        
        <!-- HOUSING CHARACTERISTICS 2 Services Section -->

               <section id="services" class="services" style=" background:white">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 28px; padding-left: 10px; margin-top: -135px; height: 300%; padding-bottom: 65px; margin-left: -295px; width: 50rem;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 1px; ">
                                  (92) What is the tenure status of the agricultural land being tilled by the household? </label><br>

                                  <div class="dropdown">
                        <select required style="margin-left: 20px; margin-top: 20px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Fully-owned</option>
                          <option value="2">Owner-like possession</option>
                          <option value="3">Tenanted</option>
                          <option value="4">Leased/Rented</option>
                          <option value="5">Rent Free</option>
                          <option value="6">Held under Certificate of Land Transfer(CLT) or Certificate of Land Ownership Award (CLOA)</option>
                          <option value="7">Held under Certificate of Ancestral Domain title/Certificate(CADT/CALT)</option>
                          <option value="8">Held under community-based Forest Management Agreement (CBFMA)/Stewardship</option>
                          <option value="8">Others, specify</option>
                         </select>
                     </div>
                         </div> <!-- form-row end.// -->
              <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>


               </section>

            <!-- HOUSING CHARACTERISTICS 2 Services Section -->
  <section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 10px; padding-bottom: 30px; padding-left: 10px; margin-top: -155px; height: 85px;margin-left: -295px; width: 50rem; background-color: white; border-color: black;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;width: 450px;">
                                  <b> (93) What is the area of the agricultural land?</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group" style="margin-right: -70px; margin-top: 18px;">
                              
                                <input type="text" class="form-control1" style="margin-left: 30px; width: 200px;"placeholder="">
                            </div> <!-- form-group end.// -->    
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->
<section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -172px; 
                                padding-bottom: 30px;height: 120%; margin-left: -295px; width: 50rem; background-color: white;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 28px;">
                                  94) During the past 12 months, what temporary<br>and permanent crops did your household harvest?</label><br>
                            </div> <!-- form-group end.// -->   

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 28px;">
                                  (95) During the past 12 months, how much did<br> you harvest? (in kilograms)
                                </label><br>
                            </div> <!-- form-group end.// -->            
                         </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  1.  </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  2. </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  3. </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  4. </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  5. </label><br>
                          </div>

                         <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->

      <section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -203px; 
                                padding-bottom: 50px; height: 120%; margin-left: -295px; width: 50rem; background-color: white;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 28px;">
                                  (96) How many of each of the following agricultural equipment/facilities does the household use?</label><br>
                            </div> <!-- form-group end.// -->        
                         </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px; width: 150px;">
                                  1. Beast of burded  </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>

                           <div class="col form-group">
                            <label style="margin-left: -20px;margin-bottom: 28px;">
                                  7. Farm Tractor  </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <label style="margin-left: -15px;margin-bottom: 28px;">
                                  13. Rice/corn/feed mill  </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -15px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px; width: 150px;">
                                  2. Plow  </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>

                           <div class="col form-group">
                            <label style="margin-left: -20px;margin-bottom: 28px;">
                                  8. Hand Tractor  </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <label style="margin-left: -15px;margin-bottom: 28px;">
                                  14. Harvester, any crop   </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -15px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px; width: 150px;">
                                  3. Harrow  </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>

                           <div class="col form-group">
                            <label style="margin-left: -20px;margin-bottom: 28px;">
                                  9. Turtle/Mudboat  </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <label style="margin-left: -15px;margin-bottom: 28px;">
                                  15. Warehouse granary   </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                         </div>

                        <div class="form-row" style="margin-top: -15px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px; width: 150px;">
                                  4. Mower  </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>

                           <div class="col form-group">
                            <label style="margin-left: -20px;margin-bottom: 28px;">
                                  10. Planter/<br>Transplanter/Dryer  </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <label style="margin-left: -15px;margin-bottom: 28px;">
                                  16. Farmshed   </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -15px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px; width: 150px;">
                                  5. Thresher/Corn Sheller  </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>

                           <div class="col form-group">
                            <label style="margin-left: -20px;margin-bottom: 28px;">
                                  11. Mechanical Dryer   </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <label style="margin-left: -15px;margin-bottom: 28px;">
                                  17. Irrigation pump   </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -15px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px; width: 150px;">
                                  6. Insecticide/<br>Pesticide sprayer  </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>

                           <div class="col form-group">
                            <label style="margin-left: -20px;margin-bottom: 28px;">
                                  12. Multipurpose drying pavement   </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <label style="margin-left: -15px;margin-bottom: 28px;">
                                  18. Others, specify   </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 5px; width: 60px;"placeholder="">
                          </div>
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->

      <section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 10px; padding-bottom: 30px; padding-left: 10px; margin-top: -220px; height: 85px;margin-left: -295px; width: 50rem; background-color: white; border-color: black;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:10px;margin-left: 20px;width: 450px;">
                                  <b> (97) How many agricultural equipment/facilities does the household own?</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group" style="margin-right: -70px; margin-top: 18px;">
                              
                                <input type="text" class="form-control1" style="margin-left: 30px; width: 200px;"placeholder="">
                            </div> <!-- form-group end.// -->    
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

            <!-- HOUSING CHARACTERISTICS 2 Services Section -->

        <!-- ======= IDENTIFICATION Section ======= -->
  <section id="about" class="about" style="background-color: #b7d8ef; margin-top: -90px;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:45px; color: black; margin-left: -201px; font-family: Raleway; margin-top: -30px; margin-bottom: -10px;"> 
              <b>Agriculture-Livestock Raising</b> </p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section>

  <!-- End IDENTIFICATION Section -->

 <!-- HOUSING CHARACTERISTICS 2 Services Section -->

       <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-bottom: 20px; font-weight: 600; font-size: 15px; margin-top: -80px; margin-left: -295px; width: 50rem;"> <b> Ask Questions (98) - (99) if CODE ‘1’ in (67), IF CODE ‘2’ in (67), PROCEED TO
(100)</b>
                          </p>
                        </div>
                    </div></div></div></div>
</section>

 <section id="services2" class="services2" style=" background: #b7d8ef; margin-bottom: -20px;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -132px; 
                                padding-bottom: 30px; height: 110%; margin-left: -295px; width: 50rem; background-color: #b7d8ef;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 28px; width: 300px;">
                                  <b>(98) For the past 12 months, what types of livestocks or other animals were raised and provided the following products?</b></label><br>
                            </div> <!-- form-group end.// -->   

                            <div class="col form-group">
                              <label style="margin-left: 130px;margin-bottom: 28px; width: 100px;">
                                  <b>(99.A) Volume of production sold</b>
                                </label><br>
                            </div> <!-- form-group end.// -->  

                            <div class="col form-group">
                              <label style="margin-left: 70px;margin-bottom: 28px;">
                                  <b>(99.B) Volume of<br> production consumed</b>
                                </label><br>
                            </div> <!-- form-group end.// -->            
                         </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 35px;">
                                  1.  Live Animals (Number of Heads)  </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 80px; width: 100px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 60px; width: 100px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 41px; width: 100px;"placeholder="">
                          </div>
            </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-top: -20px;">
                                  2. Meat (Weight in Kilograms)  </label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -20px;">
                            <input type="text" class="form-control1" style="margin-left: 80px; width: 100px;"placeholder="">
                          </div>

                          <div class="col form-group" style="margin-top: -20px;">
                            <input type="text" class="form-control1" style="margin-left: 60px; width: 100px;"placeholder="">
                          </div>

                          <div class="col form-group" style="margin-top: -20px;">
                            <input type="text" class="form-control1" style="margin-left: 41px; width: 100px;"placeholder="">
                          </div>
            </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 23px;">
                                  3. Milk (in Liters)  </label><br>
                          </div>

                          <div class="col form-group" style="margin-top: -4px;">
                            <input type="text" class="form-control1" style="margin-left: 80px; width: 100px;"placeholder="">
                          </div>

                          <div class="col form-group" style="margin-top: -4px;">
                            <input type="text" class="form-control1" style="margin-left: 60px; width: 100px;"placeholder="">
                          </div>

                          <div class="col form-group" style="margin-top: -4px;">
                            <input type="text" class="form-control1" style="margin-left: 41px; width: 100px;"placeholder="">
                          </div>
            </div>

                         <div class="form-row">
                           
                          <div class="col form-group" >
                            <label style="margin-left: 20px;margin-bottom: 25px;">
                                  4. Eggs (amount)  </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 80px; width: 100px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 60px; width: 100px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 41px; width: 100px;"placeholder="">
                          </div>
            </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 25px;">
                                  5. Others, specify  </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 80px; width: 100px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 60px; width: 100px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: 41px; width: 100px;"placeholder="">
                          </div>
            </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

       <!-- HOUSING CHARACTERISTICS 2 Services Section -->
       <!-- ======= IDENTIFICATION Section ======= -->
  <section id="about" class="about" >
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:45px; color: black; margin-left: -271px; margin-bottom: 30px; font-family: Raleway; margin-top: -10px;"> 
              Agriculture-Fishing</p>
              <p style="font-weight: bolder; font-size:15px; color: black; margin-left: -271px; font-family: Raleway;"> 
              Ask Questions (100) - (108) if CODE ‘1’ in (68). IF CODE ‘2’ in (68), PROCEED TO (109)</p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

  <!-- End IDENTIFICATION Section -->

                                        
        <!-- HOUSING CHARACTERISTICS 2 Services Section -->
<section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 20px; padding-bottom: 50px; padding-left: 10px; margin-top: -125px; height: 150px;margin-left: -295px; width: 50rem; background-color: white; border-color: black;" >

                      <form>
                        <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;">
                                  <b>(100) Which fishing activity is the household engaged in?</b></label><br>
                            </div> <!-- form-group end.// -->   
                        </div>

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;width: 450px;">
                                  <b> 1.  Catching/Gathering fishes, crabs, shrimps, etc.</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>      
                         </div> <!-- form-row end.// -->

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;width: 450px;">
                                  <b> 2. Culturing fish, seaweeds, etc.</b></label><br>
                            </div> <!-- form-group end.// --> 

                             <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div> 
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

       <!-- HOUSING CHARACTERISTICS 2 Services Section -->
<section id="about" class="about" style="margin-top: -100px;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading">
              <p style="font-weight: bolder; font-size:15px; color: black; margin-left: -401px; font-family: Raleway;"> 
              Ask Questions (101) - (105) if CODE ‘1’ in (100.1)</p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

  <!-- End IDENTIFICATION Section -->

                                        
        <!-- HOUSING CHARACTERISTICS 2 Services Section -->
<section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-left: 10px; margin-top: -125px; height: 80px;margin-left: -295px; width: 50rem; background-color: white; border-color: black;" >

                      <form>
                        
                         <div class="form-row" style="margin-top: 20px;">

                            <div class="col form-group">
                              <label style="margin-left: 20px;width: 450px;">
                                  <b> (101) Where did household/s member/s fish in the <br> past 12 months?</b></label><br>
                            </div> <!-- form-group end.// --> 
                <div class="col form-group">
                             <div class="dropdown">
                        <select required style="margin-top: 10px; width: 200px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Total blindness</option>
                          <option value="2">Partial blindness</option>
                          <option value="3">Low vision</option>
                         </select>
                     </div>
                 </div>
                         </div> <!-- form-row end.// -->
                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -152px; 
                                padding-bottom: 95px;height: 100%; margin-left: -295px; width: 50rem; background-color: white;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 23px;">
                                  <b>(102) How many of each of the following types of boats/vessels does the household use in fishing activities?</b></label><br>
                            </div> <!-- form-group end.// -->   
           </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 20px;">
                                  1.  Boat with engine and outrigger  </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -50px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 20px;">
                                  2. Boat with engine but without outrigger </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -50px; width: 200px;"placeholder="">
                          </div>
                          </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 20px;">
                                  3. Boat without engine but with outrigger </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -50px; width: 200px;"placeholder="">
                          </div>
                          </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 20px;">
                                  4. Boat without engine and outrigger </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -50px; width: 200px;"placeholder="">
                          </div>
                          </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;">
                                  5. Raft </label><br>
                          </div>

                         <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -50px; width: 200px;"placeholder="">
                          </div>
                          </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

               <!-- HOUSING CHARACTERISTICS 2 Services Section -->

               <section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -250px; padding-bottom: 130px; height: 120%; margin-left: -295px; width: 50rem; background-color: white;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 23px;">
                                  (104) What kind of gears/accessories/devices<br> was/were used?</label><br>
                            </div> <!-- form-group end.// -->   

                            <div class="col form-group">
                              <label style="margin-left: 40px;margin-bottom: 10px;">
                                  (105) How many does the household own?
                                </label><br>
                            </div> <!-- form-group end.// -->            
                         </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 10px;">
                                  1.  </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 10px;">
                                  2. </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 10px;">
                                  3. </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 10px;">
                                  4. </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  5. </label><br>
                          </div>

                         <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="about" class="about" style="margin-top: -290px;">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading">
              <p style="font-weight: bolder; font-size:15px; color: black; margin-left: -401px; font-family: Raleway;"> 
              Ask Questions (106) - (108) if CODE ‘1’ in (100.2)</p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

  <!-- End IDENTIFICATION Section -->

                                        
        <!-- HOUSING CHARACTERISTICS 2 Services Section -->
<section id="services2" class="services2" style=" background: white;">
                   <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -120px; padding-bottom: 70px;height: 100%; margin-left: -295px; width: 50rem; background-color: white;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 28px;">
                                  <b>(106) What types of aquafarm did the household member/s operate? </b> </label><br>
                            </div> <!-- form-group end.// -->            
                         </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;">
                                  1. Fishpond </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -5px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;">
                                  2. Fish penn </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -5px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;">
                                  3. Fish cage </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -5px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;">
                                  4. Seaweed Farm </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -5px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;">
                                  5. Oyster Farm </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -5px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;">
                                  6. Musslle Farm </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -5px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;">
                                  7. Fish Tank </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -5px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;">
                                  8. Hatchery </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -5px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;">
                                  9. Others,specify </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <section id="services2" class="services2" style=" background: white;">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -220px; padding-bottom: 110px;height: 120%; margin-left: -295px; width: 50rem; background-color: white;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 20px;">
                                  <b>(107) For the past 12 months, what were the fishes or aquatic animals cultured or caught by your household?</b></label><br>
                            </div> <!-- form-group end.// -->   

                            <div class="col form-group">
                              <label style="margin-left: 40px;margin-bottom: 20px;">
                                  <b>(108) How much was the volume of fish harvest/caught in the past 12 months? (in kilograms) </b>
                                </label><br>
                            </div> <!-- form-group end.// -->            
                         </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 10px;">
                                  1.  </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 10px;">
                                  2. </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 10px;">
                                  3. </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 10px;">
                                  4. </label><br>
                          </div>

                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 10px;">
                                  5. </label><br>
                          </div>

                         <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -120px; width: 200px;"placeholder="">
                          </div>
                          <div class="col form-group">
                            <input type="text" class="form-control1" style="margin-left: -60px; width: 200px;"placeholder="">
                          </div>
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>
               <!-- HOUSING CHARACTERISTICS 2 Services Section -->
               <!-- ======= NEXT PAGE BUTTON Section ======= -->
       <section id="testimonials" class="testimonials section-bg" style="margin-top: -90px;">
         <div class="container">
            <div class="form-group">
              <button type="submit" class="btn btn-primary btn-block"> <a href="/fhh6"> NEXT PAGE</a> </button>
            </div> <!-- form-group// -->
          </div>
       </section>

        <!-- End NEXT PAGE BUTTON Section -->
<?php /**PATH C:\Users\ASUS\Desktop\Laravel\applubijid\resources\views//pages/fhh5.blade.php ENDPATH**/ ?>