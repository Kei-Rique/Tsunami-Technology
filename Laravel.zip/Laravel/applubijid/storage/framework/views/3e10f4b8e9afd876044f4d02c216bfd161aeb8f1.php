<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Admin</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="../path/to/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.2.1.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> 
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
 <link href="assets/css/admin.css" rel="stylesheet">
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body style="background-color: #e2e2e2">
  <div class="container" style="margin-top: -50px;">
  <div class="page-header">
  </div>
</div>
<div class="container">
</div>
<div class="container">
  <div class="row">
    <div class="col-md-6">
      <div class="panel with-nav-tabs panel-danger" style="width: 120rem;">
        <div class="panel-heading">
          <ul class="nav nav-tabs">
            <li class="active"><a href="#tab1danger" data-toggle="tab">NAME</a></li>
            <li><a href="#tab2danger" data-toggle="tab">BRGY1</a></li>
            <li><a href="#tab3danger" data-toggle="tab">BRGY2</a></li>
             <li><a href="#tab4danger" data-toggle="tab">BRGY3</a></li>
            <li><a href="#tab5danger" data-toggle="tab">BGRY4</a></li>
             <li><a href="#tab6danger" data-toggle="tab">BGRY5</a></li>
              <li><a href="#tab7danger" data-toggle="tab">BRGY6</a></li>
               <li><a href="#tab8danger" data-toggle="tab">BRGY7</a></li>
                <li><a href="#tab9danger" data-toggle="tab">BGRY8</a></li>
                 <li><a href="#tab10danger" data-toggle="tab">BGRY9</a></li>
          </ul>
        </div>
        <div class="panel-body">
          <div class="tab-content">
            <div class="tab-pane fade in active" id="tab1danger">
              
              <div class="chart-container">
        <canvas id="myChart"></canvas>
    </div>
    
    <script src="Scripts/dist/Chart.js"></script>

    <script type="text/javascript">
        var sampleDATA = 10, sampleDATA2 = 5; //used in label 1 and 2

        var ctx = document.getElementById('myChart').getContext('2d');
        var chart = new Chart(ctx, {
            // The type of chart we want to create
            type: 'pie', 

            // The data for our dataset
            data: {
                labels: ['1-17', '18-30', '31-60', '60-80', '80-100', '100+'], //labels of which data is to be 
                                                                               //shown, can receive objects I believe so labels can be dynamic
                datasets: [{
                    backgroundColor: [
                        'rgb(245, 66, 66)',
                        'rgb(245, 164, 66)',       //pick whatever colors you want, should be same number as labes
                        'rgb(245, 230, 66)',
                        'rgb(129, 245, 66)',
                        'rgb(77, 255, 246)',
                        'rgb(66, 78, 245)'

                    ],
                    borderColor: 'rgba(255, 99, 132, 0)',
                    data: [sampleDATA, 10, sampleDATA2, 2, 20, 30]     //based on query and what was solved in the math, 
                                                            //provided variables as sample (hover on red part)
                }]
            },

            // Configuration options go here
            options: {
                responsive: true,
                maintainAspectRatio: false //makes it possible to resize the chart according to parent container size
            }

        });
    </script>
            </div>
            <!--FORM 2 START-->
            <div class="tab-pane fade" id="tab2danger">
             <div class="container">
 <input class="form-control" id="myInput" type="text" placeholder="Search..">
  <br>
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>ADDRESS</th>
        <th>COORDINATES</th>
        <th>FIRST NAME</th>
        <th>LAST NAME</th>
        <th>MIDDLE NAME</th>
        <th>HOUSE TYPE</th>
      </tr>
    </thead>
    <tbody id="myTable">
      <tr>
        <td>1</td>
        <td>3RD ST, PASAY</td>
        <td>23213</td>
        <td>SAM</td>
        <td>SDASDA</td>
        <td>R</td>
        <td>CASAD</td>
        <td style="width: 10px;"><i class="fa fa-trash" aria-hidden="true" style="font-size:24px"></i>
</td>
      </tr>
    </tbody>
  </table>

  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Popup image</button>

<div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-body">
            <img src="chart.png" style="height:300px; width: 500px;" class="img-responsive">
        </div>
    </div>
  </div>
</div>


<script type="text/javascript">
 function centerModal() {
    $(this).css('display', 'block');
    var $dialog = $(this).find(".modal-dialog");
    var offset = ($(window).height() - $dialog.height()) / 2;
    // Center modal vertically in window
    $dialog.css("margin-top", offset);
}

$('.modal').on('show.bs.modal', centerModal);
$(window).on("resize", function () {
    $('.modal:visible').each(centerModal);
});
</script>


  <div class="file btn btn-lg btn-primary" style=" position: relative; overflow: visible; height: 25px; border-radius: 2px; display: table-cell;
vertical-align: middle; font-size: 15px; background-color: #10a023; border-color: transparent;">
              Upload .csv
      <input type="file" name="file" style=" position: absolute; font-size: 50px; opacity: 0; right: 0; top: 0;" />
  </div>

  </div>
</div>
<!--FORM 2 END-->
<!--FORM 3 START-->
           
<!--FORM 3 END-->
<!--FORM 4 START-->
            <div class="tab-pane fade" id="tab3danger">
               <div class="container">
 <input class="form-control" id="myInput" type="text" placeholder="Search..">
  <br>
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>ADDRESS</th>
        <th>COORDINATES</th>
        <th>FIRST NAME</th>
        <th>LAST NAME</th>
        <th>MIDDLE NAME</th>
        <th>HOUSE TYPE</th>
      </tr>
    </thead>
    <tbody id="myTable">
      <tr>
        <td>1</td>
        <td>3RD ST, PASAY</td>
        <td>23213</td>
        <td>SAM</td>
        <td>SDASDA</td>
        <td>R</td>
        <td>CASAD</td>
        <td style="width: 10px;"><i class="fa fa-trash" aria-hidden="true" style="font-size:24px"></i>
      </tr>
    </tbody>
  </table>
  </div>
            </div>
<!--FORM 4 END-->
<!--FORM 5 START-->
            <div class="tab-pane fade" id="tab4danger">
               <div class="container">
 <input class="form-control" id="myInput" type="text" placeholder="Search..">
  <br>
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>ADDRESS</th>
        <th>COORDINATES</th>
        <th>FIRST NAME</th>
        <th>LAST NAME</th>
        <th>MIDDLE NAME</th>
        <th>HOUSE TYPE</th>
      </tr>
    </thead>
    <tbody id="myTable">
      <tr>
        <td>1</td>
        <td>3RD ST, PASAY</td>
        <td>23213</td>
        <td>SAM</td>
        <td>SDASDA</td>
        <td>R</td>
        <td>CASAD</td>
        <td style="width: 10px;"><i class="fa fa-trash" aria-hidden="true" style="font-size:24px"></i>
      </tr>
    </tbody>
  </table>
  </div>
            </div>
<!--FORM 5 END-->
<!--FORM 6 START-->
            <div class="tab-pane fade" id="tab5danger">
               <div class="container">
 <input class="form-control" id="myInput" type="text" placeholder="Search..">
  <br>
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>ADDRESS</th>
        <th>COORDINATES</th>
        <th>FIRST NAME</th>
        <th>LAST NAME</th>
        <th>MIDDLE NAME</th>
        <th>HOUSE TYPE</th>
      </tr>
    </thead>
    <tbody id="myTable">
      <tr>
        <td>1</td>
        <td>3RD ST, PASAY</td>
        <td>23213</td>
        <td>SAM</td>
        <td>SDASDA</td>
        <td>R</td>
        <td>CASAD</td>
        <td style="width: 10px;"><i class="fa fa-trash" aria-hidden="true" style="font-size:24px"></i>
      </tr>
    </tbody>
  </table>
  </div>
            </div>
<!--FORM 6 END-->
<!--FORM 7 START-->
             <div class="tab-pane fade" id="tab6danger">
                <div class="container">
 <input class="form-control" id="myInput" type="text" placeholder="Search..">
  <br>
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>ADDRESS</th>
        <th>COORDINATES</th>
        <th>FIRST NAME</th>
        <th>LAST NAME</th>
        <th>MIDDLE NAME</th>
        <th>HOUSE TYPE</th>
      </tr>
    </thead>
    <tbody id="myTable">
      <tr>
        <td>1</td>
        <td>3RD ST, PASAY</td>
        <td>23213</td>
        <td>SAM</td>
        <td>SDASDA</td>
        <td>R</td>
        <td>CASAD</td>
        <td style="width: 10px;"><i class="fa fa-trash" aria-hidden="true" style="font-size:24px"></i>
      </tr>
    </tbody>
  </table>
  </div>
             </div>
<!--FORM 7 END-->
<!--FORM 8 START-->
              <div class="tab-pane fade" id="tab7danger">
                 <div class="container">
 <input class="form-control" id="myInput" type="text" placeholder="Search..">
  <br>
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>ADDRESS</th>
        <th>COORDINATES</th>
        <th>FIRST NAME</th>
        <th>LAST NAME</th>
        <th>MIDDLE NAME</th>
        <th>HOUSE TYPE</th>
      </tr>
    </thead>
    <tbody id="myTable">
      <tr>
        <td>1</td>
        <td>3RD ST, PASAY</td>
        <td>23213</td>
        <td>SAM</td>
        <td>SDASDA</td>
        <td>R</td>
        <td>CASAD</td>
        <td style="width: 10px;"><i class="fa fa-trash" aria-hidden="true" style="font-size:24px"></i>
      </tr>
    </tbody>
  </table>
  </div>
              </div>
<!--FORM 8 END-->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>



<br/>
<script>
  $(document).ready(function(){
    $("#myInput").on("keyup", function(){
      var value = $(this).val().toLowerCase();
      $("#myTable tr").filter(function(){
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
      });
    });
  });
</script>
</body>
</html><?php /**PATH C:\Users\ASUS\Desktop\Laravel\applubijid\resources\views//admin/admin.blade.php ENDPATH**/ ?>