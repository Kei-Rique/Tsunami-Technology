<div class="container">
	<?php echo $__env->yieldContent('mainContent'); ?>
</div><?php /**PATH C:\xampp\htdocs\Laravel\applubijid\resources\views/layout.blade.php ENDPATH**/ ?>