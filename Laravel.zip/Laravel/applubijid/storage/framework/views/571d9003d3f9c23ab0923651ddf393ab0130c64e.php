<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo e($title); ?></title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="../path/to/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.2.1.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> 
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
 <link href="assets/css/admin.css" rel="stylesheet">
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body style="background-color: #e2e2e2">
  <div class="container" style="margin-top: -50px;">
  <div class="page-header">
  </div>
</div>
<div class="container">
</div>
<div class="container">
  <div class="row">
    <div class="col-md-6">
      <div class="panel with-nav-tabs panel-danger" style="width: 120rem;">
        <div class="panel-heading">
          <ul class="nav nav-tabs">
            <li class="active"><a href="#tab1danger" data-toggle="tab">NAME</a></li>
            <li><a href="#tab2danger" data-toggle="tab">BRGY1</a></li>
            <li><a href="#tab3danger" data-toggle="tab">BRGY2</a></li>
             <li><a href="#tab4danger" data-toggle="tab">BRGY3</a></li>
            <li><a href="#tab5danger" data-toggle="tab">BGRY4</a></li>
             <li><a href="#tab6danger" data-toggle="tab">BGRY5</a></li>
              <li><a href="#tab7danger" data-toggle="tab">BRGY6</a></li>
               <li><a href="#tab8danger" data-toggle="tab">BRGY7</a></li>
                <li><a href="#tab9danger" data-toggle="tab">BGRY8</a></li>
                 <li><a href="#tab10danger" data-toggle="tab">BGRY9</a></li>
          </ul>
        </div>
        <div class="panel-body">
          <div class="tab-content">
            <div class="tab-pane fade in active" id="tab1danger"></div>

            <!--FORM 2 START-->
            <div class="tab-pane fade" id="tab2danger">
             <div class="container">
 <input class="form-control" id="myInput" type="text" placeholder="Search..">
  <br>
  <table class="table table-bordered table-striped">
        <?php echo $__env->yieldContent('tab2danger'); ?>
        </div>
            <!--FORM 2 END-->

<!--FORM 3 START-->
           
<!--FORM 3 END-->
<!--FORM 4 START-->
            
<!--FORM 4 END-->
<!--FORM 5 START-->
            
<!--FORM 5 END-->
<!--FORM 6 START-->
            
<!--FORM 6 END-->
<!--FORM 7 START-->
             
<!--FORM 7 END-->
<!--FORM 8 START-->
              
<!--FORM 8 END-->
          



<br/>
<script>
  $(document).ready(function(){
    $("#myInput").on("keyup", function(){
      var value = $(this).val().toLowerCase();
      $("#myTable tr").filter(function(){
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
      });
    });
  });
</script>


</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\applubijid\resources\views//layouts/adminLayout.blade.php ENDPATH**/ ?>