<h1> Login </h1>

<form action="/locates" method="post">
 

  <div class="container">
    <label for="uname"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="uname" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>

    
  <a href="/locates">Login</a>

  </div>

 
  </div>
</form>

<?php /**PATH C:\xampp\htdocs\Laravel\applubijid\resources\views/login.blade.php ENDPATH**/ ?>