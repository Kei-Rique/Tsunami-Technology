

<?php $__env->startSection('mainContent'); ?>
	<hi>Show User</h1>
	<div style="color: <?php echo e($locate->color); ?>">
		<strong><?php echo e($locate->Users); ?></strong><br>
	</div>
	<strong> Province </strong>
		<p><?php echo e($locate->province); ?></p>
		<strong> City </strong>
		<p><?php echo e($locate->City); ?></p>
		<strong> Street </strong>
		<p><?php echo e($locate->street); ?></p>
		<strong> Zone </strong>
		<p><?php echo e($locate->zone); ?></p>
		<strong> House Number </strong>
		<p><?php echo e($locate->house_number); ?></p>
		<strong> Baranggay </strong>
		<p><?php echo e($locate->baranggay); ?></p>
		<strong> Latitude </strong>
		<p><?php echo e($locate->latitude); ?></p>
		<strong> Longitude </strong>
		<p><?php echo e($locate->longitude); ?></p>
		
	
	<a href="<?php echo e($locate->id); ?>/edit">Edit User</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\applubijid\resources\views/locates/show.blade.php ENDPATH**/ ?>