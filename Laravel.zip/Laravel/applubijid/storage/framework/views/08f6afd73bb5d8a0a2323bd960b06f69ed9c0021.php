<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo e($title); ?></title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i, 700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/line-awesome/css/line-awesome.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">


  <!-- Template Main CSS File -->
  <link href="assets/css/fhh1.css" rel="stylesheet">

</head>

<body>
  <!-- ======= IDENTIFICATION Section ======= -->
  <section id="about" class="about">
    <div class="page-wrap">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:45px; color: black; margin-left: -471px; font-family: Raleway;"> 
              HOUSEHOLD INFORMATION </p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </div>
  </section><!-- End IDENTIFICATION Section -->

  <!-- ======= LOCATION Section ======= -->
  <section id="counts" class="counts">
    <div class="page-wrap">
    <div class="container">

      <div class="row counters">

        <div class="row justify-content-center" style=" background: #b7d8ef;">
          <div class="col-md-6">
            <div class="card" style=" background: #b7d8ef; border-color: transparent; margin-left: -295px; margin-top: 40px; margin-bottom: 30px; width: 50rem; ">

              <form method="post" action="/fhh1">
                <?php echo csrf_field(); ?>
                <p style="font-weight: bolder; font-size:30px; color: black; margin-top: 17px; margin-left: 14px;"> <b> Demography </b></p>
               
              <div class="demog">
                <div class="form-row" style="margin-bottom: 15px;">
                  <div class="col form-group">
                    <label>(1) Surname </label>   
                    <input type="text" for="surname" id="surname" name="surname" class="form-control" placeholder="">
                    
                  </div> <!-- form-group end.// -->
                

                  <div class="col form-group1" style="margin-left: 20px;">
                    <label> (2) First Name</label>   
                    <input type="text" for="first_name" id="first_name" name="first_name"class="form-control" placeholder="">
                  </div> <!-- form-group end.//-->

                  <div class="col form-group1" style="margin-left: 20px;">
                    <label> (3) Middle Name</label>   
                    <input type="text" for="middle_name" id="middle_name" name="middle_name" class="form-control" placeholder="">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group">
                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                <div class="form-row" style="margin-bottom: 5px;">
                  <div class="col form-group">
                    <label>(4) Date of Birth</label> 
                    <input type="Date" for="date_of_birth" id="date_of_birth" name="date_of_birth" class="form-control" placeholder="mm/dd/yyyy" style="margin-top: 35px;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group1" style="margin-left: 15px;">
                    <label>(5) Age </label>   
                    <input type="number" for="age" id="age" name="age" class="form-control" placeholder="" style="width: 80px; margin-top: 35px;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group1" style="margin-left: 20px;">
                    <label style="width: 150px;">(6) Sex <br> 1 - male 2 - female</label>   
                    <input type="number" for="sex" id="sex" name="sex" class="form-control" placeholder="" style="width: 80px; margin-top: 13px;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group1" style="margin-left: 20px;">
                    <label style="width: 200px;">(7) In which nuclear family do you belong?</label>   
                    <input type="text" for="nfamily" id="nfamily" name="nfamily" class="form-control" placeholder="" style="width: 80px; margin-top: 13px;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group">
                    <label> <br> </label>   
                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                <div class="form-row" style="margin-bottom: 15px;">
                  <div class="col form-group">
                    <label>(8) What is your relationship to the head of the household? </label>   

                    <div class="dropdown">
                      <select for="rhousehold" id="rhousehold" name="rhousehold" required style="font-size: 13px;margin-top: 23px;">
                        <option value="">Select your option</option>
                        <option value="Head">Head </option>
                        <option value="Spouse">Spouse </option>
                        <option value="Son/Daughter">Son/Daughter</option>
                        <option value="Son/Daughter-in-law">Son/Daughter-in-law</option>
                        <option value="Grandchildren">Grandchildren</option>
                        <option value="Parents">Parents</option>
                        <option value="Other relatives, specify">Other relatives, specify</option>
                        <option value="Housemaid/boy">Housemaid/boy</option>
                        <option value="Others">Others</option>
                      </select>
                    </div>
                  </div> <!-- form-group end.// -->

                  
                  <div class="col form-group" style="margin-left: 140px;">
                    <label>(9) Was your birth registered with the civil registry office?<br> 1 - Yes 2 - No</label>   
                    <input type="number" for="registered_civilregistry" id="registered_civilregistry" name="registered_civilregistry" class="form-control" placeholder="">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group">
                    <label> <br> </label>
                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                <div class="form-row" style="margin-bottom: 15px;">
                  <div class="col form-group">
                    <label>(10) <b>FOR 10 YEARS OLD AND ABOVE </b> What is your marital (civil) status? </label>   
                    
                    <div class="dropdown">
                      <select for="marital_status" id="marital_status" name="marital_status" style="margin-top: 7px; font-size: 10px;" required>
                        <option value="">Select your option</option>
                        <option value="Single">Single </option>
                        <option value="Married">Married </option>
                        <option value="Widowed">Widowed </option>
                        <option value="Divorced/Separated">Divorced/Separated</option>
                        <option value="Common-law/Live-in">Common-law/Live-in</option>
                        <option value="Unknown">Unknown</option>
                      </select>
                    </div>
                  </div> <!-- form-group end.// -->

                  <div class="col form-group" style="margin-left: 140px;">
                    <label>(11) What is your Ethnicity by blood? <i style="font-size: 10px;"> Mention the predominant/common IP or NON-IP Groups in the area </i> </label>   
                    <input type="text" for="ethnicity_by_blood" id="ethnicity_by_blood" name="ethnicity_by_blood" class="form-control" placeholder="">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group">
                    <label> <br> </label>


                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                <div class="form-row">
                  <div class="col form-group">
                    <label>(12) <b>IF A MEMBER IS AN OFW AND <br> AGE IS 10 YEARS OLD AND ABOVE <br></b> Are you an overseas worker? <br><br> 1 - yes (proceed to <b> (18) </b>) 2 - no </label>   
                    <input type="number" for="q12" id="q12" name="q12" class="form-control" placeholder="" style="margin-top: 23px;">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group" style="margin-left: -10px;">
                    <label>(13) <b>FOR 3 YEARS OLD AND ABOVE</b><br> Where were you residing 3 years ago? <br><br> 1 - same address now  <br>2 - other address, specify </label>   
                    <input type="number" for="q13" id="q13" name="q13" class="form-control" placeholder="" style="margin-top: 23px;">
                  </div> <!-- form-group end.// -->
</div>
                </div>

            </article> <!-- card-body end .// -->

          </div> <!-- col.//-->

        </div> <!-- row.//-->

        <!--container end.//-->

        <br><br>

      </div>

    </div>
  </div>
  </section><!-- End LOCATION Section -->


  <!-- ======= HOUSING CHARACTERISTICS 1 Section ======= -->
  <section id="clients" class="clients section-bg">
    <div class="container">

        <div class="row justify-content-center" >
          <div class="col-md-6" >
            <div class="card" style=" background: #ffffff; border-color: transparent; margin-left: -300px; margin-top: 35px; margin-bottom: 30px; width: 50rem;">

              
                <p style="font-weight: bolder; font-size:30px; color: black; margin-top: 1px; margin-left: -440px; font-family: Raleway; text-align: center;"> <b>Education and Literacy</b> </p>

                <div class="educ">
                <div class="form-row" style="">
                  <div class="col form-group">
                    <label style="margin-bottom: 25px;">(14) Are you currently attending school?<br> 1 - Yes (leave <b> (17)</b> blank ) 2 - No (skip to<b> (17
                    )</b>) </label>   
                    <input type="number" for="q14" id="q14" name="q14" class="form-control1" placeholder="">
                  </div> <!-- form-group end.// -->

                  <div class="col form-group">
                    <label> <br> </label>
                  </div> <!-- form-group end.// -->
                </div> <!-- form-row end.// -->

                        </div>

                  </div>
                      </div>
              </article> <!-- card-body end .// -->

            </div> <!-- col.//-->
          </div>
        </section>

        <!-- End HOUSING CHARACTERISTICS 1 Section -->
        <section id="clients" class="clients section-bg">
    <div class="container">

        <div class="row justify-content-center" >
          <div class="col-md-6" >
            <div class="card" style=" background: #ffffff; border-color: black; width: 81rem; margin-left: -300px; margin-top: -20px; padding-bottom: 20px; width: 50rem;" >

              
                

                <div class="educ">
                <div class="form-row">
                  <p style="margin: 30px 10px; margin-bottom: 20px;"> <b>For 3 years old and above</b>
                  </p></div>


                  <div class="form-row">
                    <div class="col form-group">
                      <label>(15) What grade or year are you currently attending? </label>   

                      <div class="dropdown">
                        <select for="q15" id="q15" name="q15" style="width: 300px; height: 30px;   border-radius: 0px; background-color: white; margin-top: 3px; "required>
                          <option value="" disabled="">Select your option</option>
                          <option value="No Grade">No Grade </option>
                          <option value="Daycare">Daycare </option>
                          <option value="Kindergarten/Preparatory">Kindergarten/Preparatory</option>
                          <option value="Grade I">Grade I</option>
                          <option value="Grade II">Grade II</option>
                          <option value="Grade III">Grade III</option>
                          <option value="Grade IV">Grade IV</option>
                          <option value="Grade V">Grade V</option>
                          <option value="Grade VI">Grade VI</option>
                          <option value="Grade 7">Grade 7 </option>
                          <option value="Grade 8">Grade 8 </option>
                          <option value="Grade 9/3rd Year HS">Grade 9/3rd Year HS</option>
                          <option value="Grade 10/4th Year HS">Grade 10/4th Year HS</option>
                          <option value="Grade 11">Grade 11</option>
                          <option value="Grade 12">Grade 12</option>
                          <option value="1st Year PS/N-T/TV">1st Year PS/N-T/TV</option>
                          <option value="2nd Year PS/N-T/TV">2nd Year PS/N-T/TV</option>
                          <option value="3rd Year PS/N-T/TV">3rd Year PS/N-T/TV</option>
                          <option value="1st Year College">1st Year College </option>
                          <option value="2nd Year College">2nd Year College </option>
                          <option value="3rd Year College">3rd Year College</option>
                          <option value="4th Year College or higher">4th Year College or higher</option>
                          <option value="Post Grad w/ units">Post Grad w/ units</option>
                          <option value="ALS Elementary">ALS Elementary</option>
                          <option value="ALS Secondary">ALS Secondary</option>
                          <option value="SPED Elementary">SPED Elementary</option>
                          <option value="SPED Secondary">SPED Secondary</option>
                          <option value="Grade school graduate">Grade school graduate</option>
                          <option value="High school graduate">High school graduate</option>
                          <option value="Post secondary graduate">Post secondary graduate</option>
                          <option value="College graduate">College graduate</option>
                          <option value="Masters/PhD graduate">Masters/PhD graduate</option>
                        </select>
                      </div>
                    </div> <!-- form-group end.// -->


                    <div class="col form-group" style="margin-left: 100px;">
                      <label style="width: 250px;">(16) Where do you attend school? <br> 1 - public 2 - private</label>   
                      <input type="number" for="q16" id="q16" name="q16" class="form-control1" placeholder="">
                    </div> <!-- form-group end.// -->

                    <div class="col form-group">
                      <label> <br> </label>
                    </div> <!-- form-group end.// -->
                  </div> <!-- form-row end.// -->

                  <div class="form-row" style="margin-top: 20px;">
                    <div class="col form-group">
                      <label>(17) Why are you not attending school? </label>   

                      <div class="dropdown">
                        <select for="q17" id="q17" name="q17" style="margin-top: 45px; font-size: 10px;"required >
                          <option value="">Select your option</option>
                          <option value="Schools are very far">Schools are very far </option>
                          <option value="No school within the bgy">No school within the bgy </option>
                          <option value="No regular transportation">No regular transportation</option>
                          <option value="High cost of education">High cost of education </option>
                          <option value="Illness/Disability">Illness/Disability</option>
                          <option value="Housekeeping/Taking care of siblings">Housekeeping/Taking care of siblings</option>
                          <option value="Marriage">Marriage</option>
                          <option value="Employment/looking for work">Employment/looking for work</option>
                          <option value="Lack of personal interest">Lack of personal interest</option>
                          <option value="Cannot cope with school work">Cannot cope with school work </option>
                          <option value="Finished schooling">Finished schooling </option>
                          <option value="Problem with school record">Problem with school record</option>
                          <option value="Problem with birth certificate">Problem with birth certificate</option>
                          <option value="Too young to go to school">Too young to go to school</option>
                          <option value="Others">Others</option> </select>
                        </div>
                      </div> <!-- form-group end.// -->


                  <div class="col form-group" style="margin-left: 100px;">
                      <label style="width: 300px">(18) What is the highest educational attainment you have completed? If you are a college graduate, what is your course?</label>   

                        <div class="dropdown">
                        <select for="q18" id="q18" name="q18"style="width: 300px;   margin-top: 3px;"required>
                          <option value="">Select your option</option>
                          <option value="No Grade">No Grade </option>
                          <option value="Daycare">Daycare </option>
                          <option value="Kindergarten/Preparatory">Kindergarten/Preparatory</option>
                          <option value="Grade I">Grade I</option>
                          <option value="Grade II">Grade II</option>
                          <option value="Grade III">Grade III</option>
                          <option value="Grade IV">Grade IV</option>
                          <option value="Grade V">Grade V</option>
                          <option value="Grade VI">Grade VI</option>
                          <option value="Grade 7">Grade 7 </option>
                          <option value="Grade 8">Grade 8 </option>
                          <option value="Grade 9/3rd Year HS">Grade 9/3rd Year HS</option>
                          <option value="Grade 10/4th Year HS">Grade 10/4th Year HS</option>
                          <option value="Grade 11">Grade 11</option>
                          <option value="Grade 12">Grade 12</option>
                          <option value="1st Year PS/N-T/TV">1st Year PS/N-T/TV</option>
                          <option value="2nd Year PS/N-T/TV">2nd Year PS/N-T/TV</option>
                          <option value="3rd Year PS/N-T/TV">3rd Year PS/N-T/TV</option>
                          <option value="1st Year College">1st Year College </option>
                          <option value="2nd Year College">2nd Year College </option>
                          <option value="3rd Year College">3rd Year College</option>
                          <option value="4th Year College or higher">4th Year College or higher</option>
                          <option value="Post Grad w/ units">Post Grad w/ units</option>
                          <option value="ALS Elementary">ALS Elementary</option>
                          <option value="ALS Secondary">ALS Secondary</option>
                          <option value="SPED Elementary">SPED Elementary</option>
                          <option value="SPED Secondary">SPED Secondary</option>
                          <option value="Grade school graduate">Grade school graduate</option>
                          <option value="High school graduate">High school graduate</option>
                          <option value="Post secondary graduate">Post secondary graduate</option>
                          <option value="College graduate">College graduate</option>
                          <option value="Masters/PhD graduate">Masters/PhD graduate</option>
                        </select>
                      </div>
                      </div> <!-- form-group end.// -->

                      <div class="col form-group">
                        <label> <br> </label>
                      </div> <!-- form-group end.// -->
                    </div> <!-- form-row end.// -->
                        </div>

</div>
                      </div>


              </article> <!-- card-body end .// -->

            </div> <!-- col.//-->
          </div>
        </section>

        <!-- End HOUSING CHARACTERISTICS 1 Section -->
         <section id="clients" class="clients section-bg">
    <div class="container">

        <div class="row justify-content-center" >
          <div class="col-md-6" >
            <div class="card" style=" background: #ffffff; border-color: black; width: 81rem; margin-left: -300px; margin-top: -40px; padding-bottom: 20px; width: 50rem;" >

              
                

                <div class="educ">
                    <div class="form-row" style="margin-top: 15px;">
                      <p style="margin: 20px 10px; margin-bottom: 20px;"> <b>For 5 years old and above</b>
                      </p>
                    </div>

                      <div class="form-row">
                        <div class="col form-group">
                          <label style="width: 700px">(19) Can you read and write a simple message in any language or dialect? <br><br> 1 - Yes   2 - No </label>   
                          <input type="text" for="q19" id="q19" name="q19" class="form-control1" placeholder="">
                        </div> <!-- form-group end.// -->

                        <div class="col form-group">
                          <label> <br> </label>


                        </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                        </div>

</div>
                      </div>


              </article> <!-- card-body end .// -->

            </div> <!-- col.//-->
          </div>
        </section>

        <!-- End HOUSING CHARACTERISTICS 1 Section -->

          <section id="clients" class="clients section-bg">
    <div class="container">

        <div class="row justify-content-center" >
          <div class="col-md-6" >
            <div class="card" style=" background: #ffffff; border-color: black; width: 81rem; margin-left: -300px; margin-top: -40px; margin-bottom: 30px; padding-bottom: 20px; width: 50rem;" >

              
                

                <div class="educ">
                    <div class="form-row">
                      <p style="margin: 30px 10px; margin-bottom: 20px;"> <b>For 15 years old and above</b>
                      </p>
                    </div>

                      <div class="form-row">
                        <div class="col form-group">
                          <label style="width: 700px">(20) Are you a registered voter? <br><br> 1 - Yes   2 - No (skip to <b>(22)</b>) </label>   
                          <input type="text" for="q20" id="q20" name="q20" class="form-control1" placeholder="">
                        </div> <!-- form-group end.// -->

                         <div class="col form-group" style="margin-left: 1px; ">
                          <label style="width: 700px">(21) Did you vote in the last election? <b> If OFW go to next number</b> <br><br> 1 - Yes 2 - No  3 - I don't know </label>   
                          <input type="text" for="q21" id="q21" name="q21" class="form-control1" placeholder="">
                        </div> <!-- form-group end.// -->

                        <div class="col form-group">
                          <label> <br> </label>


                        </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                        </div>

</div>
                      </div>


              </article> <!-- card-body end .// -->

            </div> <!-- col.//-->
          </div>
        </section>

        <!-- End HOUSING CHARACTERISTICS 1 Section -->

        <!-- ======= HOUSING CHARACTERISTICS 2 Section ======= -->
        <section id="services" class="services"style=" background: #b7d8ef">
          <div class="container">

            <div class="row counters">
          
              <div class="row justify-content-center" >
                <div class="col-md-6" >
                  <p style="font-weight: bolder; font-size:30px; color: black; margin-top: 1px; margin-left: -540px; font-family: Raleway; text-align: center;"><B> Economic Activity </B></p>

                  <div class="card" style="padding-bottom: 1px; padding-top: 18px; padding-left: 10px; height:92%;margin-bottom: -68px; margin-left: -300px; width: 50rem;" >

                      <div class="form-row">
                        <p style="margin: 2px 20px; margin-bottom: 20px; color: black; font-weight: 600;"> <b>For 5 years old and above</b>
                        </p></div>


                        <div class="form-row">

                          <div class="col form-group">
                            <label style="width: 250px;">(22) Did you do any work for at <br> least 1 hour during the past week?<br><br><br> 1 - yes 2 - no (skip to <b>(22)</b>)</label>   <br>
                            <input type="number" for="q22" id="q22" name="q22" class="form-control" placeholder="" style="width: 150px;"><br>
                          </div> <!-- form-group end.// --> 

                          <div class="col form-group" style="margin-left: 20px;">
                            <label>(23) Although you did not work, did you have a job or business during the past week? <br><br> 1 - yes 2 - no (skip to <b>(32)</b>)</label>   <br>
                            <input type="number" for="q23" id="q23" name="q23" class="form-control" placeholder="" style="width: 150px;">
                          </div> <!-- form-group end.// -->

                          <div class="col form-group" style="margin-left: 20px;">
                            <label>(24) How many work, jobs<br> or businesses do you have? </label>   <br>
                            <input type="number" for="q24" id="q24" name="q24" class="form-control" placeholder="" style="width: 150px; margin-top: 65px;">
                          </div> <!-- form-group end.// -->

                        </div>

                        <div class="form-row">

                          <div class="col form-group">

                            <label style="margin-left: 5px; width: 270px;">
                              (25) What was your primary occupation during the past week <br><br><br> (SPECIFY OCCUPATION, E.G.,<br> ELEMENTARY TEACHER, RICE<br> FARMER, ETC.) </label>   <br>
                              <input for="q25" id="q25" name="q25" class="form-control" type="text">
                          </div> <!-- form-group end.// -->

                          <div class="col form-group" style="margin-left: -40px">

                              <label style="margin-left: 5px; width: 290px;">
                                (26) In what kind of industry did you work during the past week? <br><br><br> (SPECIFY INDUSTRY, E.G.,<br> PRIMARY/ELEMENTARY EDUCATION, GROWING PADDY RICE, ETC) </label>   
                                <br>

                                <input for="q26" id="q26" name="q26" class="form-control" type="text">
                          </div> <!-- form-group end.// -->
                        </div> <!-- form-row end.// -->


                            <div class="col form-group">
                              <label> <br> </label>

                            </div> <!-- form-group end.// -->
                          </div> <!-- form-row end.// -->

                        </div>
                      </section>

      <!-- HOUSING CHARACTERISTICS 2 Services Section -->

       <section id="services" class="services"style=" background: #b7d8ef">
            <div class="container">

                <div class="row counters">
                        

                   <div class="row justify-content-center" >
                     <div class="col-md-6">
                        <div class="card" style="padding-top: 18px; padding-left: 10px; margin-top: -50px; height: 130%; margin-bottom:-150px; width: 50rem; margin-left: -300px;" >

                           <div class="form-row">
                              <p style="margin: 2px 20px; margin-bottom: 48px; font-weight: 600"> <b>For 15 years old and above</b>
                                      </p></div>


                          <div class="form-row">
                             <div class="col form-group">
                               <label style="margin-left: 5px;">
                                      (27) What is your nature<br> of employment? </label><br>


                                    <div class="dropdown">
                                      <select for="q27" id="q27" name="q27" style="margin-bottom: 90px; width: 60%;" required>
                                        <option value="">Select your option</option>
                                         <option value="Permanent job/business/unpaid family work">Permanent job/business/unpaid family work </option>
                                         <option value="Short-term or seasonal or casual job/business/unpaid family work">Short-term or seasonal or casual job/business/unpaid family work </option>
                                         <option value="Worked for different employers or customers on day-to-day or week-to-week basis">Worked for different employers or customers on day-to-day or week-to-week basis</option>
                                      </select>
                                    </div>



                             </div> <!-- form-group end.// -->

                             <div class="col form-group" style="margin-left: -110px">
                                <label style="margin-left: 5px; margin-bottom: 12px;">
                                        (28) What was your normal working hours<br> per day during the past week? </label><br>

                                    
                                    <input for="q28" id="q28" name="q28" class="form-control" type="number">

                            </div> <!-- form-group end.// -->
                          </div> <!-- form-row end.// -->

                          <div class="form-row" style="margin-top: -70px;">
<div class="page-wrap">
                            <div class="col form-group" >
                                <label style="margin-left: 5px">
                                       (29) What was your total number <br> of hours worked during the past week? </label><br>

                                    <input for="q29" id="q29" name="q29" class="form-control" type="number">
                           </div> <!-- form-group end.// -->
</div>
                             <div class="col form-group" style="margin-left: 50px">
                                <label style="margin-left: 5px; margin-bottom: 18px;">
                                       (30) Did you want more hours of<br> work  during the past week? 
                                </label><br>

                             <div class="form-check form-check-inline">
                                   <input for="q30" id="q30" name="q30" class="form-check-input" type="radio" value="Yes">
                                       <label class="form-check-label" > Yes</label></div>
                             <div class="form-check form-check-inline">
                                    <input for="q30" id="q30" name="q30" class="form-check-input" type="radio" value="No">
                                       <label class="form-check-label" > No</label>
                                        </div>
                            </div> <!-- form-group end.// -->
                          </div> 
                          <br><br><br><br><!-- form-row end.// -->


                           <div class="col form-group">
                              <label> <br> </label>
                                              </div> <!-- form-group end.// -->
                                            </div> <!-- form-row end.// -->

                                          </div>
                                        </section>
                                        
        <!-- HOUSING CHARACTERISTICS 2 Services Section -->

               <section id="services" class="services" style=" background:#b7d8ef">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 18px; padding-left: 10px; margin-top: -105px; height: 550%; margin-bottom: -65px; width: 50rem; margin-left: -300px;" >

                         <div class="form-row">
                          <p style="margin: 10px 20px; margin-bottom: 28px; font-weight: 600"> <b> If YES in (22) or YES in (23)</b>
                          </p>
                        </div>

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 5px;margin-bottom: 16px;">
                                  (31) Did you look for additional work during<br>the past week? </label><br>

                          <div class="form-check form-check-inline">
                               <input for="q31" id="q31" name="q31" class="form-check-input" type="radio"  value="Yes">
                                  <label class="form-check-label"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q31" id="q31" name="q31" class="form-check-input" type="radio"  value="No">
                                  <label class="form-check-label"> No</label>
                          </div>
                            </div> <!-- form-group end.// -->

                            <div class="col form-group" style="margin-left: -110px">
                                <label style="margin-left: 5px; margin-bottom: 2px;">
                                    (32) What is your class of worker? </label><br>


                           <div class="dropdown">
                              <select for="q32" id="q32" name="q32" style="margin-top: 26px; width: 60%" required>
                                <option value="">Select your option</option>
                                <option value="Working for private household">Working for private household</option>
                                <option value="Working for private business/establishment /farm">Working for private business/establishment /farm</option>
                                <option value="Working for government/government corporation">Working for government/government corporation</option>
                                <option value="Self-employed with no paid employee">Self-employed with no paid employee</option>
                                <option value="Employer in own family- operated farm or business">Employer in own family- operated farm or business</option>
                                <option value="Working with pay on own family-operated farm or business">Working with pay on own family-operated farm or business</option>
                                <option value="Working without pay on own family-operated farm or business">Working without pay on own family-operated farm or business</option>
                              </select>
                            </div>

                            </div> <!-- form-group end.// -->
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

            <!-- HOUSING CHARACTERISTICS 2 Services Section -->

              <section id="services" class="services"style=" background: #b7d8ef">
                  <div class="container">
                     <div class="row counters">
                        <div class="row justify-content-center" >
                              <div class="col-md-6">
                                <div class="card" style="padding-top: 18px; padding-left: 10px;  margin-top: -85px; height: 155%; width: 50rem; margin-left: -300px;" >

                    <div class="form-row">
                       <p style="margin: 10px 20px; margin-bottom: 28px;font-weight: 600"> <b> If NO in (22) or YES in (23)</b>
                       </p>
                    </div>


                    <div class="form-row">

                      <div class="col form-group">
                        <label style="margin-left: 5px;margin-bottom: 16px;">
                            (33) Did you look for work or try to establish <br> business during the past week? 
                        </label><br>

                      <div class="form-check form-check-inline">
                         <input for="q33" id="q33" name="q33" class="form-check-input" type="radio"  value="Yes">
                           <label class="form-check-label" > Yes</label>
                      </div>

                      <div class="form-check form-check-inline">
                         <input for="q33" id="q33" name="q33" class="form-check-input" type="radio" value="No">
                          <label class="form-check-label" > No (proceed to <b>(37)</b>)
                          </label>
                     </div>
                      </div> <!-- form-group end.// -->
                  </div> <!-- form-row end.// -->
                  
                  <div class="form-row">

                     <div class="col form-group">
                        <label> <br> </label>
                      </div> <!-- form-group end.// -->
                       </div> <!-- form-row end.// -->
                        </div>
                         </section>

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->

         <section id="services" class="services"style=" background:#b7d8ef">
            <div class="container">
              <div class="row counters">
                 <div class="row justify-content-center" >
                              <div class="col-md-6">
                                <div class="card" style="padding-top: 18px; padding-left: 10px; height: 130%; margin-top: -150px; margin-bottom: 50px; width: 50rem; margin-left: -300px;" >

             <div class="form-row">
               <p style="margin: 10px 20px; margin-bottom: 34px;font-weight: 600"> <b>If YES in (33) </b>
                                      </p></div>


                 <div class="form-row">

                    <div class="col form-group">
                      <label style="margin-left: 5px">
                        (34) Was this your first time to look for<br>work or try to establish a business? 
                      </label><br>


                    <div class="form-check form-check-inline" style="margin-bottom: 50px;">
                        <input for="q34" id="q34" name="q34" class="form-check-input" type="radio" value="Yes">
                            <label class="form-check-label" > Yes</label>
                    </div>

                    <div class="form-check form-check-inline">
                        <input for="q34" id="q34" name="q34" class="form-check-input" type="radio"  value="No">
                            <label class="form-check-label" > No</label>
                    </div>

                    </div> <!-- form-group end.// -->

                    <div class="col form-group" style="margin-left: -110px">
                        <label style="margin-left: 5px; margin-bottom: 7px;">
                            (35) What have you been doing to find work? </label><br>


                          <div class="dropdown">
                              <select for="q35" id="q35" name="q35" style="margin-top: 26px; width: 60%"required>
                                <option value="">Select your option</option>
                                <option value="Registered in public employment agency">Registered in public employment agency</option>
                                <option value="Registered in private employment agency">Registered in private employment agency</option>
                                <option value="Approached employer directly">Approached employer directly</option>
                                <option value="Approached relatives or friends">Approached relatives or friends</option>
                                <option value="Placed or answered advertisements">Placed or answered advertisements</option>
                                <option value="Searched and applied online">Searched and applied online</option>
                                <option value="Others">Others</option>
                               </select>
                          </div>

                        </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->

                      <div class="form-row" style="margin-top: -20px;">

                        <div class="col form-group">
                            <label style="margin-left: 5px">
                            (36) How many weeks have you been<br> looking for work? <b>(Proceed to 46) </b><br>
                            </label><br>

                        <input for="q36" id="q36" name="q36" class="form-control" type="number">
                       </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->


                        <div class="col form-group">
                          <label> <br> </label>
                            </div> <!-- form-group end.// -->
                             </div> <!-- form-row end.// -->
                            </div>
                </section>

      <!-- HOUSING CHARACTERISTICS 2 Services Section -->

             <section id="services" class="services"style=" background: #b7d8ef">
                <div class="container">
                    <div class="row counters">
                      <div class="row justify-content-center" >
                              <div class="col-md-6">
                                <div class="card" style="padding-top: 18px; padding-left: 10px; height: 170%; margin-top: -208px; margin-bottom: 20px; width: 50rem; margin-left: -300px;" >

              <div class="form-row">
                <p style="margin: 10px 20px; margin-bottom: 10px;font-weight: 600"> <b>If NO in (33) </b>
                </p>
              </div>

              <div class="form-row">

                <div class="col form-group">
                  <label style="margin-left: 5px;">
                    (37) Why did you not look for work? 
                  </label> 

                      <div class="dropdown" style="width:50%;">
                        <select for="q37" id="q37" name="q37" >
                          <option value="">Select your option</option>
                          <option value="Tired/Believes no work is available">Tired/Believes no work is available</option>
                          <option value="Awaiting results of previous job application">Awaiting results of previous job application</option>
                          <option value="Temporary illness/ disability">Temporary illness/ disability</option>
                          <option value="Bad weather">Bad weather</option>
                          <option value="Waiting for rehire/job recall">Waiting for rehire/job recall</option>
                          <option value="Too young/old or retired/permanent disability">Too young/old or retired/permanent disability</option>
                          <option value="Household, family duties">Household, family duties</option>
                          <option value="Schooling">Schooling</option>
                          <option value="Others">Others</option>

                         </select>
                     </div>
                </div> <!-- form-group end.// -->

                <div class="col form-group" style="margin-left: -130px">
                   <label style="margin-left: 5px; margin-bottom: 15px;">
                      (38) When was the last time you looked for work? 
                  </label><br>

                      <div class="form-check form-check-inline" style="margin-bottom: 10px;">
                        <input for="q38" id="q38" name="q38" class="form-check-input" type="radio" value="Within last month">
                         <label class="form-check-label" > Within last month</label>
                       </div>

                       <div class="form-check form-check-inline" style="margin-left: 90px;">
                        <input for="q38" id="q38" name="q38" class="form-check-input" type="radio" value="One to six months">
                         <label class="form-check-label" > One to six months</label>
                       </div>

                        <div class="form-check form-check-inline" style="margin-top: -80px; margin-bottom: 40px;">
                        <input class="form-check-input" for="q38" id="q38" name="q38" type="radio" value="More than six months ago">
                         <label class="form-check-label"  > More than six months ago</label>
                       </div>

                    </div> <!-- form-group end.// -->
                  </div> 
                  <br>
                  <br><!-- form-row end.// -->

                     <div class="col form-group">
                          <label> <br> </label>
                        </div> <!-- form-group end.// -->
                         </div> <!-- form-row end.// -->
                        </div>
              </section>

      <!-- HOUSING CHARACTERISTICS 2 Services Section -->

            <section id="services" class="services"style=" background: #b7d8ef">
              <div class="container">
                <div class="row counters">
                  <div class="row justify-content-center" >
                    <div class="col-md-6">
                      <div class="card" style="padding-top: 18px; padding-left: 10px; height: 170px; margin-top: -250px; margin-bottom: 1px; width: 50rem; margin-left: -300px;" >

            <div class="form-row">

              <div class="col form-group">
                 <label style="margin-left: 5px; margin-bottom: 15px; margin-top: 9px;">
                        (39) Had opportunity for work existed last<br> week or within two weeks, would you been <br> available? 
                 </label> <br>

                    <div class="form-check form-check-inline">
                      <input for="q39" id="q39" name="q39" class="form-check-input" type="radio" value="Yes">
                      <label class="form-check-label" > Yes</label>
                    </div>
                    <div class="form-check form-check-inline">
                      <input for="q39" id="q39" name="q39" class="form-check-input" type="radio" value="No">
                      <label class="form-check-label" > No</label>
                    </div>
              </div> <!-- form-group end.// -->

              <div class="col form-group" style="margin-left: 20px">
                 <label style="margin-left: 5px; margin-bottom: 40px; margin-top: 9px;">
                        (40) Were you willing to take up work <br> during the past week or within 2 weeks? 
                 </label><br>
                
                    <div class="form-check form-check-inline">
                         <input for="q40" id="q40" name="q40" class="form-check-input" type="radio" value="Yes">
                           <label class="form-check-label" > Yes</label>
                   </div>
                   <div class="form-check form-check-inline">
                         <input for="q40" id="q40" name="q40" class="form-check-input" type="radio" value="No">
                           <label class="form-check-label" > No</label>
                   </div>
                </div> <!-- form-group end.// -->
              </div> <!-- form-row end.// -->
        
          <div class="col form-group">
              <label> <br> </label>
              </div> <!-- form-group end.// -->
            </div> <!-- form-row end.// -->
          </div>
         </section>

        <!-- HOUSING CHARACTERISTICS 2 Services Section -->


            <section id="services" class="services"style=" background: #b7d8ef">
              <div class="container">
                <div class="row counters">
                  <div class="row justify-content-center" >
                    <div class="col-md-6">
                      <div class="card" style="padding-top: 18px; padding-left: 10px; height: 130%;  margin-top: -180px; margin-bottom: 45px; width: 50rem; margin-left: -300px; padding-bottom: 20px;" >

            <div class="form-row">

              <div class="col form-group">
                 <label style="margin-left: 5px; margin-bottom: 15px; margin-top: 9px;">
                        (41) In the past 12 months, how much total salary/wages did you receive? <br><br> DO NOT INCLUDE SALARY OF HOUSEHOLD MEMBERS WHO ARE OFW AND <br> HOUSEMAIDS/BOYS
                 </label> <br>

                    <label>(A) Cash </label>   
                    <input for="q41" id="q41" name="q41" type="number" class="form-control" placeholder="">
              </div> <!-- form-group end.// -->

              <div class="col form-group">
                 <label style="margin-left: 5px; margin-bottom: 15px; margin-top: 9px;">
                        <br><br><br><br><br><br>
                 </label> <br>

                    <label>(B) In Kind </label>   
                    <input for="q41" id="q41" name="q41" type="text" class="form-control" placeholder="">
              </div> <!-- form-group end.// -->

            
              </div> <!-- form-row end.// -->
         <div class="form-row">

          <div class="col form-group">
            <label style="margin-bottom: 15px; margin-top: 20px;">
                (42) Is ____ a member of SSS or GSIS?
             </label> <br>

             <div class="form-check form-check-inline">
                <input for="q42" id="q42" name="q42" class="form-check-input" type="radio"  value="Yes, SSS">
                    <label class="form-check-label" > Yes, SSS</label>
              </div>
              <div class="form-check form-check-inline">
                <input for="q42" id="q42" name="q42" class="form-check-input" type="radio" alue="Yes, GSIS">
                    <label class="form-check-label" > Yes, GSIS</label>
              </div>
              <div class="form-check form-check-inline">
                <input for="q42" id="q42" name="q42" class="form-check-input" type="radio" value=" Yes, both">
                    <label class="form-check-label" > Yes, both</label>
              </div>
              <div class="form-check form-check-inline">
                <input for="q42" id="q42" name="q42" class="form-check-input" type="radio" value="No">
                    <label class="form-check-label" > No</label>
              </div>
          </div> <!-- form-group end.// --> 
        </div> <!-- form-row end.// -->

          <div class="col form-group">
              <label> <br> </label>
              </div> <!-- form-group end.// -->
            </div> <!-- form-row end.// -->
          </div>
         </section>

        <!-- HOUSING CHARACTERISTICS 2 Services Section -->


      <!-- ======= NEXT PAGE BUTTON Section ======= -->
       <section id="testimonials" class="testimonials section-bg">
         <div class="container" style="padding-top: 1px;">
            <div class="form-group">
              <button type="submit" class="btn btn-primary btn-block"> Next Form </button>
            </div> <!-- form-group// -->
          </div>
        </form>
       </section>
     </body>
     </html>
        <!-- End NEXT PAGE BUTTON Section -->
<?php /**PATH C:\Users\ASUS\Desktop\Laravel\applubijid\resources\views//pages/fhh1.blade.php ENDPATH**/ ?>