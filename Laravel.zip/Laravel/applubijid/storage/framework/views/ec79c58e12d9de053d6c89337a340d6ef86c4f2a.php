

<?php $__env->startSection('mainContent'); ?>
	<hi>List of User</h1>
	<table class="table table-striped">
		<thead>
			<tr>
				<th>Users</th>
			
			</tr>
		</thead>
		<tbody>
	<?php $__currentLoopData = $locates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
		<tr>
			<td><a href="locates/<?php echo e($locate->id); ?>"><?php echo e($locate->Users); ?></a></td>
			
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<div><a href="locates/create"> Create User</a> </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\applubijid\resources\views/locates/index.blade.php ENDPATH**/ ?>