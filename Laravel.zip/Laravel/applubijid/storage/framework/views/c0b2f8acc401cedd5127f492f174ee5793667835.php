<!DOCTYPE html>
<html>
    <head>
        <title>CHART SAMPLE</title>
        <!--These 3 properties are required to resize the chart-->
        <style type="text/css">
            .chart-container {
                position: relative; 
                height: 50vh;
                width: 50vw;
            }
        </style>
    </head>

    <body>
    <div class="chart-container">
        <canvas id="myChart"></canvas>
    </div>
    
    <script src="Scripts/dist/Chart.js"></script>

    <script type="text/javascript">
        var sampleDATA = 10, sampleDATA2 = 5; //used in label 1 and 2

        var ctx = document.getElementById('myChart').getContext('2d');
        var chart = new Chart(ctx, {
            // The type of chart we want to create
            type: 'pie', 

            // The data for our dataset
            data: {
                labels: ['1-17', '18-30', '31-60', '60-80', '80-100', '100+'], //labels of which data is to be 
                                                                               //shown, can receive objects I believe so labels can be dynamic
                datasets: [{
                    backgroundColor: [
                        'rgb(245, 66, 66)',
                        'rgb(245, 164, 66)',       //pick whatever colors you want, should be same number as labes
                        'rgb(245, 230, 66)',
                        'rgb(129, 245, 66)',
                        'rgb(77, 255, 246)',
                        'rgb(66, 78, 245)'

                    ],
                    borderColor: 'rgba(255, 99, 132, 0)',
                    data: [sampleDATA, 10, sampleDATA2, 2, 20, 30]     //based on query and what was solved in the math, 
                                                            //provided variables as sample (hover on red part)
                }]
            },

            // Configuration options go here
            options: {
                responsive: true,
                maintainAspectRatio: false //makes it possible to resize the chart according to parent container size
            }

        });
    </script>

    
    </body>
</html> <?php /**PATH C:\Users\ASUS\Desktop\Laravel\applubijid\resources\views//admin/chart.blade.php ENDPATH**/ ?>