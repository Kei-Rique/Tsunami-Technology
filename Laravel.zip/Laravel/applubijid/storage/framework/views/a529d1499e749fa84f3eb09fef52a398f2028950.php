
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Test</title>
	
</head>
<body>

	<div class="container">
		<?php echo $__env->yieldContent('content'); ?>
	</div>

	<?php echo $__env->yieldContent('footer'); ?>
</body>
</html>
<?php /**PATH C:\Users\ASUS\Desktop\Laravel\applubijid\resources\views/layouts/app.blade.php ENDPATH**/ ?>