<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Form - Household 3</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i, 700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/line-awesome/css/line-awesome.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">


  <!-- Template Main CSS File -->
  <link href="assets/css/fhh3.css" rel="stylesheet">
</head>

<body>

  <!-- ======= IDENTIFICATION Section ======= -->
   <section id="about" class="about">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:50px; color: black; margin-left: -471px; font-family: Raleway;"> 
              Health and Other Characteristics </p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

  <!-- End IDENTIFICATION Section -->

                                        
        <!-- HOUSING CHARACTERISTICS 2 Services Section -->

               <section id="services" class="services" style=" background:white">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 48px; padding-left: 10px; margin-top: -100px; height: 300%; margin-bottom: -65px; margin-left: -510px;" >

                      <form>
                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 30px;">
                                  (52) What is your household's main source of water supply? </label><br>

                      <div class="dropdown">
                        <select required style="margin-left: 20px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Total blindness</option>
                          <option value="2">Partial blindness</option>
                          <option value="3">Low vision</option>
                         </select>
                     </div>
                </div> <!-- form-group end.// -->

                            
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

            <!-- HOUSING CHARACTERISTICS 2 Services Section -->
	<section id="services" class="services"style=" background: white">
 		<div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin: 10px 30px; margin-bottom: 40px; font-weight: 600; font-size: 25px; margin-top: 10px; margin-left: -640px;"> <b> ASK (53) IF ANSWER IN (52) IS '2', '3', '4', '5', '6', '7', <br> '8', '9' OR '12'. IF THE ANSWER IN (52) IS '1', '10' OR '11', GO TO (54)</b>
                          </p>
                        </div>
                    </div></div></div></div>
</section>

              <section id="services" class="services"style=" background: white">
                  <div class="container">
                     <div class="row counters">
                        <div class="row justify-content-center" >
                              <div class="col-md-6">
                                <div class="card" style="padding-top: 38px; padding-left: 10px; margin-top: -100px; height: 155%; margin-left: -510px; margin-bottom: -6px;">

                 <form>
                 
                    <div class="form-row">

                      <div class="col form-group">
                        <label style="margin-left: 20px;margin-bottom: 40px;">
                            (53) How far is this water source from your house? IN METERS
                        </label><br>

 						<input type="text" class="form-control1" style="margin-left: 20px;"placeholder="">
                      </div> <!-- form-group end.// -->
                  </div> <!-- form-row end.// -->
                  
                  <div class="form-row">

                     <div class="col form-group">
                        <label> <br> </label>
                      </div> <!-- form-group end.// -->
                       </div> <!-- form-row end.// -->
                        </div>
                         </section>

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->

         <section id="services" class="services" style=" background:white">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 38px; padding-left: 10px; margin-top: -155px; height: 300%; margin-bottom: -10px; margin-left: -510px;" >

                      <form>
                        
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 30px;">
                                  (54) What type of toilet facility does the household use? </label><br>

                     
                      <div class="dropdown">
                        <select required style="margin-left: 20px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Total blindness</option>
                          <option value="2">Partial blindness</option>
                          <option value="3">Low vision</option>
                         </select>
                     </div>
                            </div> <!-- form-group end.// -->

                            
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

      <!-- HOUSING CHARACTERISTICS 2 Services Section -->

        <!-- ======= IDENTIFICATION Section ======= -->
  <section id="about" class="about" style="background-color: #b7d8ef">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:60px; color: black; margin-left: -621px; font-family: Raleway; margin-top: -30px; margin-bottom: -10px;"> 
              <b>Housing</b> </p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section>

  <!-- End IDENTIFICATION Section -->

 <section id="services2" class="services2" style=" background:#b7d8ef" >
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -85px; height: 300%; margin-bottom: -83px; margin-left: -510px;" >

                      <form>
                     
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 28px;">
                                  (55) What is the tenure status of the housing unit and lot occupied by your household? </label><br>
 
                      <div class="dropdown">
                        <select required style="margin-left: 20px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Total blindness</option>
                          <option value="2">Partial blindness</option>
                          <option value="3">Low vision</option>
                         </select>
                     </div>
                            </div> <!-- form-group end.// -->

                            
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

       <!-- HOUSING CHARACTERISTICS 2 Services Section -->

       <section id="services" class="services"style=" background: #b7d8ef;">
 		<div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin: 10px 30px; margin-bottom: 20px; font-weight: 600; font-size: 25px; margin-top: 10px; margin-left: -590px;"> <b> ASK (56) IF ANSWER IN (55) IS '1', '3', '4', '5', '6', '7', <br> OR '9'. IF THE ANSWER IS '3', ASK ONLY FOR THE  <BR>IMPUTED RENT FOR THE HOUSE. IF THE ANSWER IN (55) IS '2' OR '8', GO TO (57)</b>
                          </p>
                        </div>
                    </div></div></div></div>
</section>

 <section id="services2" class="services2" style=" background:#b7d8ef">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -60px; height: 120%; margin-bottom: -4px; margin-left: -510px;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 28px;">
                                  (56) By your own estimate, how much is the imputed rent per month for the house and/or lot? </label><br>
                
 						<input type="text" class="form-control1" style="margin-left: 20px;"placeholder="">

                            </div> <!-- form-group end.// -->            
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

       <!-- HOUSING CHARACTERISTICS 2 Services Section -->
       <section id="services2" class="services2" style=" background:#b7d8ef">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -150px; height: 120%; margin-bottom: 85px; margin-left: -510px;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 28px;">
                                  (57) What type of toilet facility does the household use? </label><br>
                <div class="dropdown">
                        <select required style="margin-left: 20px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Total blindness</option>
                          <option value="2">Partial blindness</option>
                          <option value="3">Low vision</option>
                         </select>
                     </div>
                            </div> <!-- form-group end.// -->            
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

       <!-- HOUSING CHARACTERISTICS 2 Services Section -->
       <section id="services2" class="services2" style=" background:#b7d8ef">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -235px; height: 120%; margin-bottom: -80px; margin-left: -510px;" >

                      <form>
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:30px;margin-left: 20px;margin-bottom: 28px;">
                                  (58) What is the source of electricity in the dwelling place? </label><br>
                            </div> <!-- form-group end.// -->            
                         </div> <!-- form-row end.// -->

                         <div class="form-row">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  1. Electric Company </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                         	</div>
                         </div>

                         <div class="form-row">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  2. Generator </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                         	</div>
                         </div>

                         <div class="form-row">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  3. Solar </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                         	</div>
                         </div>

                         <div class="form-row">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  4. Battery </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                         	</div>
                         </div>

                         <div class="form-row">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  5. Others, specify </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: 20px;"placeholder="">
                         	</div>
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

       <!-- HOUSING CHARACTERISTICS 2 Services Section -->

       <section id="services2" class="services2" style=" background:#b7d8ef">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -290px; height: 100%; margin-bottom: -100px; margin-left: -510px;" >

                      <form>
                     
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 48px;">
                                  (59) How many of each of the following items does the household own? </label><br>
                            </div> <!-- form-group end.// -->

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 190px;margin-bottom: 48px;">
                                  (60) How many were acquired during <br> the past 3 years? </label><br>
                            </div> <!-- form-group end.// -->
                         </div> <!-- form-row end.// -->

                         <div class="form-row">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  1. Radio/Radio Casette </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>
                     

                         <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  2. Television </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                         <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  3. CD/VCD/DVD Player </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                         <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  4. Component/Stereo Set </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                         <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  5. Karaoke/Videoke </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                          <div class="form-row" style="margin-top: 10px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  6. Refrigerator/Freezer </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  7. Electric Fan </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  8. Flat iron </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  9. LPG gas stove/range </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  10. Washing machine </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

<div class="form-row" style="margin-top: 10px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  11. Microwave oven </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  12. Computer/Laptop/Notebook </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  13. Internet connection </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  14. Cellphone </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  15. Landline telephone </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                         <div class="form-row" style="margin-top: 10px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  16. Air Conditioner </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  17. Sewing machine </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  18. Car, Jeep, etc. </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  19. Tricycle, Motorcycle, etc. </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  20. Land (Agricultural) </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                         <div class="form-row" style="margin-top: 10px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  21. Land (Residential) </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                 22. Land (Commercial) </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  23. Sala/Sofa Set </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  24. Dining Set </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  25. Others, specify </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                         	</div>
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

       <!-- HOUSING CHARACTERISTICS 2 Services Section -->

        <section id="services2" class="services2" style=" background:#b7d8ef; margin-bottom: -200px;" >
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -320px; height: 120%; padding-bottom: -20px;margin-bottom: 85px; margin-left: -510px;" >

                      <form>
                         
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 68px;">
                                  (61) Do you have an insurance for the following? </label><br>
                            </div> <!-- form-group end.// -->

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 190px;margin-bottom: 68px;">
                                  (62) Who is the insurance provider? </label><br>
                            </div> <!-- form-group end.// -->
                         </div> <!-- form-row end.// -->

<div class="form-row">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 48px;">
                                  1. Government insurance</label><br>
                         	</div>

                         	<div class="col form-group">
                         		<div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                         	</div>

                         	<div class="col form-group">
                         		  <div class="dropdown">
                        <select required style="margin-left: 10px; width: 70%">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Above normal</option>
                          <option value="2">Normal</option>
                          <option value="3">Below normal (moderate)</option>
                          <option value="4">Below normal (severe)</option>
                         </select>
                     </div>
                         	</div>
                         </div>
                     

                         <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 48px;">
                                  2. Private insurance company </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                         	</div>

                         	<div class="col form-group">
                         		  <div class="dropdown">
                        <select required style="margin-left: 10px; width: 70%">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Above normal</option>
                          <option value="2">Normal</option>
                          <option value="3">Below normal (moderate)</option>
                          <option value="4">Below normal (severe)</option>
                         </select>
                     </div>
                         	</div>
                         </div>

                         <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 48px;">
                                  3. Bank </label><br>
                         	</div>

                         	<div class="col form-group">
                         	<div class="radio">
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1">
                                  <label class="form-check-label" for="inlineCheckbox1"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" id="inlineCheckbox2" value="2">
                                  <label class="form-check-label" for="inlineCheckbox2"> No</label>
                          </div>
                        </div>
                         	</div>

                         	<div class="col form-group">
                         		  <div class="dropdown">
                        <select required style="margin-left: 10px; width: 70%">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Above normal</option>
                          <option value="2">Normal</option>
                          <option value="3">Below normal (moderate)</option>
                          <option value="4">Below normal (severe)</option>
                         </select>
                     </div>
                         	</div>
                         </div>

                         <div class="form-row" style="margin-top: -20px;">
                         	 
                         	<div class="col form-group">
                         		<label style="margin-left: 20px;margin-bottom: 28px;">
                                  4. Others, specify </label><br>
                         	</div>

                         	<div class="col form-group">
                         		<input type="text" class="form-control1" style="margin-left: -220px;"placeholder="">
                         	</div>
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>
       <!-- ======= IDENTIFICATION Section ======= -->
  <section id="about" class="about" style="background-color: #ffffff">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:60px; color: black; margin-left: -621px; font-family: Raleway; margin-top: -30px; margin-bottom: -10px;"> 
              <b>Nutrition</b> </p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section>

  <!-- End IDENTIFICATION Section -->

       <section id="services" class="services" style=" background:#ffffff">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 18px; padding-left: 10px; margin-top: -75px; height: 80%; margin-bottom: 85px; margin-left: -510px;" >

                      <form>
                     <div class="form-row">
                <p style="margin: 10px 30px; margin-bottom: 30px;font-weight: 600"> <b>FOR 5 YEARS OLD AND BELOW</b>
                </p>
              </div>

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 28px;">
                                  (51) NUTRITIONAL STATUS OF CHILDREN 0-5 YEARS OLD AND DATE OF RECORD OF BARANGAY <BR> NUTRITION SCHOLAR </label><br>

                  <div class="dropdown">
                        <select required style="margin-left: 20px;">
                          <option value=""disabled>Select your option</option>
                          <option value="1">Above normal</option>
                          <option value="2">Normal</option>
                          <option value="3">Below normal (moderate)</option>
                          <option value="4">Below normal (severe)</option>
                         </select>
                     </div>

                            </div> <!-- form-group end.// -->    
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

       <!-- HOUSING CHARACTERISTICS 2 Services Section -->

      <!-- ======= NEXT PAGE BUTTON Section ======= -->
       <section id="testimonials" class="testimonials section-bg">
         <div class="container">
            <div class="form-group">
              <button type="submit" class="btn btn-primary btn-block"> <a href=""> ADD HOUSEHOLD</a> </button>
            </div> <!-- form-group// -->
          </div>
       </section>

        <!-- End NEXT PAGE BUTTON Section -->
<?php /**PATH C:\Users\ASUS\Desktop\Laravel\applubijid\resources\views//pages/fhh3.blade.php ENDPATH**/ ?>