<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo e($title); ?></title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i, 700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/line-awesome/css/line-awesome.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">


  <!-- Template Main CSS File -->
  <link href="assets/css/fhh3.css" rel="stylesheet">
</head>

<body>

  <!-- ======= IDENTIFICATION Section ======= -->
   <section id="about" class="about">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:45px; color: black; margin-left: -150px; font-family: Raleway;"> 
              Health and Other Characteristics </p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section><!-- End IDENTIFICATION Section -->

  <!-- End IDENTIFICATION Section -->

                                        
        <!-- HOUSING CHARACTERISTICS 2 Services Section -->
              <form method="post" action="/fhh3">
                <?php echo csrf_field(); ?>
               <section id="services" class="services" style=" background:white">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 48px; padding-left: 10px; margin-top: -100px; height: 300%; margin-left: -295px; width: 50rem;" >

                       
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 30px;">
                                  (52) What is your household's main source of water supply? </label><br>

                      <div class="dropdown">
                        <select for="q52" id="q52" name="q52" required style="margin-left: 20px;">
                          <option value="">Select your option</option>
                          <option value="Total blindness">Total blindness</option>
                          <option value="Partial blindness">Partial blindness</option>
                          <option value="Low vision">Low vision</option>
                         </select>
                     </div>
                </div> <!-- form-group end.// -->

                            
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

            <!-- HOUSING CHARACTERISTICS 2 Services Section -->
  <section id="services" class="services"style=" background: white">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin: 10px 30px; margin-bottom: 40px; font-weight: 600; font-size: 15px; margin-left: -370px;"> <b> ASK (53) IF ANSWER IN (52) IS '2', '3', '4', '5', '6', '7', <br> '8', '9' OR '12'. IF THE ANSWER IN (52) IS '1', '10' OR '11', GO TO (54)</b>
                          </p>
                        </div>
                    </div></div></div></div>
</section>

              <section id="services" class="services"style=" background: white">
                  <div class="container">
                     <div class="row counters">
                        <div class="row justify-content-center" >
                              <div class="col-md-6">
                                <div class="card" style="padding-top: 38px; padding-left: 10px; margin-top: -100px; height: 155%; margin-left: -295px; width: 50rem; margin-bottom: 10px;">

                 
                    <div class="form-row">

                      <div class="col form-group">
                        <label style="margin-left: 20px;margin-bottom: 40px;">
                            (53) How far is this water source from your house? IN METERS
                        </label><br>

            <input for="q53" id="q53" name="q53" type="text" class="form-control1" style="margin-left: 20px;"placeholder="">
                      </div> <!-- form-group end.// -->
                  </div> <!-- form-row end.// -->
                  
                  <div class="form-row">

                     <div class="col form-group">
                        <label> <br> </label>
                      </div> <!-- form-group end.// -->
                       </div> <!-- form-row end.// -->
                        </div>
                         </section>

    <!-- HOUSING CHARACTERISTICS 2 Services Section -->

         <section id="services" class="services" style=" background:white">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 38px; padding-left: 10px; margin-top: -155px;
                                padding-bottom: 10px;height: 300%; margin-bottom: 20px; margin-left: -295px; width: 50rem;" >

                        
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="margin-left: 20px;margin-bottom: 30px;">
                                  (54) What type of toilet facility does the household use? </label><br>

                     
                      <div class="dropdown">
                        <select for="q54" id="q54" name="q54" required style="margin-left: 20px;">
                          <option value="">Select your option</option>
                          <option value="Total blindness">Total blindness</option>
                          <option value="Partial blindness">Partial blindness</option>
                          <option value="Low vision">Low vision</option>
                         </select>
                     </div>
                            </div> <!-- form-group end.// -->

                            
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

      <!-- HOUSING CHARACTERISTICS 2 Services Section -->

        <!-- ======= IDENTIFICATION Section ======= -->
  <section id="about" class="about" style="background-color: #b7d8ef">
    <div class="container">

     <div class="container">
      <div class="row">  
        <div class="block">
          <div class="row">
            <div class="span4">
              <div class="content-heading"><p style="font-weight: bolder; font-size:45px; color: black; margin-left: -400px; font-family: Raleway; margin-top: -30px; margin-bottom: -10px;"> 
              <b>Housing</b> </p></div>
            </div> 
          </div>
          <br> 
        </div>
      </div>
    </div>
  </section>

  <!-- End IDENTIFICATION Section -->

 <section id="services2" class="services2" style=" background:#b7d8ef" >
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -85px; height: 300%; margin-left: -295px; width: 50rem;" >

                     
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 28px;">
                                  (55) What is the tenure status of the housing unit and lot occupied by your household? </label><br>
 
                      <div class="dropdown">
                        <select for="q55" id="q55" name="q55" required style="margin-left: 20px;">
                          <option value="">Select your option</option>
                          <option value="Total blindness">Total blindness</option>
                          <option value="Partial blindness">Partial blindness</option>
                          <option value="Low vision">Low vision</option>
                         </select>
                     </div>
                            </div> <!-- form-group end.// -->

                            
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

       <!-- HOUSING CHARACTERISTICS 2 Services Section -->

       <section id="services" class="services"style=" background: #b7d8ef;">
    <div class="container">
              <div class="row counters">
                   <div class="row justify-content-center" >
                              <div class="col-md-6">
             <div class="form-row">
                          <p style="margin-top: 50px; font-weight: 600; font-size: 15px; margin-left: -370px;"> <b> ASK (56) IF ANSWER IN (55) IS '1', '3', '4', '5', '6', '7', <br> OR '9'. IF THE ANSWER IS '3', ASK ONLY FOR THE  <BR>IMPUTED RENT FOR THE HOUSE. IF THE ANSWER IN (55) IS '2' OR '8', GO TO (57)</b>
                          </p>
                        </div>
                    </div></div></div></div>
</section>

 <section id="services2" class="services2" style=" background:#b7d8ef">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 10px; padding-left: 10px; padding-bottom: 15px; margin-top: -70px; height: 120%; margin-bottom: -4px; margin-left: -295px; width: 50rem;" >

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 28px;">
                                  (56) By your own estimate, how much is the imputed rent per month for the house and/or lot? </label><br>
                
            <input for="q56" id="q56" name="q56" type="text" class="form-control1" style="margin-left: 20px;"placeholder="">

                            </div> <!-- form-group end.// -->            
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

       <!-- HOUSING CHARACTERISTICS 2 Services Section -->
       <section id="services2" class="services2" style=" background:#b7d8ef">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -150px; height: 120%; margin-bottom: 85px; margin-left: -295px; width: 50rem;" >

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 28px;">
                                  (57) What type of toilet facility does the household use? </label><br>
                <div class="dropdown">
                        <select for="q57" id="q57" name="q57" required style="margin-left: 20px;">
                          <option value="">Select your option</option>
                          <option value="Total blindness">Total blindness</option>
                          <option value="Partial blindness">Partial blindness</option>
                          <option value="Low vision">Low vision</option>
                         </select>
                     </div>
                            </div> <!-- form-group end.// -->            
                         </div> <!-- form-row end.// -->

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

       <!-- HOUSING CHARACTERISTICS 2 Services Section -->
       <section id="services2" class="services2" style=" background:#b7d8ef">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -230px; 
                                padding-bottom: 45px;height: 120%; margin-bottom: -70px; margin-left: -295px; width: 50rem;" >

                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:30px;margin-left: 20px;margin-bottom: 28px;">
                                  (58) What is the source of electricity in the dwelling place? </label><br>
                            </div> <!-- form-group end.// -->            
                         </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  1. Electric Company </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q58_1" id="q58_1" name="q58_1" class="form-check-input" type="radio" value="Yes">
                                  <label class="form-check-label" > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q58_1" id="q58_1" name="q58_1" class="form-check-input" type="radio" value="No">
                                  <label class="form-check-label"> No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  2. Generator </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q58_2" id="q58_2" name="q58_2" class="form-check-input" type="radio" value="Yes">
                                  <label class="form-check-label" > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q58_2" id="q58_2" name="q58_2" class="form-check-input" type="radio" value="No">
                                  <label class="form-check-label" > No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  3. Solar </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q58_3" id="q58_3" name="q58_3" class="form-check-input" type="radio" value="Yes">
                                  <label class="form-check-label"> Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q58_3" id="q58_3" name="q58_3" class="form-check-input" type="radio" value="No">
                                  <label class="form-check-label" > No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  4. Battery </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q58_4" id="q58_4" name="q58_4" class="form-check-input" type="radio" value="1">
                                  <label class="form-check-label" > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q58_4" id="q58_4" name="q58_4" class="form-check-input" type="radio"  value="2">
                                  <label class="form-check-label" > No</label>
                          </div>
                        </div>
                          </div>
                         </div>

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  5. Others, specify </label><br><br><br><br><br><br>
                          </div>

                          <div class="col form-group">
                            <input for="q58_5" id="q58_5" name="q58_5" type="text" class="form-control1" style="margin-left: 20px;"placeholder="">
                          </div>
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

       <!-- HOUSING CHARACTERISTICS 2 Services Section -->

       <section id="services2" class="services2" style=" background:#b7d8ef">
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -245px; height: 100%; margin-bottom: 10px; margin-left: -295px; width: 50rem;" >

                     
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 48px;">
                                  (59) How many of each of the following items does the household own? </label><br>
                            </div> <!-- form-group end.// -->

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 190px;margin-bottom: 48px;">
                                  (60) How many were acquired during <br> the past 3 years? </label><br>
                            </div> <!-- form-group end.// -->
                         </div> <!-- form-row end.// -->

                         <div class="form-row">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  1. Radio/Radio Casette </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_1" id="q59_1" name="q59_1" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_1" id="q60_1" name="q60_1" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>
                     

                         <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  2. Television </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_2" id="q59_2" name="q59_2" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_2" id="q60_2" name="q60_2" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  3. CD/VCD/DVD Player </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_3" id="q59_3" name="q59_3" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_3" id="q60_3" name="q60_3" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  4. Component/Stereo Set </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_4" id="q59_4" name="q59_4" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_4" id="q60_4" name="q60_4" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  5. Karaoke/Videoke </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_5" id="q59_5" name="q59_5" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_5" id="q60_5" name="q60_5" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                          <div class="form-row" style="margin-top: 10px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  6. Refrigerator/Freezer </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_6" id="q59_6" name="q59_6" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_6" id="q60_6" name="q60_6" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  7. Electric Fan </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_7" id="q59_7" name="q59_7" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_7" id="q60_7" name="q60_7" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  8. Flat iron </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_8" id="q59_8" name="q59_8" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_8" id="q60_8" name="q60_8" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  9. LPG gas stove/range </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_9" id="q59_9" name="q59_9" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_9" id="q60_9" name="q60_9" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  10. Washing machine </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_10" id="q59_10" name="q59_10" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_10" id="q60_10" name="q60_10" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

<div class="form-row" style="margin-top: 10px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  11. Microwave oven </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_11" id="q59_11" name="q59_11" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_11" id="q60_11" name="q60_11" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  12. Computer/Laptop/Notebook </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_12" id="q59_12" name="q59_12" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_12" id="q60_12" name="q60_12" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  13. Internet connection </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_13" id="q59_13" name="q59_13" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_13" id="q60_13" name="q60_13" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  14. Cellphone </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_14" id="q59_14" name="q59_14" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_14" id="q60_14" name="q60_14" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  15. Landline telephone </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_15" id="q59_15" name="q59_15" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_15" id="q60_15" name="q60_15" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: 10px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  16. Air Conditioner </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_16" id="q59_16" name="q59_16" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_16" id="q60_16" name="q60_16" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  17. Sewing machine </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_17" id="q59_17" name="q59_17" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_17" id="q60_17" name="q60_17" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  18. Car, Jeep, etc. </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_18" id="q59_18" name="q59_18" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_18" id="q60_18" name="q60_18" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  19. Tricycle, Motorcycle, etc. </label>
                          </div>

                          <div class="col form-group">
                            <input for="q59_19" id="q59_19" name="q59_19" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_19" id="q60_19" name="q60_19" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                          <div class="form-row" style="margin-top: 10px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  20. Land (Agricultural) </label>
                          </div>

                          <div class="col form-group">
                            <input for="q59_20" id="q59_20" name="q59_20" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_20" id="q60_20" name="q60_20" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: 10px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  21. Land (Residential) </label>
                          </div>

                          <div class="col form-group">
                            <input for="q59_21" id="q59_21" name="q59_21" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_21" id="q60_21" name="q60_21" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                 22. Land (Commercial) </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_22" id="q59_22" name="q59_22" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_22" id="q60_22" name="q60_22" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  23. Sala/Sofa Set </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_23" id="q59_23" name="q59_23" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_23" id="q60_23" name="q60_23" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  24. Dining Set </label><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_24" id="q59_24" name="q59_24" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_24" id="q60_24" name="q60_24" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                          </div>
                         </div>

                          <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  25. Others, specify </label><br><br><br><br><br><br><br><br><br><br>
                          </div>

                          <div class="col form-group">
                            <input for="q59_25" id="q59_25" name="q59_25" type="text" class="form-control1" style="margin-left: -10px;"placeholder="">
                          </div>

                          <div class="col form-group">
                            <input for="q60_25" id="q60_25" name="q60_25" type="text" class="form-control1" style="margin-left: -50px;"placeholder="">
                            <br>
                          </div>
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

       <!-- HOUSING CHARACTERISTICS 2 Services Section -->

        <section id="services2" class="services2" style=" background:#b7d8ef; margin-bottom: -200px;" >
                    <div class="container">
                        <div class="row justify-content-center" >
                            <div class="col-md-6">
                                <div class="card" style="padding-top: 30px; padding-left: 10px; margin-top: -330px; height: 120%; padding-bottom: 40px;margin-bottom: 135px; margin-left: -295px; width: 50rem;" >

                         
                         <div class="form-row">

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 20px;margin-bottom: 68px;">
                                  (61) Do you have an insurance for the following? </label><br>
                            </div> <!-- form-group end.// -->

                            <div class="col form-group">
                              <label style="padding-top:20px;margin-left: 100px;margin-bottom: 68px;">
                                  (62) Who is the insurance provider? </label><br>
                            </div> <!-- form-group end.// -->
                         </div> <!-- form-row end.// -->

<div class="form-row" style="margin-top: -30px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 48px;">
                                  1. Government insurance</label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q61_1" id="q61_1" name="q61_1" class="form-check-input" type="radio" value="Yes">
                                  <label class="form-check-label" > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q61_1" id="q61_1" name="q61_1" class="form-check-input" type="radio"  value="No">
                                  <label class="form-check-label" > No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                              <div class="dropdown">
                        <select for="q62_1" id="q62_1" name="q62_1" required style="margin-left: 10px; width: 70%">
                          <option value="">Select your option</option>
                          <option value="Above normal">Above normal</option>
                          <option value="Normal">Normal</option>
                          <option value="Below normal (moderate)">Below normal (moderate)</option>
                          <option value="Below normal (severe)">Below normal (severe)</option>
                         </select>
                     </div>
                          </div>
                         </div>
                     

                         <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 48px;">
                                  2. Private insurance company </label><br>
                          </div>

                          <div class="col form-group">
                            <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q61_2" id="q61_2" name="q61_2" class="form-check-input" type="radio" value="Yes">
                                  <label class="form-check-label" > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q61_2" id="q61_2" name="q61_2" class="form-check-input" type="radio" value="No">
                                  <label class="form-check-label" > No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                              <div class="dropdown">
                        <select for="q62_2" id="q62_2" name="q62_2" required style="margin-left: 10px; width: 70%">
                          <option value="">Select your option</option>
                          <option value="Above normal">Above normal</option>
                          <option value="Normal">Normal</option>
                          <option value="Below normal (moderate)">Below normal (moderate)</option>
                          <option value="Below normal (severe)">Below normal (severe)</option>
                         </select>
                     </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 48px;">
                                  3. Bank </label><br>
                          </div>

                          <div class="col form-group">
                          <div class="radio">
                          <div class="form-check form-check-inline">
                               <input for="q61_3" id="q61_3" name="q61_3" class="form-check-input" type="radio" value="Yes">
                                  <label class="form-check-label" > Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                               <input for="q61_3" id="q61_3" name="q61_3" class="form-check-input" type="radio" value="No">
                                  <label class="form-check-label" > No</label>
                          </div>
                        </div>
                          </div>

                          <div class="col form-group">
                              <div class="dropdown">
                        <select for="q62_3" id="q62_3" name="q62_3" required style="margin-left: 10px; width: 70%">
                          <option value="">Select your option</option>
                          <option value="Above normal">Above normal</option>
                          <option value="Normal">Normal</option>
                          <option value="Below normal (moderate)">Below normal (moderate)</option>
                          <option value="Below normal (severe)">Below normal (severe)</option>
                         </select>
                     </div>
                          </div>
                         </div>

                         <div class="form-row" style="margin-top: -20px;">
                           
                          <div class="col form-group">
                            <label style="margin-left: 20px;margin-bottom: 28px;">
                                  4. Others, specify </label><br><br><br>
                          </div>

                          <div class="col form-group">
                            <input for="q61_4" id="q61_4" name="q61_4" type="text" class="form-control1" style="margin-left: -220px;"placeholder="">
                          </div>
                         </div>

                      <div class="form-row">
                          <div class="col form-group">
                             <label> <br> </label>
                          </div> <!-- form-group end.// -->
                      </div> <!-- form-row end.// -->
                   </div>
               </section>

      <!-- ======= NEXT PAGE BUTTON Section ======= -->
       <section id="testimonials" class="testimonials section-bg">
         <div class="container">
            <div class="form-group">
            </div> <!-- form-group// -->
          </div>
       </section>
       <section id="testimonials" class="testimonials section-bg">
         <div class="container">
            <div class="form-group">
              <button type="submit" class="btn btn-primary btn-block"> Next Form </button>
              </form>

            </div> <!-- form-group// -->
          </div>
       </section>
     
   </body>
   </html>

        <!-- End NEXT PAGE BUTTON Section -->
<?php /**PATH C:\Users\ASUS\Desktop\Laravel\applubijid\resources\views//pages/fhh3.blade.php ENDPATH**/ ?>