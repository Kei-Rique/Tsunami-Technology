

<?php $__env->startSection('content'); ?>

	<h1>post </h1>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\Laravel\applubijid\resources\views/post.blade.php ENDPATH**/ ?>