<?php

namespace App\Http\Controllers;
use App\Models\Fhh4;
use Illuminate\Http\Request;

class Fhh4Controller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $fhh4 = new Fhh4;
        $fhh4->crop= request('crop'); 
        $fhh4->crop_cash= request('crop_cash');
        $fhh4->crop_kind= request('crop_kind');
        $fhh4->livestock= request('livestock');
        $fhh4->livestock_cash= request('livestock_cash');
        $fhh4->livestock_kind= request('livestock_kind');
        $fhh4->fishing= request('fishing');
        $fhh4->fishing_cash= request('fishing_cash');
        $fhh4->fishing_kind= request('fishing_kind');
        $fhh4->forestry= request('forestry');
        $fhh4->forestry_cash= request('forestry_cash');
        $fhh4->forestry_kind= request('forestry_kind');
        $fhh4->wholesale= request('wholesale');
        $fhh4->wholesale_cash= request('wholesale_cash');
        $fhh4->wholesale_kind= request('wholesale_kind');
        $fhh4->manufacturing= request('manufacturing');
        $fhh4->manufacturing_cash= request('manufacturing_cash');
        $fhh4->manufacturing_kind= request('manufacturing_kind');
        $fhh4->community= request('community');
        $fhh4->community_cash= request('community_cash');
        $fhh4->community_kind= request('community_kind');
        $fhh4->transportation= request('transportation');
        $fhh4->transportation_cash= request('transportation_cash');
        $fhh4->transportation_kind= request('transportation_kind');
        $fhh4->mining= request('mining');
        $fhh4->mining_cash= request('mining_cash');
        $fhh4->mining_kind= request('mining_kind');
        $fhh4->construction= request('construction');
        $fhh4->construction_cash= request('construction_cash');
        $fhh4->construction_kind= request('construction_kind');
        $fhh4->activities= request('activities');
        $fhh4->activities_cash= request('activities_cash');
        $fhh4->activities_kind= request('activities_kind');
        $fhh4->total_ent_act= request('total_ent_act');
        $fhh4->total_salaries= request('total_salaries');
        $fhh4->share_crops_cash= request('share_crops_cash');
        $fhh4->share_crops_kind= request('share_crops_kind');
        $fhh4->remittance_cash= request('remittance_cash');
        $fhh4->remittance_kind= request('remittance_kind');
        $fhh4->cashreceipts_cash= request('cashreceipts_cash');
        $fhh4->cashreceipts_kind= request('cashreceipts_kind');
        $fhh4->cashsupport_cash= request('cashsupport_cash');
        $fhh4->cashsupport_kind= request('cashsupport_kind');
        $fhh4->rentals_cash= request('rentals_cash');
        $fhh4->rentals_kind= request('rentals_kind');
        $fhh4->interest_cash= request('cashreceipts_cash');
        $fhh4->interest_kind= request('interest_kind');
        $fhh4->pension_cash= request('pension_cash');
        $fhh4->pension_kind= request('pension_kind');
        $fhh4->dividends_cash= request('dividends_cash');
        $fhh4->dividends_kind= request('dividends_kind');
        $fhh4->other_sources_cash= request('other_sources_cash');
        $fhh4->other_sources_kind= request('other_sources_kind');
        $fhh4->q88_cash= request('q88_cash');
        $fhh4->q88_kind= request('q88_kind');
        $fhh4->q89_cash= request('q89_cash');
        $fhh4->q89_kind= request('q89_kind');
        $fhh4->q90_cash= request('q90_cash');
        $fhh4->q90_kind= request('q90_kind');
        $fhh4->q91_cash= request('q91_cash');
        $fhh4->q91_kind= request('q91_kind');
        $fhh4->save();
        return redirect('/fhh5');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
