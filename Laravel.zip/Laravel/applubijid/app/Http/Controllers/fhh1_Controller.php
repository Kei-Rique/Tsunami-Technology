<?php

namespace App\Http\Controllers;

use App\Models\Fhh1;
use Illuminate\Http\Request;

class fhh1_Controller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $fhh1 = DB::table('fhh1')->get();

        return view('fhh1.index', ['fhh1' => $users]);
    }



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $fhh1 = new Fhh1;
         $fhh1->surname = request('surname');
         $fhh1->first_name = request('first_name'); 
         $fhh1->middle_name = request('middle_name'); 
         $fhh1->date_of_birth = request('date_of_birth'); 
         $fhh1->age = request('age'); 
         $fhh1->sex = request('sex'); 
         $fhh1->nfamily = request('nfamily'); 
         $fhh1->rhousehold = request('rhousehold'); 
         $fhh1->registered_civilregistry = request('registered_civilregistry'); 
         $fhh1->marital_status = request('marital_status'); 
         $fhh1->ethnicity_by_blood = request('ethnicity_by_blood'); 
         $fhh1->q12 = request('q12'); 
         $fhh1->q13 = request('q13'); 
         $fhh1->q14 = request('q14'); 
         $fhh1->q15 = request('q15'); 
         $fhh1->q16 = request('q16'); 
         $fhh1->q17 = request('q17'); 
         $fhh1->q18 = request('q18'); 
         $fhh1->q19 = request('q19'); 
         $fhh1->q20 = request('q20'); 
         $fhh1->q21 = request('q21'); 
         $fhh1->q22 = request('q22'); 
         $fhh1->q23 = request('q23'); 
         $fhh1->q24 = request('q24'); 
         $fhh1->q25 = request('q25'); 
         $fhh1->q26 = request('q26'); 
         $fhh1->q27 = request('q27'); 
         $fhh1->q28 = request('q28'); 
         $fhh1->q29 = request('q29'); 
         $fhh1->q30 = request('q30'); 
         $fhh1->q31 = request('q31'); 
         $fhh1->q32 = request('q32'); 
         $fhh1->q33 = request('q33'); 
         $fhh1->q34 = request('q34'); 
         $fhh1->q35 = request('q35'); 
         $fhh1->q36 = request('q36'); 
         $fhh1->q37 = request('q37'); 
         $fhh1->q38 = request('q38'); 
         $fhh1->q39 = request('q39'); 
         $fhh1->q40 = request('q40'); 
         $fhh1->q41 = request('q41'); 
         $fhh1->q42 = request('q42');   
         $fhh1->save();  

        return redirect('/fhh2');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Form  $form
     * @return \Illuminate\Http\Response
     */
    public function show(Form $form)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Form  $form
     * @return \Illuminate\Http\Response
     */
    public function edit(Form $form)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Form  $form
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Form $form)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Form  $form
     * @return \Illuminate\Http\Response
     */
    public function destroy(Form $form)
    {
        //
    }
}
