<?php

namespace App\Http\Controllers;
use App\Models\Fhh5;
use Illuminate\Http\Request;

class Fhh5Controller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $fhh5 = new Fhh5;
        $fhh5->q92= request('q92'); 
        $fhh5->q93= request('q93'); 
        $fhh5->q94_1= request('q94_1'); 
        $fhh5->q94_2= request('q94_2'); 
        $fhh5->q94_3= request('q94_3'); 
        $fhh5->q94_4= request('q94_4'); 
        $fhh5->q94_5= request('q94_5');

        $fhh5->q95_1= request('q95_1'); 
        $fhh5->q95_2= request('q95_2'); 
        $fhh5->q95_3= request('q95_3'); 
        $fhh5->q95_4= request('q95_4'); 
        $fhh5->q95_5= request('q95_5');

        $fhh5->q96_1= request('q96_1'); 
        $fhh5->q96_2= request('q96_2'); 
        $fhh5->q96_3= request('q96_3'); 
        $fhh5->q96_4= request('q96_4'); 
        $fhh5->q96_5= request('q96_5'); 
        $fhh5->q96_6= request('q96_6'); 
        $fhh5->q96_7= request('q96_7'); 
        $fhh5->q96_8= request('q96_8'); 
        $fhh5->q96_9= request('q96_9'); 
        $fhh5->q96_10= request('q96_10'); 
        $fhh5->q96_11= request('q96_11'); 
        $fhh5->q96_12= request('q96_12'); 
        $fhh5->q96_13= request('q96_13'); 
        $fhh5->q96_14= request('q96_14'); 
        $fhh5->q96_15= request('q96_15'); 
        $fhh5->q96_16= request('q96_16'); 
        $fhh5->q96_17= request('q96_17'); 
        $fhh5->q96_18= request('q96_18'); 

        $fhh5->q97= request('q97'); 
     

        $fhh5->q98_1= request('q98_1'); 
        $fhh5->q98_2= request('q98_2'); 
        $fhh5->q98_3= request('q98_3'); 
        $fhh5->q98_4= request('q98_4'); 
        $fhh5->q98_5= request('q98_5'); 

        $fhh5->q99_a1= request('q99_a1'); 
        $fhh5->q99_a2= request('q99_a2'); 
        $fhh5->q99_a3= request('q99_a3'); 
        $fhh5->q99_a4= request('q99_a4'); 
        $fhh5->q99_a5= request('q99_a5'); 

        $fhh5->q99_b1= request('q99_b1'); 
        $fhh5->q99_b2= request('q99_b2'); 
        $fhh5->q99_b3= request('q99_b3'); 
        $fhh5->q99_b4= request('q99_b4'); 
        $fhh5->q99_b5= request('q99_b5');

        $fhh5->q100_1= request('q100_1'); 
        $fhh5->q100_2= request('q100_2'); 

        $fhh5->q101= request('q101'); 


        $fhh5->q102_1= request('q102_1'); 
        $fhh5->q102_2= request('q102_2'); 
        $fhh5->q102_3= request('q102_3'); 
        $fhh5->q102_4= request('q102_4'); 
        $fhh5->q102_5= request('q102_5'); 

        $fhh5->q104_1= request('q104_1'); 
        $fhh5->q104_2= request('q104_2'); 
        $fhh5->q104_3= request('q104_3'); 
        $fhh5->q104_4= request('q104_4'); 
        $fhh5->q104_5= request('q104_5');

        $fhh5->q105_1= request('q105_1'); 
        $fhh5->q105_2= request('q105_2'); 
        $fhh5->q105_3= request('q105_3'); 
        $fhh5->q105_4= request('q105_4'); 
        $fhh5->q105_5= request('q105_5'); 

        $fhh5->q106_1= request('q106_1'); 
        $fhh5->q106_2= request('q106_2'); 
        $fhh5->q106_3= request('q106_3'); 
        $fhh5->q106_4= request('q106_4'); 
        $fhh5->q106_5= request('q106_5');
        $fhh5->q106_6= request('q106_6'); 
        $fhh5->q106_7= request('q106_7'); 
        $fhh5->q106_8= request('q106_8'); 
        $fhh5->q106_9= request('q106_9');


        $fhh5->q107_1= request('q107_1'); 
        $fhh5->q107_2= request('q107_2'); 
        $fhh5->q107_3= request('q107_3'); 
        $fhh5->q107_4= request('q107_4'); 
        $fhh5->q107_5= request('q107_5');


        $fhh5->q108_1= request('q108_1'); 
        $fhh5->q108_2= request('q108_2'); 
        $fhh5->q108_3= request('q108_3'); 
        $fhh5->q108_4= request('q108_4'); 
        $fhh5->q108_5= request('q108_5');
        $fhh5->save();
        return redirect('/fhh6');



    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
