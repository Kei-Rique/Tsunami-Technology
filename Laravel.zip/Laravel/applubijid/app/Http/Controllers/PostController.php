<?php

namespace App\Http\Controllers;

use App\Models\Form;
use Illuminate\Http\Request;

class PostController extends Controller
{

/*USER*/
    public function login(){
        $title = 'Login';
        return view('/pages/login', compact('title'));
    }

    public function chub(){
        $title = 'Centralized Hub';
        return view('/pages/chub', compact('title'));
    }

    public function start_form(){
        $title = 'The Alubijid Household Profile Monitoring';
        return view('/pages/start_form', compact('title'));
    }

    public function demography(){
        $title = 'Demography';
        return view('/pages/demography', compact('title'));
    }

    public function fhh1(){
        $title = 'Family Household Information 1';
        return view('/pages/fhh1', compact('title'));
    }

    public function fhh2(){
        $title = 'Family Household Information 2';
        return view('/pages/fhh2', compact('title'));
    }

    public function fhh3(){
        $title = 'Family Household Information 3';
        return view('/pages/fhh3', compact('title'));
    }

    public function fhh4(){
        $title = 'Family Household Information 4';
        return view('/pages/fhh4', compact('title'));
    }

    public function fhh5(){
        $title = 'Family Household Information 5';
        return view('/pages/fhh5', compact('title'));
    }

    public function fhh6(){
        $title = 'Family Household Information 6';
        return view('/pages/fhh6', compact('title'));
    }

    public function fhh7(){
        $title = 'Family Household Information 7';
        return view('/pages/fhh7', compact('title'));
    }

    public function ty(){
        $title = 'Alubijid Household Profile Questionnaire';
        return view('/pages/ty', compact('title'));
    }

/*ADMIN*/
    public function admin(){
        $title = 'Admin';
        return view('/layouts/adminLayout', compact('title'));
    }

    public function tab2danger(){
        $title = 'Admin';
        return view('/admin/tab2danger', compact('title'));
    }

    public function chart(){
        $title = 'Chart';
        return view('/admin/chart', compact('title'));
    }
}
