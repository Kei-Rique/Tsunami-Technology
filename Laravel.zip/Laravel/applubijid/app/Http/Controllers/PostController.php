<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PostController extends Controller
{

    public function login(){
        $title = 'Login';
        $cssFile = '/assets/css/login.css';
        return view('/pages/login', compact('title'));
    }

    public function chub(){
        $title = 'Centralized Hub';
        return view('/pages/chub', compact('title'));
    }

    public function start_form(){
        $title = 'The Alubijid Household Profile Monitoring';
        return view('/pages/start_form', compact('title'));
    }

    public function demography(){
        $title = 'Demography';
        return view('/pages/demography', compact('title'));
    }

    public function fhh1(){
        $title = 'Family Household Information 1';
        return view('/pages/fhh1', compact('title'));
    }

    public function fhh2(){
        $title = 'Family Household Information 2';
        return view('/pages/fhh2', compact('title'));
    }

    public function fhh3(){
        $title = 'Family Household Information 3';
        return view('/pages/fhh3', compact('title'));
    }
}
