<?php

namespace App\Http\Controllers;
use App\Models\Fhh3;
use Illuminate\Http\Request;

class Fhh3Controller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
          $fhh3 = new Fhh3;
        $fhh3->q52= request('q52'); 
        $fhh3->q53= request('q53'); 
        $fhh3->q54= request('q54'); 
        $fhh3->q55= request('q55');
        $fhh3->q56= request('q56');
        $fhh3->q57= request('q57');  
        $fhh3->q58_1= request('q58_1');  
        $fhh3->q58_2= request('q58_2');  
        $fhh3->q58_3= request('q58_3');  
        $fhh3->q58_4= request('q58_4');  
        $fhh3->q58_5= request('q58_5');  

        $fhh3->q59_1= request('q59_1');  
        $fhh3->q59_2= request('q59_2');
        $fhh3->q59_3= request('q59_3');
        $fhh3->q59_4= request('q59_4');
        $fhh3->q59_5= request('q59_5');
        $fhh3->q59_6= request('q59_6');
        $fhh3->q59_7= request('q59_7');
        $fhh3->q59_8= request('q59_8');
        $fhh3->q59_9= request('q59_9');
        $fhh3->q59_10= request('q59_10');
        $fhh3->q59_11= request('q59_11');
        $fhh3->q59_12= request('q59_12');
        $fhh3->q59_13= request('q59_13');
        $fhh3->q59_14= request('q59_14');
        $fhh3->q59_15= request('q59_15');
        $fhh3->q59_16= request('q59_16');
        $fhh3->q59_17= request('q59_17');
        $fhh3->q59_18= request('q59_18');
        $fhh3->q59_19= request('q59_19');
        $fhh3->q59_20= request('q59_20');
        $fhh3->q59_21= request('q59_21');
        $fhh3->q59_22= request('q59_22');
        $fhh3->q59_23= request('q59_23');
        $fhh3->q59_24= request('q59_24');
        $fhh3->q59_25= request('q59_25');

        $fhh3->q60_1= request('q60_1');  
        $fhh3->q60_2= request('q60_2');
        $fhh3->q60_3= request('q60_3');
        $fhh3->q60_4= request('q60_4');
        $fhh3->q60_5= request('q60_5');
        $fhh3->q60_6= request('q60_6');
        $fhh3->q60_7= request('q60_7');
        $fhh3->q60_8= request('q60_8');
        $fhh3->q60_9= request('q60_9');
        $fhh3->q60_10= request('q60_10');
        $fhh3->q60_11= request('q60_11');
        $fhh3->q60_12= request('q60_12');
        $fhh3->q60_13= request('q60_13');
        $fhh3->q60_14= request('q60_14');
        $fhh3->q60_15= request('q60_15');
        $fhh3->q60_16= request('q60_16');
        $fhh3->q60_17= request('q60_17');
        $fhh3->q60_18= request('q60_18');
        $fhh3->q60_19= request('q60_19');
        $fhh3->q60_20= request('q60_20');
        $fhh3->q60_21= request('q60_21');
        $fhh3->q60_22= request('q60_22');
        $fhh3->q60_23= request('q60_23');
        $fhh3->q60_24= request('q60_24');
        $fhh3->q60_25= request('q60_25');

        $fhh3->q61_1= request('q61_1');
        $fhh3->q61_2= request('q61_2');
        $fhh3->q61_3= request('q61_3');
        $fhh3->q61_4= request('q61_4');

        $fhh3->q62_1= request('q62_1');
        $fhh3->q62_2= request('q62_2');
        $fhh3->q62_3= request('q62_3');
         $fhh3->save();
         return redirect('/fhh4');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
