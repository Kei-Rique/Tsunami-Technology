<?php

namespace App\Http\Controllers;

use App\Models\Locate;
use Illuminate\Http\Request;

class LocationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $locates = Locate::all();
        return view('locates.index', compact('locates'));


    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('locates.create');
       



    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

      
        $locate = new Locate;
        $locate->Users = request('Users');
        $locate->City = request('City');
        $locate->Purok = request('Purok');
        $locate->province = request('province');
        $locate->street = request('street');
        $locate->zone = request('zone');
        $locate->house_number = request('house_number');
        $locate->baranggay = request('baranggay');
        $locate->latitude = request('latitude');
        $locate->longitude = request('longitude');

        $locate->save();

    
        return redirect('/locates');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Locate  $locate
     * @return \Illuminate\Http\Response
     */
    public function show(Locate $locate)
    {
           return view('locates.show', compact('locate'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Locate  $locate
     * @return \Illuminate\Http\Response
     */
    public function edit(Locate $locate)
    {
        return view('locates.edit', compact('locate'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Locate  $locate
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Locate $locate)
    {
        
     $locate->Users = request('Users');
     $locate->City = request('City');
     $locate->Purok = request('Purok');
      $locate->province = request('province');
        $locate->street = request('street');
        $locate->zone = request('zone');
        $locate->house_number = request('house_number');
        $locate->baranggay = request('baranggay');
        $locate->latitude = request('latitude');
        $locate->longitude = request('longitude');

     $locate->save();
     return redirect('/locates');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Locate  $locate
     * @return \Illuminate\Http\Response
     */
    public function destroy(Locate $locate)
    {
          $locate->delete();
        return redirect('/locates');  
  }
}
