<?php

namespace App\Http\Controllers;
use App\Models\Fhh2;
use Illuminate\Http\Request;

class Fhh2Controller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $fhh2 = new Fhh2;
        $fhh2->q43= request('q43'); 
        $fhh2->q44= request('q44'); 
        $fhh2->q45= request('q45'); 
        $fhh2->q46= request('q46'); 
        $fhh2->q47= request('q47'); 
        $fhh2->q48= request('q48'); 
        $fhh2->q49= request('q49'); 
        $fhh2->q50= request('q50'); 
        $fhh2->q50b= request('q50b'); 
        $fhh2->q51= request('q51'); 
        $fhh2->save();
        return redirect('/fhh3');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
