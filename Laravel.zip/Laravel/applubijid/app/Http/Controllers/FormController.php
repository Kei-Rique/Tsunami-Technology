<?php

namespace App\Http\Controllers;

use App\Models\Form;
use Illuminate\Http\Request;

class FormController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $form = new Form;
        $form->purok = request('purok'); 
        $form->street = request('street'); 
        $form->zone = request('zone'); 
        $form->house_number = request('house_number'); 
        $form->baranggay = request('baranggay'); 
        $form->house_identification_number = request('house_identification_number'); 
        $form->latitude = request('latitude'); 
        $form->longitude = request('longitude'); 
        $form->name_of_respondent = request('name_of_respondent'); 
        $form->q1 = request('q1'); 
        $form->q2 = request('q2'); 
        $form->q3 = request('q3'); 
        $form->q4 = request('q4'); 
        $form->q5 = request('q5'); 
        $form->q6 = request('q6'); 
        $form->q7 = request('q7');   
        $form->q8 = request('q8');   
        $form->q9 = request('q9'); 

        $form->save();  

        return redirect('/demography');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Form  $form
     * @return \Illuminate\Http\Response
     */
    public function show(Form $form)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Form  $form
     * @return \Illuminate\Http\Response
     */
    public function edit(Form $form)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Form  $form
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Form $form)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Form  $form
     * @return \Illuminate\Http\Response
     */
    public function destroy(Form $form)
    {
        //
    }

    
}

