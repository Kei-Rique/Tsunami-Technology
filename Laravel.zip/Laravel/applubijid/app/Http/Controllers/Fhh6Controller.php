<?php

namespace App\Http\Controllers;
use App\Models\Fhh6;
use Illuminate\Http\Request;

class Fhh6Controller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $fhh6 = new Fhh6;
        $fhh6->q109= request('q109'); 
        $fhh6->q110= request('q110'); 
        $fhh6->q111= request('q111'); 
        $fhh6->q112= request('q112'); 

        $fhh6->q113_1= request('q113_1'); 
        $fhh6->q113_2= request('q113_2');

        $fhh6->q114_1= request('q114_1'); 
        $fhh6->q114_2= request('q114_2'); 

        $fhh6->q115_1= request('q115_1');
        $fhh6->q115_2= request('q115_2');


        $fhh6->q116_1= request('q116_1');  
        $fhh6->q116_2= request('q116_2');  

        $fhh6->q117= request('q117'); 
        $fhh6->q118= request('q118'); 
        $fhh6->q119= request('q119'); 
        $fhh6->q120= request('q120'); 
        $fhh6->q121= request('q121'); 
        $fhh6->q122= request('q122'); 
        $fhh6->q123= request('q123'); 
        $fhh6->q124= request('q124'); 
        $fhh6->q125= request('q125'); 
        $fhh6->q126= request('q126'); 

        $fhh6->q127= request('q127'); 
        $fhh6->q128= request('q128'); 
        $fhh6->q129= request('q129'); 
        $fhh6->q130= request('q130'); 
        $fhh6->q131= request('q131'); 
        $fhh6->q132= request('q132'); 
        $fhh6->q133= request('q133'); 
        $fhh6->q134= request('q134'); 
        $fhh6->q135= request('q135'); 
        $fhh6->q136= request('q136'); 
        $fhh6->q137= request('q137'); 
        $fhh6->q138= request('q138'); 
        $fhh6->q139= request('q139'); 
        $fhh6->q140= request('q140'); 

        $fhh6->q141_1= request('q141_1'); 
        $fhh6->q141_2= request('q141_2'); 
        $fhh6->q141_3= request('q141_3'); 
        $fhh6->q141_4= request('q141_4'); 
        $fhh6->q141_5= request('q141_5'); 
        $fhh6->q141_6= request('q141_6'); 
        $fhh6->q141_7= request('q141_7'); 
        $fhh6->q141_8= request('q141_8'); 
        $fhh6->q141_9= request('q141_9'); 
        $fhh6->q141_10= request('q141_10'); 
        $fhh6->q141_11= request('q141_11'); 


        $fhh6->q142_1= request('q142_1'); 
        $fhh6->q142_2= request('q142_2'); 
        $fhh6->q142_3= request('q142_3'); 
        $fhh6->q142_4= request('q142_4'); 
        $fhh6->q142_5= request('q142_5'); 
        $fhh6->q142_6= request('q142_6'); 
        $fhh6->q142_7= request('q142_7'); 
        $fhh6->q142_8= request('q142_8'); 
        $fhh6->q142_9= request('q142_9'); 
        $fhh6->q142_10= request('q142_10'); 
        $fhh6->q142_11= request('q142_11'); 


        $fhh6->q143_1= request('q143_1'); 
        $fhh6->q143_2= request('q143_2'); 
        $fhh6->q143_3= request('q143_3'); 
        $fhh6->q143_4= request('q143_4'); 
        $fhh6->q143_5= request('q143_5'); 
        $fhh6->q143_6= request('q143_6'); 
        $fhh6->q143_7= request('q143_7'); 
        $fhh6->q143_8= request('q143_8'); 
        $fhh6->q143_9= request('q143_9'); 
        $fhh6->q143_10= request('q143_10'); 
        $fhh6->q143_11= request('q143_11'); 

        $fhh6->q144_1= request('q144_1'); 
        $fhh6->q144_2= request('q144_2'); 
        $fhh6->q144_3= request('q144_3'); 
        $fhh6->q144_4= request('q144_4'); 
        $fhh6->q144_5= request('q144_5'); 
        $fhh6->q144_6= request('q144_6'); 
        $fhh6->q144_7= request('q144_7'); 
        $fhh6->q144_8= request('q144_8'); 
        $fhh6->q144_9= request('q144_9'); 
        $fhh6->q144_10= request('q144_10'); 
        $fhh6->q144_11= request('q144_11');

        $fhh6->q145= request('q145');

        $fhh6->q146_1= request('q146_1'); 
        $fhh6->q146_2= request('q146_2'); 
        $fhh6->q146_3= request('q146_3'); 
        $fhh6->q146_4= request('q146_4'); 
        $fhh6->q146_5= request('q146_5'); 
        $fhh6->q146_6= request('q146_6'); 
        $fhh6->q146_7= request('q146_7'); 
        $fhh6->q146_8= request('q146_8'); 
        $fhh6->q146_9= request('q146_9'); 
        $fhh6->q146_10= request('q146_10'); 
        $fhh6->q146_11= request('q146_11');
        $fhh6->q146_12= request('q146_12'); 
        $fhh6->q146_13= request('q146_13'); 

        $fhh6->q147_1= request('q147_1'); 
        $fhh6->q147_2= request('q147_2'); 
        $fhh6->q147_3= request('q147_3'); 
        $fhh6->q147_4= request('q147_4'); 
        $fhh6->q147_5= request('q147_5'); 
        $fhh6->q147_6= request('q147_6'); 
        $fhh6->q147_7= request('q147_7'); 
        $fhh6->q147_8= request('q147_8'); 
        $fhh6->q147_9= request('q147_9'); 
        $fhh6->q147_10= request('q147_10'); 
        $fhh6->q147_11= request('q147_11');
        $fhh6->q147_12= request('q147_12'); 
        $fhh6->q147_13= request('q147_13'); 
        $fhh6->save();
        return redirect('/fhh7');



    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
