<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class Fhh4 extends Model
{
  protected $table = 'fhh4';
}