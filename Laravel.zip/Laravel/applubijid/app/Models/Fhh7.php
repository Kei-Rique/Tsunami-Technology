<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class Fhh7 extends Model
{
  protected $table = 'fhh7';
}