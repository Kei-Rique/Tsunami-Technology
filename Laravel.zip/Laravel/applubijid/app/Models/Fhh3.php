<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class Fhh3 extends Model
{
  protected $table = 'fhh3';
}