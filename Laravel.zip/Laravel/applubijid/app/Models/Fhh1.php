<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class Fhh1 extends Model
{
  protected $table = 'fhh1';
}